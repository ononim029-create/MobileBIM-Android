package com.domokrat.mobilebim.ui

import android.graphics.Paint as NativePaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.nativeCanvas
import com.domokrat.mobilebim.core.*
import kotlin.math.max
import kotlin.math.min

/**
 * Document-oriented section preview, generated entirely from model geometry.
 * On-screen annotation scale is adaptive and is not yet an A1/A3 print layout.
 */
@Composable
fun SectionView(
    project:BimProject, cut:SectionCut,
    modifier:Modifier=Modifier,
    showHatches:Boolean=true, showDimensions:Boolean=true,
) {
    val section=remember(project,cut){SectionDocumentation.build(project,cut)}
    Canvas(modifier.fillMaxSize()) {
        drawRect(Color.White)
        val parts=section.parts
        val zMin=min(0.0,(parts.minOfOrNull{it.bottomMm}?:0.0)-500.0)
        val zMax=max(4000.0,(parts.maxOfOrNull{it.topMm}?:3000.0)+500.0)
        val length=section.lengthMm
        // Reserve a band below the cut for dimensions and drawing captions.
        val scale=min(size.width*0.84f/length.toFloat(),
            size.height*0.64f/(zMax-zMin).toFloat()).coerceAtLeast(0.001f)
        val sx=(size.width-length.toFloat()*scale)*0.5f
        val viewHeight=size.height*0.78f
        val sy=viewHeight-(viewHeight-(zMax-zMin).toFloat()*scale)*0.5f
        fun x(v:Double)=sx+v.toFloat()*scale
        fun y(v:Double)=sy-(v-zMin).toFloat()*scale
        val ink=Color(0xFF34495E)
        val faint=Color(0xFFC8D2DD)
        val labelPaint=NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply {
            color=android.graphics.Color.rgb(44,66,85)
            textSize=25f
        }
        val smallPaint=NativePaint(labelPaint).apply {textSize=21f}
        section.levels.forEach {level->
            val yy=y(level.elevationMm)
            drawLine(faint,Offset(0f,yy),Offset(size.width,yy),1f)
            drawContext.canvas.nativeCanvas.drawText(
                "${level.name} · ${level.elevationMm.toInt()} мм",8f,yy-6f,smallPaint)
        }
        val palette=listOf(Color(0xFFE0E5E9),Color(0xFFDDE6E2),Color(0xFFECE0D8),
            Color(0xFFF1EAD9),Color(0xFFE5E1EC),Color(0xFFDDE6EE))
        for(part in parts) {
            val left=x(part.leftMm);val right=x(part.rightMm)
            val top=y(part.topMm);val bottom=y(part.bottomMm)
            val width=right-left;val height=bottom-top
            if(width<=0f||height<=0f)continue
            val fill=if(part.layerIndex<0)Color(0xFFE2E8EB)
                else palette[part.layerIndex%palette.size]
            drawRect(fill,Offset(left,top),Size(width,height))
            if(showHatches&&width>3f&&height>3f) {
                val mode=SectionDocumentation.hatch(part.material)
                clipRect(left,top,right,bottom) {
                    when(mode) {
                        MaterialHatch.CONCRETE,MaterialHatch.WOOD,MaterialHatch.GENERIC -> {
                            val stride=if(mode==MaterialHatch.CONCRETE)17 else if(mode==MaterialHatch.WOOD)22 else 29
                            var at=left-height
                            while(at<right+height) {
                                drawLine(Color(0xFF9BAAB5),Offset(at,bottom),
                                    Offset(at+height,top),0.8f)
                                at+=stride
                            }
                        }
                        MaterialHatch.MASONRY -> {
                            var yy=top+14f
                            while(yy<bottom){drawLine(Color(0xFFB6A294),Offset(left,yy),Offset(right,yy),0.8f); yy+=14f}
                            var xx=left+28f
                            while(xx<right){drawLine(Color(0xFFC6B3A6),Offset(xx,top),Offset(xx,bottom),0.8f);xx+=42f}
                        }
                        MaterialHatch.INSULATION -> {
                            var xx=left
                            while(xx<right){
                                drawLine(Color(0xFF92A7A4),Offset(xx,top),Offset(xx+10f,bottom),0.8f)
                                drawLine(Color(0xFF92A7A4),Offset(xx+10f,bottom),Offset(xx+20f,top),0.8f)
                                xx+=20f
                            }
                        }
                    }
                }
            }
            drawRect(ink,Offset(left,top),Size(width,height),style=Stroke(0.9f))
        }
        drawContext.canvas.nativeCanvas.drawText(cut.name,14f,32f,labelPaint)
        if(showDimensions) {
            val bottomLine=min(size.height-40f,viewHeight+size.height*0.12f)
            // Overall section length, dimensioned along the cutting direction.
            drawLine(ink,Offset(x(0.0),bottomLine),Offset(x(length),bottomLine),1.2f)
            listOf(0.0,length).forEach {station->
                val xx=x(station)
                drawLine(ink,Offset(xx,bottomLine-12f),Offset(xx,bottomLine+12f),1.2f)
                drawLine(faint,Offset(xx,y(0.0)+8f),Offset(xx,bottomLine-15f),0.8f)
            }
            drawContext.canvas.nativeCanvas.drawText(
                "${length.toInt()} мм",(x(0.0)+x(length))/2-42f,bottomLine-10f,smallPaint)
            for(tag in section.openings) {
                val xx=x(tag.stationMm)
                val yy=y(tag.headMm)
                val text="${tag.name}: ${tag.widthMm.toInt()}×${(tag.headMm-tag.sillMm).toInt()}"
                drawLine(Color(0xFF147A7C),Offset(xx,yy),Offset(xx,yy-35f),1f)
                drawContext.canvas.nativeCanvas.drawText(text,xx+5f,yy-39f,smallPaint)
            }
            val maxZ=parts.maxOfOrNull{it.topMm}?:0.0
            val minZ=parts.minOfOrNull{it.bottomMm}?:0.0
            if(maxZ>minZ) {
                val dimensionX=size.width-19f
                drawLine(ink,Offset(dimensionX,y(minZ)),Offset(dimensionX,y(maxZ)),1f)
                listOf(minZ,maxZ).forEach {z ->
                    drawLine(ink,Offset(dimensionX-7f,y(z)),Offset(dimensionX+7f,y(z)),1f)
                }
                drawContext.canvas.nativeCanvas.drawText(
                    "H ${(maxZ-minZ).toInt()} мм",max(0f,dimensionX-165f),y(maxZ)-10f,smallPaint)
            }
        }
    }
}
