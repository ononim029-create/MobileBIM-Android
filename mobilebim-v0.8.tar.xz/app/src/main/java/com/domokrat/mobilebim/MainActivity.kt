package com.domokrat.mobilebim

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.domokrat.mobilebim.core.*
import com.domokrat.mobilebim.data.ProjectCodec
import com.domokrat.mobilebim.data.ProjectStorage
import com.domokrat.mobilebim.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme=lightColorScheme(
                primary=androidx.compose.ui.graphics.Color(0xFF126F72),
                secondary=androidx.compose.ui.graphics.Color(0xFF48617A)
            )) { EditorScreen() }
        }
    }
}

@Composable
private fun EditorScreen() {
    val context=LocalContext.current
    val storage=remember{ProjectStorage(context.applicationContext)}
    var project by remember{mutableStateOf(storage.loadDraft()?:BimProject())}
    var currentLevelId by remember{mutableStateOf(project.levels.first().id)}
    var tool by remember{mutableStateOf(EditorTool.SELECT)}
    var startPoint by remember{mutableStateOf<Point2?>(null)}
    var wallStartSnap by remember{mutableStateOf<SnapResult?>(null)}
    var snapMarker by remember{mutableStateOf<SnapResult?>(null)}
    var snappingEnabled by remember{mutableStateOf(true)}
    var orthoEnabled by remember{mutableStateOf(false)}
    var drawByNumbers by remember{mutableStateOf(false)}
    var slabPoints by remember{mutableStateOf(emptyList<Point2>())}
    var cadPoints by remember{mutableStateOf(emptyList<Point2>())}
    var activeLayer by remember{mutableStateOf("Чертёж")}
    var activeWallTypeId by remember{mutableStateOf<String?>(null)}
    var selectedCadHit by remember{mutableStateOf<CadHit?>(null)}
    var layersDialog by remember{mutableStateOf(false)}
    var wallTypesDialog by remember{mutableStateOf(false)}
    var assignTypeDialog by remember{mutableStateOf(false)}
    var cadEditDialog by remember{mutableStateOf(false)}
    var selectedWallId by remember{mutableStateOf<String?>(null)}
    var selectedOpeningId by remember{mutableStateOf<String?>(null)}
    var selectedSlabId by remember{mutableStateOf<String?>(null)}
    var selectedDraftLineId by remember{mutableStateOf<String?>(null)}
    var selectedDimensionId by remember{mutableStateOf<String?>(null)}
    var show3D by remember{mutableStateOf(false)}
    var showSection by remember{mutableStateOf(false)}
    var sectionHatches by remember{mutableStateOf(true)}
    var sectionDimensions by remember{mutableStateOf(true)}
    var selectedSectionId by remember{mutableStateOf<String?>(null)}
    var rotation by remember{mutableIntStateOf(0)}
    var undo by remember{mutableStateOf(emptyList<BimProject>())}
    var redo by remember{mutableStateOf(emptyList<BimProject>())}
    var editWallDialog by remember{mutableStateOf(false)}
    var editOpeningDialog by remember{mutableStateOf(false)}
    var editSlabDialog by remember{mutableStateOf(false)}
    var editDimensionDialog by remember{mutableStateOf(false)}
    var levelDialog by remember{mutableStateOf(false)}
    var renameDialog by remember{mutableStateOf(false)}
    var newDialog by remember{mutableStateOf(false)}
    var demoDialog by remember{mutableStateOf(false)}
    var levelMenu by remember{mutableStateOf(false)}
    val selectedWall=project.walls.find{it.id==selectedWallId}
    val selectedOpening=project.openings.find{it.id==selectedOpeningId}
    val selectedSlab=project.slabs.find{it.id==selectedSlabId}
    val selectedDraftLine=project.draftLines.find{it.id==selectedDraftLineId}
    val selectedDimension=project.dimensions.find{it.id==selectedDimensionId}
    val selectedLevel=project.levels.find{it.id==currentLevelId}?:project.levels.first()
    val selectedSection=project.sections.firstOrNull{it.id==selectedSectionId} ?: project.sections.firstOrNull()

    fun notify(message:String)=Toast.makeText(context,message,Toast.LENGTH_LONG).show()
    fun clearSelection() {
        selectedWallId=null;selectedOpeningId=null;selectedSlabId=null
        selectedDraftLineId=null;selectedDimensionId=null;selectedCadHit=null
    }
    fun commit(next:BimProject) {
        if(next==project)return
        undo=(undo+project).takeLast(50);redo=emptyList();project=next
    }
    fun replaceLoaded(next:BimProject) {
        project=next;currentLevelId=next.levels.first().id;tool=EditorTool.SELECT
        startPoint=null;wallStartSnap=null;snapMarker=null;slabPoints=emptyList()
        cadPoints=emptyList();activeLayer=next.draftLayers.first().name
        activeWallTypeId=null;clearSelection()
        undo=emptyList();redo=emptyList();show3D=false;showSection=false;selectedSectionId=null
    }
    fun changeTool(next:EditorTool) {
        tool=next;startPoint=null;wallStartSnap=null;snapMarker=null
        slabPoints=emptyList();cadPoints=emptyList();clearSelection()
    }
    fun tryEdit(operation:()->BimProject,onSuccess:()->Unit={}) {
        runCatching(operation).onSuccess {commit(it);onSuccess()}
            .onFailure {notify(it.message?:"Ошибка редактирования")}
    }

    LaunchedEffect(project) {
        if(project.levels.none{it.id==currentLevelId})currentLevelId=project.levels.first().id
        if(selectedWallId!=null&&project.walls.none{it.id==selectedWallId})selectedWallId=null
        if(selectedOpeningId!=null&&project.openings.none{it.id==selectedOpeningId})selectedOpeningId=null
        if(selectedSlabId!=null&&project.slabs.none{it.id==selectedSlabId})selectedSlabId=null
        if(selectedDraftLineId!=null&&project.draftLines.none{it.id==selectedDraftLineId})selectedDraftLineId=null
        if(selectedDimensionId!=null&&project.dimensions.none{it.id==selectedDimensionId})selectedDimensionId=null
        if(project.draftLayers.none{it.name==activeLayer}) activeLayer=project.draftLayers.first().name
        selectedCadHit?.let { hit ->
            if(when(hit.kind){
                 CadKind.LINE -> project.draftLines.none{it.id==hit.id}
                 CadKind.POLYLINE -> project.polylines.none{it.id==hit.id}
                 CadKind.CIRCLE -> project.circles.none{it.id==hit.id}
                 CadKind.ARC -> project.arcs.none{it.id==hit.id}
               }) selectedCadHit=null
        }
        if(activeWallTypeId!=null&&project.wallTypes.none{it.id==activeWallTypeId})activeWallTypeId=null
        if(selectedSectionId!=null && project.sections.none{it.id==selectedSectionId})selectedSectionId=null
        val snapshot=project
        runCatching{withContext(Dispatchers.IO){storage.saveDraft(snapshot)}}
            .onFailure{notify("Ошибка автосохранения: ${it.message}")}
    }

    val openFile=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri:Uri? ->
        if(uri!=null)runCatching {
            context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                ProjectCodec.decode(it.readText())
            }?:error("Не удалось прочитать файл")
        }.onSuccess{replaceLoaded(it);notify("Проект открыт")}
         .onFailure{notify("Ошибка импорта проекта: ${it.message}")}
    }
    val saveFile=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri:Uri? ->
        if(uri!=null)runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(ProjectCodec.encode(project))
            }?:error("Нет доступа к файлу")
        }.onSuccess{notify("Проект сохранён в файл")}
         .onFailure{notify("Ошибка экспорта: ${it.message}")}
    }

    Scaffold(topBar={
        Column {
            Row(Modifier.fillMaxWidth().padding(start=14.dp,end=12.dp,top=12.dp),
                horizontalArrangement=Arrangement.SpaceBetween) {
                Column {
                    Text("Mobile BIM",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                    Text(project.name,style=MaterialTheme.typography.labelMedium)
                }
                Text("v0.8",style=MaterialTheme.typography.labelMedium)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp),
                horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick={newDialog=true}){Text("Новый")}
                OutlinedButton(onClick={demoDialog=true}){Text("Пример")}
                OutlinedButton(onClick={openFile.launch(arrayOf("application/json","text/plain","*/*"))}) {
                    Text("Открыть")
                }
                Button(onClick={saveFile.launch(project.name.replace(
                    Regex("[^a-zA-Zа-яА-Я0-9_-]"),"_")+".mbim.json")}){Text("Сохранить файл")}
                OutlinedButton(onClick={renameDialog=true}){Text("Название")}
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp),
                horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                FilterChip(selected=!show3D&&!showSection,
                    onClick={show3D=false;showSection=false},label={Text("План")})
                FilterChip(selected=show3D,onClick={show3D=true;showSection=false;changeTool(EditorTool.SELECT)},
                    label={Text("3D")})
                FilterChip(selected=showSection,
                    enabled=project.sections.isNotEmpty(),
                    onClick={showSection=true;show3D=false;changeTool(EditorTool.SELECT)},
                    label={Text("Разрез")})
                if(showSection) {
                    var cutMenu by remember{mutableStateOf(false)}
                    Box {
                        OutlinedButton(onClick={cutMenu=true}){Text((selectedSection?.name?:"Выбор разреза")+" ▾")}
                        DropdownMenu(expanded=cutMenu,onDismissRequest={cutMenu=false}) {
                            project.sections.forEach {cut->
                                DropdownMenuItem(text={Text(cut.name)},onClick={
                                    selectedSectionId=cut.id;cutMenu=false
                                })
                            }
                        }
                    }
                    FilterChip(selected=sectionHatches,onClick={sectionHatches=!sectionHatches},
                        label={Text("Штриховки")})
                    FilterChip(selected=sectionDimensions,onClick={sectionDimensions=!sectionDimensions},
                        label={Text("Размеры")})
                    OutlinedButton(onClick={selectedSection?.let{cut->
                        tryEdit({project.copy(sections=project.sections.filterNot{it.id==cut.id})},
                            {showSection=false;selectedSectionId=null})
                    }}){Text("Удалить разрез")}
                }
                Box {
                    OutlinedButton(onClick={levelMenu=true}){Text(selectedLevel.name+" ▾")}
                    DropdownMenu(expanded=levelMenu,onDismissRequest={levelMenu=false}) {
                        project.levels.forEach {level ->
                            DropdownMenuItem(text={Text("${level.name} (${level.elevationMm.toInt()} мм)")},
                                onClick={currentLevelId=level.id;clearSelection()
                                    startPoint=null;slabPoints=emptyList();cadPoints=emptyList();levelMenu=false})
                        }
                    }
                }
                OutlinedButton(onClick={levelDialog=true}){Text("+ Этаж")}
            }
            if(!show3D && !showSection) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=8.dp),
                    horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected=tool==EditorTool.SELECT,onClick={changeTool(EditorTool.SELECT)},label={Text("Выбор")})
                    FilterChip(selected=tool==EditorTool.WALL,onClick={changeTool(EditorTool.WALL)},label={Text("Стена")})
                    FilterChip(selected=tool==EditorTool.DOOR,onClick={changeTool(EditorTool.DOOR)},label={Text("Дверь")})
                    FilterChip(selected=tool==EditorTool.WINDOW,onClick={changeTool(EditorTool.WINDOW)},label={Text("Окно")})
                    FilterChip(selected=tool==EditorTool.SLAB,onClick={changeTool(EditorTool.SLAB)},label={Text("Перекрытие")})
                    FilterChip(selected=tool==EditorTool.LINE,onClick={changeTool(EditorTool.LINE)},label={Text("Линия 2D")})
                    FilterChip(selected=tool==EditorTool.POLYLINE,onClick={changeTool(EditorTool.POLYLINE)},label={Text("Полилиния")})
                    FilterChip(selected=tool==EditorTool.CIRCLE,onClick={changeTool(EditorTool.CIRCLE)},label={Text("Окружность")})
                    FilterChip(selected=tool==EditorTool.ARC,onClick={changeTool(EditorTool.ARC)},label={Text("Дуга")})
                    OutlinedButton(onClick={layersDialog=true}){Text("Слои 2D")}
                    OutlinedButton(onClick={wallTypesDialog=true}){Text("Типы стен")}
                    Box {
                        var layerMenu by remember{mutableStateOf(false)}
                        OutlinedButton(onClick={layerMenu=true}){Text("Слой: $activeLayer ▾")}
                        DropdownMenu(expanded=layerMenu,onDismissRequest={layerMenu=false}) {
                            project.draftLayers.forEach {layer ->
                                DropdownMenuItem(text={Text(layer.name+if(layer.locked)" 🔒" else "")},
                                    enabled=!layer.locked,onClick={activeLayer=layer.name;layerMenu=false})
                            }
                        }
                    }
                    Box {
                        var typeMenu by remember{mutableStateOf(false)}
                        OutlinedButton(onClick={typeMenu=true}){Text("Стена: "+
                            (project.wallTypes.firstOrNull{it.id==activeWallTypeId}?.name?:"Свободная")+" ▾")}
                        DropdownMenu(expanded=typeMenu,onDismissRequest={typeMenu=false}) {
                            DropdownMenuItem(text={Text("Свободная (200 мм)")},onClick={activeWallTypeId=null;typeMenu=false})
                            project.wallTypes.forEach {type -> DropdownMenuItem(text={Text(type.name)},
                                onClick={activeWallTypeId=type.id;typeMenu=false}) }
                        }
                    }
                    FilterChip(selected=tool==EditorTool.DIMENSION,onClick={changeTool(EditorTool.DIMENSION)},label={Text("Размер")})
                    FilterChip(selected=tool==EditorTool.SECTION,onClick={changeTool(EditorTool.SECTION)},label={Text("Разрез: 2 точки")})
                    FilterChip(selected=snappingEnabled,onClick={snappingEnabled=!snappingEnabled},
                        label={Text(if(snappingEnabled)"Привязки ✓" else "Привязки —")})
                    FilterChip(selected=orthoEnabled,onClick={orthoEnabled=!orthoEnabled},
                        label={Text("Орто")})
                    if(tool==EditorTool.WALL && startPoint!=null) {
                        Button(onClick={drawByNumbers=true}){Text("Длина / угол")}
                        OutlinedButton(onClick={startPoint=null;wallStartSnap=null;snapMarker=null}){Text("Отмена линии")}
                    }
                    if((tool==EditorTool.LINE || tool==EditorTool.DIMENSION) && startPoint!=null) {
                        OutlinedButton(onClick={startPoint=null;wallStartSnap=null;snapMarker=null}) {Text("Отмена построения")}
                    }
                    if(tool==EditorTool.POLYLINE) {
                        Button(enabled=cadPoints.size>=2,onClick={tryEdit({CadEditing.addPolyline(
                            project,currentLevelId,cadPoints,activeLayer)},{cadPoints=emptyList()})}){
                            Text("Завершить полилинию")
                        }
                        Button(enabled=cadPoints.size>=3,onClick={tryEdit({CadEditing.addPolyline(
                            project,currentLevelId,cadPoints,activeLayer,closed=true)},{cadPoints=emptyList()})}){
                            Text("Замкнуть")
                        }
                        OutlinedButton(enabled=cadPoints.isNotEmpty(),onClick={cadPoints=cadPoints.dropLast(1)}) {
                            Text("− Точка")
                        }
                    }
                    if(tool==EditorTool.ARC || tool==EditorTool.CIRCLE) {
                        OutlinedButton(enabled=cadPoints.isNotEmpty(),onClick={cadPoints=emptyList()}){Text("Отмена построения")}
                    }
                    if(tool==EditorTool.SLAB) {
                        Button(enabled=slabPoints.size>=3,onClick={
                            tryEdit({EditorEngine.addSlab(project,currentLevelId,slabPoints)},
                                {slabPoints=emptyList()})
                        }){Text("Завершить контур")}
                        OutlinedButton(enabled=slabPoints.isNotEmpty(),onClick={slabPoints=slabPoints.dropLast(1)}) {
                            Text("− Точка")
                        }
                    }
                    OutlinedButton(enabled=undo.isNotEmpty(),onClick={
                        redo=redo+project;project=undo.last();undo=undo.dropLast(1)
                        startPoint=null;wallStartSnap=null;snapMarker=null;slabPoints=emptyList();cadPoints=emptyList();clearSelection()
                    }){Text("↶")}
                    OutlinedButton(enabled=redo.isNotEmpty(),onClick={
                        undo=undo+project;project=redo.last();redo=redo.dropLast(1)
                        startPoint=null;wallStartSnap=null;snapMarker=null;slabPoints=emptyList();cadPoints=emptyList();clearSelection()
                    }){Text("↷")}
                }
            } else if(show3D) {
                Row(Modifier.padding(horizontal=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick={rotation=(rotation+45)%360}){Text("Повернуть 45°")}
                    Text("3D: послойная 2.5D-сетка",Modifier.padding(top=12.dp),
                        style=MaterialTheme.typography.labelSmall)
                }
            }
        }
    },bottomBar={
        Column {
            HorizontalDivider()
            if(!show3D&&!showSection&&tool==EditorTool.SELECT&&selectedOpening!=null) {
                Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(if(selectedOpening.kind==OpeningKind.DOOR)"Дверь" else "Окно",
                            style=MaterialTheme.typography.titleSmall)
                        Text("${selectedOpening.widthMm.toInt()} × ${selectedOpening.heightMm.toInt()} мм",
                            style=MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick={editOpeningDialog=true}){Text("Свойства")}
                    OutlinedButton(onClick={tryEdit({EditorEngine.deleteOpening(project,selectedOpening.id)},{clearSelection()})}){
                        Text("Удалить")
                    }
                }
            } else if(!show3D&&!showSection&&tool==EditorTool.SELECT&&selectedDimension!=null) {
                Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("Размер",style=MaterialTheme.typography.titleSmall)
                        Text("${PlanEditing.dimensionPoints(project,selectedDimension)?.third?.toInt() ?: 0} мм",
                            style=MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick={editDimensionDialog=true}){Text("Отступ")}
                    OutlinedButton(onClick={tryEdit({PlanEditing.deleteDimension(project,selectedDimension.id)},
                        {clearSelection()})}){Text("Удалить")}
                }
            } else if(!show3D&&!showSection&&tool==EditorTool.SELECT&&selectedCadHit!=null) {
                val hit=requireNotNull(selectedCadHit)
                val layerName=when(hit.kind) {
                    CadKind.POLYLINE -> project.polylines.firstOrNull{it.id==hit.id}?.layer
                    CadKind.CIRCLE -> project.circles.firstOrNull{it.id==hit.id}?.layer
                    CadKind.ARC -> project.arcs.firstOrNull{it.id==hit.id}?.layer
                    CadKind.LINE -> project.draftLines.firstOrNull{it.id==hit.id}?.layer
                } ?: "Чертёж"
                Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(when(hit.kind){CadKind.POLYLINE->"Полилиния";CadKind.CIRCLE->"Окружность";
                            CadKind.ARC->"Дуга";CadKind.LINE->"2D-линия"},style=MaterialTheme.typography.titleSmall)
                        Text("Слой: $layerName",style=MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick={cadEditDialog=true}){Text("Изменить")}
                    OutlinedButton(onClick={tryEdit({CadEditing.delete(project,hit)},{clearSelection()})}){Text("Удалить")}
                }
            } else if(!show3D&&!showSection&&tool==EditorTool.SELECT&&selectedDraftLine!=null) {
                Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("2D-линия",style=MaterialTheme.typography.titleSmall)
                        Text(selectedDraftLine.layer,style=MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick={tryEdit({PlanEditing.deleteDraftLine(project,selectedDraftLine.id)},
                        {clearSelection()})}){Text("Удалить")}
                }
            } else if(!show3D&&!showSection&&tool==EditorTool.SELECT&&selectedWall!=null) {
                Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("Стена · ${"%.2f".format(Locale.US,selectedWall.lengthMm/1000)} м",
                            style=MaterialTheme.typography.titleSmall)
                        Text("${selectedWall.thicknessMm.toInt()} × ${selectedWall.heightMm.toInt()} мм",
                            style=MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick={editWallDialog=true}){Text("Свойства")}
                    OutlinedButton(onClick={assignTypeDialog=true}){Text("Тип") }
                    OutlinedButton(onClick={tryEdit({EditorEngine.deleteWall(project,selectedWall.id)},{clearSelection()})}) {
                        Text("Удалить")
                    }
                }
            } else if(!show3D&&!showSection&&tool==EditorTool.SELECT&&selectedSlab!=null) {
                Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("Перекрытие · ${"%.2f".format(Locale.US,selectedSlab.areaMm2/1e6)} м²",
                            style=MaterialTheme.typography.titleSmall)
                        Text("Толщина ${selectedSlab.thicknessMm.toInt()} мм",style=MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick={editSlabDialog=true}){Text("Свойства")}
                    OutlinedButton(onClick={tryEdit({EditorEngine.deleteSlab(project,selectedSlab.id)},{clearSelection()})}) {
                        Text("Удалить")
                    }
                }
            } else {
                val info=if(show3D)"Триангулированная 2.5D-визуализация, не BRep" else if(showSection)
                    "Разрез вычисляется из модели; сечение отображает слои стен, проёмы и перекрытия"
                    else when(tool) {
                    EditorTool.SELECT -> "Перемещайте двери и окна вдоль стены; вершины и контур перекрытия доступны перетаскиванием"
                    EditorTool.WALL -> if(startPoint==null)"Стена: начало (привязка к оси/концу другой стены)" else "Стена: конец или «Длина / угол» для точного ввода"
                    EditorTool.DOOR -> "Дверь: коснитесь существующей стены (900 × 2100 мм)"
                    EditorTool.WINDOW -> "Окно: коснитесь стены (1200 × 1400 мм, подоконник 900 мм)"
                    EditorTool.SLAB -> "Перекрытие: укажите точки контура, затем «Завершить» (${slabPoints.size})"
                    EditorTool.LINE -> "2D: укажите начало и конец линии; линия не меняет BIM-геометрию"
                    EditorTool.POLYLINE -> "Полилиния: добавляйте вершины, затем завершите или замкните (${cadPoints.size})"
                    EditorTool.CIRCLE -> "Окружность: центр, затем точка радиуса"
                    EditorTool.ARC -> "Дуга против часовой стрелки: центр → начало → конец (${cadPoints.size}/3)"
                    EditorTool.DIMENSION -> "Размер: выберите две точки; к концам стен размеры привязываются автоматически"
                    EditorTool.SECTION -> "Разрез: коснитесь начала и конца линии сечения на плане"
                }
                Text(info,Modifier.padding(horizontal=12.dp,vertical=10.dp),
                    style=MaterialTheme.typography.labelSmall)
            }
        }
    }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if(show3D) IsoView(project,selectedWallId,selectedSlabId,rotation)
            else if(showSection && selectedSection!=null) SectionView(project,selectedSection,
                showHatches=sectionHatches,showDimensions=sectionDimensions)
            else PlanView(project,currentLevelId,tool,startPoint,slabPoints,cadPoints,
                selectedWallId,selectedOpeningId,selectedSlabId,
                selectedDraftLineId,selectedDimensionId,selectedCadHit,
                onDragEdit={next -> tryEdit({next})},snappingEnabled=snappingEnabled,
                snapMarker=snapMarker,sectionStart=if(tool==EditorTool.SECTION)startPoint else null,
                onTap={raw,tolerance ->
                    fun snapped(p:Point2):SnapResult = if(snappingEnabled)
                        WallEditing.snap(project,currentLevelId,p,tolerance)
                        else SnapResult(p,SnapKind.GRID)
                    when(tool) {
                        EditorTool.WALL -> {
                            val first=startPoint
                            if(first==null) {
                                val snap=snapped(raw)
                                startPoint=snap.point;wallStartSnap=snap;snapMarker=snap
                            } else {
                                var finish=raw
                                if(orthoEnabled) {
                                    finish=if(abs(raw.xMm-first.xMm)>=abs(raw.yMm-first.yMm))
                                        Point2(raw.xMm,first.yMm) else Point2(first.xMm,raw.yMm)
                                }
                                var snap=snapped(finish)
                                if(orthoEnabled && abs(snap.point.xMm-first.xMm)>0.001 &&
                                   abs(snap.point.yMm-first.yMm)>0.001) {
                                    snap=SnapResult(if(abs(finish.xMm-first.xMm)>=abs(finish.yMm-first.yMm))
                                        Point2(snap.point.xMm,first.yMm) else Point2(first.xMm,snap.point.yMm),
                                        SnapKind.GRID)
                                }
                                tryEdit({
                                    val type=project.wallTypes.firstOrNull{it.id==activeWallTypeId}
                                    val drawn=WallEditing.addSnappedWall(project,currentLevelId,
                                        wallStartSnap?:SnapResult(first,SnapKind.GRID),snap,
                                        thicknessMm=type?.thicknessMm?:200.0,typeId=type?.id)
                                    drawn
                                },{
                                    startPoint=null;wallStartSnap=null;snapMarker=snap
                                })
                            }
                        }
                        EditorTool.DOOR,EditorTool.WINDOW -> {
                            val wall=EditorEngine.nearestWall(project,currentLevelId,raw,tolerance)
                            if(wall==null)notify("Коснитесь стены для вставки проёма")
                            else tryEdit({EditorEngine.addOpening(project,wall.id,
                                if(tool==EditorTool.DOOR)OpeningKind.DOOR else OpeningKind.WINDOW,raw)})
                        }
                        EditorTool.SLAB -> {
                            val snap=snapped(raw)
                            snapMarker=snap
                            if(slabPoints.lastOrNull()!=snap.point)slabPoints=slabPoints+snap.point
                        }
                        EditorTool.POLYLINE -> {
                            val snap=snapped(raw);snapMarker=snap
                            if(cadPoints.lastOrNull()!=snap.point)cadPoints=cadPoints+snap.point
                        }
                        EditorTool.CIRCLE -> {
                            val snap=snapped(raw);snapMarker=snap
                            if(cadPoints.isEmpty())cadPoints=listOf(snap.point)
                            else tryEdit({
                                val c=cadPoints.first()
                                CadEditing.addCircle(project,currentLevelId,c,
                                    kotlin.math.hypot(c.xMm-snap.point.xMm,c.yMm-snap.point.yMm),activeLayer)
                            },{cadPoints=emptyList();snapMarker=null})
                        }
                        EditorTool.ARC -> {
                            val snap=snapped(raw);snapMarker=snap
                            if(cadPoints.size<2)cadPoints=cadPoints+snap.point
                            else tryEdit({CadEditing.addArcByPoints(project,currentLevelId,
                                cadPoints[0],cadPoints[1],snap.point,activeLayer)},
                                {cadPoints=emptyList();snapMarker=null})
                        }
                        EditorTool.LINE, EditorTool.DIMENSION -> {
                            val snap=snapped(raw)
                            snapMarker=snap
                            if(startPoint==null) {
                                startPoint=snap.point;wallStartSnap=snap
                            } else {
                                val a=requireNotNull(startPoint)
                                tryEdit({if(tool==EditorTool.LINE)
                                    PlanEditing.addDraftLine(project,currentLevelId,a,snap.point,activeLayer)
                                    else PlanEditing.addDimension(project,currentLevelId,
                                        wallStartSnap?:SnapResult(a,SnapKind.GRID),snap)}, {
                                    startPoint=null;wallStartSnap=null;snapMarker=null
                                })
                            }
                        }
                        EditorTool.SECTION -> {
                            val snap=snapped(raw)
                            val first=startPoint
                            if(first==null){startPoint=snap.point;snapMarker=snap}
                            else {
                                val cut=runCatching{SectionCut(levelId=currentLevelId,
                                    name="Разрез ${project.sections.size+1}",start=first,end=snap.point)}
                                cut.onSuccess{section->tryEdit({project.copy(sections=project.sections+section)}, {
                                    startPoint=null;snapMarker=null;selectedSectionId=section.id
                                    show3D=false;showSection=true;changeTool(EditorTool.SELECT)
                                })}.onFailure {notify(it.message?:"Неверная линия разреза")}
                            }
                        }
                        EditorTool.SELECT -> {
                            snapMarker=null
                            val hitTolerance=tolerance.coerceAtMost(200.0)
                            val d=PlanEditing.nearestDimension(project,currentLevelId,raw,hitTolerance)
                            val o=if(d==null)EditorEngine.nearestOpening(project,currentLevelId,raw,hitTolerance) else null
                            val w=if(d==null&&o==null)EditorEngine.nearestWall(project,currentLevelId,raw,hitTolerance) else null
                            val cad=if(d==null&&o==null&&w==null)
                                CadEditing.nearest(project,currentLevelId,raw,hitTolerance) else null
                            val s=if(d==null&&o==null&&w==null&&cad==null)
                                EditorEngine.nearestSlab(project,currentLevelId,raw) else null
                            selectedDimensionId=d?.id;selectedOpeningId=o?.id
                            selectedWallId=w?.id;selectedDraftLineId=null
                            selectedCadHit=cad;selectedSlabId=s?.id
                        }
                    }
                })
        }
    }

    if(layersDialog) LayersDialog(project,onDismiss={layersDialog=false},onUpdate={next ->
        tryEdit({next})
    })
    if(wallTypesDialog) WallTypesDialog(project,onDismiss={wallTypesDialog=false},onUpdate={next ->
        tryEdit({next})
    })
    if(assignTypeDialog && selectedWall!=null) AssignWallTypeDialog(project,selectedWall,
        onDismiss={assignTypeDialog=false},onAssign={typeId ->
            tryEdit({if(typeId==null)WallTypes.detach(project,selectedWall.id)
                else WallTypes.assign(project,selectedWall.id,typeId)},{assignTypeDialog=false})
        })
    if(cadEditDialog && selectedCadHit!=null) CadEditDialog(project,requireNotNull(selectedCadHit),
        onDismiss={cadEditDialog=false},onSave={next ->
            tryEdit({next},{cadEditDialog=false})
        })
    if(editWallDialog && selectedWall!=null) EditWallDialog(selectedWall,onDismiss={editWallDialog=false}){
        t,h,m,start,length,angle ->
        tryEdit({
            val newGeometry=WallEditing.setGeometry(project,selectedWall.id,start,length,angle)
            EditorEngine.changeWall(newGeometry,selectedWall.id,t,h,m)
        },{editWallDialog=false})
    }
    if(drawByNumbers && startPoint!=null) DrawByNumbersDialog(onDismiss={drawByNumbers=false}) { length,angle ->
        val a=requireNotNull(startPoint)
        val radians=Math.toRadians(angle)
        val end=Point2(a.xMm+length*cos(radians),a.yMm+length*sin(radians))
        tryEdit({
            val type=project.wallTypes.firstOrNull{it.id==activeWallTypeId}
            val drawn=WallEditing.addSnappedWall(project,currentLevelId,
                wallStartSnap?:SnapResult(a,SnapKind.GRID),SnapResult(end,SnapKind.GRID),
                thicknessMm=type?.thicknessMm?:200.0,typeId=type?.id)
            drawn
        },{
            startPoint=null;wallStartSnap=null;snapMarker=null;drawByNumbers=false
        })
    }
    if(editOpeningDialog && selectedOpening!=null) EditOpeningDialog(selectedOpening,onDismiss={editOpeningDialog=false}){o,w,h,s ->
        tryEdit({EditorEngine.editOpening(project,selectedOpening.id,o,w,h,s)},{editOpeningDialog=false})
    }
    if(editSlabDialog && selectedSlab!=null) EditSlabDialog(selectedSlab,onDismiss={editSlabDialog=false}){t,m ->
        tryEdit({EditorEngine.changeSlab(project,selectedSlab.id,t,m)},{editSlabDialog=false})
    }
    if(editDimensionDialog && selectedDimension!=null) {
        var offset by remember(selectedDimension.id){mutableStateOf(selectedDimension.offsetMm.toInt().toString())}
        AlertDialog(onDismissRequest={editDimensionDialog=false},title={Text("Отступ размерной линии")},
            text={DecimalField(offset,{offset=it},"Отступ от измеряемой линии, мм")},
            confirmButton={TextButton(onClick={
                offset.asNumber()?.let { value ->
                    tryEdit({PlanEditing.changeDimensionOffset(project,selectedDimension.id,value)},
                        {editDimensionDialog=false})
                }
            }){Text("Применить")}},
            dismissButton={TextButton(onClick={editDimensionDialog=false}){Text("Отмена")}})
    }
    if(levelDialog) LevelDialog(onDismiss={levelDialog=false}){name,e ->
        tryEdit({EditorEngine.addLevel(project,name,e)},{currentLevelId=project.levels.last().id
            levelDialog=false})
    }
    if(renameDialog) {
        var name by remember(project.id){mutableStateOf(project.name)}
        AlertDialog(onDismissRequest={renameDialog=false},title={Text("Имя проекта")},
            text={OutlinedTextField(name,onValueChange={name=it},label={Text("Название")})},
            confirmButton={TextButton(onClick={
                if(name.isNotBlank()){commit(project.copy(name=name.trim()));renameDialog=false}
            }){Text("Сохранить")}},
            dismissButton={TextButton(onClick={renameDialog=false}){Text("Отмена")}})
    }
    if(newDialog) AlertDialog(onDismissRequest={newDialog=false},title={Text("Создать новый проект?")},
        text={Text("Автосохранённый черновик заменится. При необходимости сначала сохраните проект в файл.")},
        confirmButton={TextButton(onClick={replaceLoaded(BimProject());newDialog=false}){Text("Создать")}},
        dismissButton={TextButton(onClick={newDialog=false}){Text("Отмена")}})
    if(demoDialog) AlertDialog(onDismissRequest={demoDialog=false},title={Text("Открыть пример здания?")},
        text={Text("Текущий черновик будет заменён демонстрационным BIM-проектом.")},
        confirmButton={TextButton(onClick={replaceLoaded(createDemoProject());demoDialog=false}){Text("Открыть")}},
        dismissButton={TextButton(onClick={demoDialog=false}){Text("Отмена")}})
}

@Composable
private fun EditWallDialog(wall:Wall,onDismiss:()->Unit,
    onSave:(Double,Double,String,Point2,Double,Double)->Unit) {
    fun format(v:Double)=String.format(Locale.US,"%.4f",v)
    var t by remember(wall.id){mutableStateOf(format(wall.thicknessMm))}
    var h by remember(wall.id){mutableStateOf(format(wall.heightMm))}
    var m by remember(wall.id){mutableStateOf(wall.material)}
    var x by remember(wall.id){mutableStateOf(format(wall.start.xMm))}
    var y by remember(wall.id){mutableStateOf(format(wall.start.yMm))}
    var len by remember(wall.id){mutableStateOf(format(wall.lengthMm))}
    var angle by remember(wall.id){mutableStateOf(String.format(Locale.US,"%.7f",WallEditing.degrees(wall)))}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Геометрия и параметры стены")},
        text={Column(Modifier.heightIn(max=440.dp).verticalScroll(rememberScrollState()),
            verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text("Положение оси (мм) и направление относительно +X",style=MaterialTheme.typography.labelSmall)
            DecimalField(x,{x=it},"Начало X, мм")
            DecimalField(y,{y=it},"Начало Y, мм")
            DecimalField(len,{len=it},"Точная длина, мм")
            DecimalField(angle,{angle=it},"Угол, °")
            DecimalField(t,{t=it},"Толщина, мм")
            DecimalField(h,{h=it},"Высота, мм")
            OutlinedTextField(m,onValueChange={m=it},label={Text("Материал")},singleLine=true)
        }},confirmButton={TextButton(onClick={
            val nums=listOf(t,h,x,y,len,angle).map { it.asNumber() }
            if(nums.all{it!=null})onSave(nums[0]!!,nums[1]!!,m,
                Point2(nums[2]!!,nums[3]!!),nums[4]!!,nums[5]!!)
        }){Text("Применить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

@Composable
private fun DrawByNumbersDialog(onDismiss:()->Unit,onSave:(Double,Double)->Unit) {
    var length by remember{mutableStateOf("4000")}
    var angle by remember{mutableStateOf("0")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Стена по размеру")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            DecimalField(length,{length=it},"Длина, мм")
            DecimalField(angle,{angle=it},"Угол относительно оси X, °")
        }},confirmButton={TextButton(onClick={
            val l=length.asNumber();val a=angle.asNumber()
            if(l!=null&&a!=null)onSave(l,a)
        }){Text("Построить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

@Composable
private fun EditOpeningDialog(o:Opening,onDismiss:()->Unit,
                              onSave:(Double,Double,Double,Double)->Unit) {
    var offset by remember(o.id){mutableStateOf(o.offsetMm.toInt().toString())}
    var width by remember(o.id){mutableStateOf(o.widthMm.toInt().toString())}
    var height by remember(o.id){mutableStateOf(o.heightMm.toInt().toString())}
    var sill by remember(o.id){mutableStateOf(o.sillMm.toInt().toString())}
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(o.kind==OpeningKind.DOOR)"Дверь" else "Окно")},
        text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
            DecimalField(offset,{offset=it},"От начала стены, мм")
            DecimalField(width,{width=it},"Ширина, мм")
            DecimalField(height,{height=it},"Высота, мм")
            if(o.kind==OpeningKind.WINDOW)DecimalField(sill,{sill=it},"Подоконник, мм")
            else Text("Отметка низа двери: 0 мм",style=MaterialTheme.typography.bodySmall)
        }},confirmButton={TextButton(onClick={
            val a=offset.asNumber();val b=width.asNumber();val c=height.asNumber()
            val d=if(o.kind==OpeningKind.DOOR)0.0 else sill.asNumber()
            if(a!=null&&b!=null&&c!=null&&d!=null)onSave(a,b,c,d)
        }){Text("Применить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

@Composable
private fun EditSlabDialog(slab:Slab,onDismiss:()->Unit,onSave:(Double,String)->Unit) {
    var t by remember(slab.id){mutableStateOf(slab.thicknessMm.toInt().toString())}
    var m by remember(slab.id){mutableStateOf(slab.material)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Перекрытие")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            DecimalField(t,{t=it},"Толщина, мм")
            OutlinedTextField(m,onValueChange={m=it},label={Text("Материал")},singleLine=true)
        }},confirmButton={TextButton(onClick={t.asNumber()?.let{onSave(it,m)}}){Text("Применить")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

@Composable
private fun LevelDialog(onDismiss:()->Unit,onSave:(String,Double)->Unit) {
    var name by remember{mutableStateOf("Этаж 2")}
    var elevation by remember{mutableStateOf("3300")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Новый этаж")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name,onValueChange={name=it},label={Text("Название")})
            DecimalField(elevation,{elevation=it},"Отметка, мм")
        }},confirmButton={TextButton(onClick={
            val e=elevation.asNumber();if(name.isNotBlank()&&e!=null)onSave(name,e)
        }){Text("Создать")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

@Composable
private fun DecimalField(value:String,onChange:(String)->Unit,title:String) {
    OutlinedTextField(value,onValueChange=onChange,label={Text(title)},singleLine=true,
        keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
}
private fun String.asNumber():Double?=replace(',','.').toDoubleOrNull()

private fun createDemoProject():BimProject {
    var p=BimProject(name="Демонстрационный дом")
    val level=p.levels.first().id
    p=WallTypes.create(p,"Кирпичная 200",listOf(
        WallLayer("Штукатурка",20.0,10),WallLayer("Кирпич",160.0,100),WallLayer("Штукатурка",20.0,10)))
    val v=listOf(Point2(-3000.0,-2300.0),Point2(3000.0,-2300.0),
        Point2(3000.0,2300.0),Point2(-3000.0,2300.0))
    p=EditorEngine.addSlab(p,level,v)
    // Separate L-shaped slab demonstrates correct concave-polygon triangulation.
    p=EditorEngine.addSlab(p,level,listOf(Point2(4800.0,-2300.0),
        Point2(7600.0,-2300.0),Point2(7600.0,-1200.0),
        Point2(6000.0,-1200.0),Point2(6000.0,200.0),Point2(4800.0,200.0)))
    for(i in v.indices) {
        p=EditorEngine.addWall(p,level,v[i],v[(i+1)%v.size])
        p=WallTypes.assign(p,p.walls.last().id,p.wallTypes.first().id)
    }
    p=EditorEngine.addOpening(p,p.walls[0].id,OpeningKind.DOOR,Point2(0.0,-2300.0))
    p=EditorEngine.addOpening(p,p.walls[1].id,OpeningKind.WINDOW,Point2(3000.0,0.0))
    p=EditorEngine.addOpening(p,p.walls[2].id,OpeningKind.WINDOW,Point2(0.0,2300.0))
    // A T-junction to demonstrate actual parameterized attachment.
    p=WallEditing.addSnappedWall(p,level,
        WallEditing.snap(p,level,Point2(-1300.0,-2300.0),60.0),
        SnapResult(Point2(-1300.0,800.0),SnapKind.GRID))
    p=PlanEditing.addDraftLine(p,level,Point2(-2500.0,-1800.0),Point2(1800.0,1200.0))
    p=CadEditing.addLayer(p,"Мебель 2D")
    p=CadEditing.addPolyline(p,level,listOf(Point2(600.0,-1400.0),Point2(1800.0,-1400.0),
        Point2(1800.0,-200.0),Point2(600.0,-200.0)),"Мебель 2D",closed=true)
    p=CadEditing.addCircle(p,level,Point2(-2000.0,1200.0),350.0)
    p=CadEditing.addArcByPoints(p,level,Point2(600.0,1600.0),Point2(1150.0,1600.0),
        Point2(325.0,2076.314))
    p=PlanEditing.addDimension(p,level,
        SnapResult(v[0],SnapKind.WALL_ENDPOINT,p.walls[0].id,0.0),
        SnapResult(v[1],SnapKind.WALL_ENDPOINT,p.walls[0].id,1.0),-600.0)
    p=p.copy(sections=p.sections+SectionCut(levelId=level,name="Разрез 1-1",
        start=Point2(-3600.0,-2300.0),end=Point2(3600.0,-2300.0)))
    return p
}
