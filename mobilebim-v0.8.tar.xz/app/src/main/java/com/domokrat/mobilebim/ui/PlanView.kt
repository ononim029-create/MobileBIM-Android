package com.domokrat.mobilebim.ui

import android.graphics.Paint as NativePaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.sp
import com.domokrat.mobilebim.core.*
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.hypot

private const val BASE_PX_PER_MM=0.05f
private val wallColor=Color(0xFF43576D)
private val selectColor=Color(0xFF008F77)
private val slabColor=Color(0xFFD9E8F1)
private val windowColor=Color(0xFF1598CC)

private fun toScreen(p:Point2,w:Float,h:Float,cx:Double,cy:Double,s:Float)=
    Offset(w/2+((p.xMm-cx)*s).toFloat(),h/2-((p.yMm-cy)*s).toFloat())
private fun toWorld(p:Offset,w:Float,h:Float,cx:Double,cy:Double,s:Float)=
    Point2(cx+(p.x-w/2)/s,cy-(p.y-h/2)/s)

/** 2D plan: continuous geometry in mm; input is always interpreted on the active level. */
@Composable
fun PlanView(project:BimProject,levelId:String,tool:EditorTool,
             startPoint:Point2?,slabPoints:List<Point2>,cadPoints:List<Point2>,
             selectedWallId:String?,selectedOpeningId:String?,selectedSlabId:String?,
             selectedDraftLineId:String?,selectedDimensionId:String?,selectedCadHit:CadHit?,
             onTap:(Point2,Double)->Unit,
             onDragEdit:(BimProject)->Unit,
             snappingEnabled:Boolean=true,
             snapMarker:SnapResult?=null,
             sectionStart:Point2?=null,
             modifier:Modifier=Modifier) {
    val projectState=rememberUpdatedState(project)
    val tapState=rememberUpdatedState(onTap)
    val dragCommitState=rememberUpdatedState(onDragEdit)
    val preview=remember { mutableStateOf<BimProject?>(null) }
    val zoom=remember{mutableFloatStateOf(1f)}
    val cx=remember{mutableDoubleStateOf(0.0)}
    val cy=remember{mutableDoubleStateOf(0.0)}
    Canvas(modifier.fillMaxSize()
        .pointerInput(tool,levelId) {
            detectTapGestures { off ->
                val scale=BASE_PX_PER_MM*zoom.floatValue
                val p=toWorld(off,size.width.toFloat(),size.height.toFloat(),
                    cx.doubleValue,cy.doubleValue,scale)
                val tolerance=(14.0/scale).coerceIn(50.0,350.0)
                tapState.value(p,tolerance)
            }
        }
        .pointerInput(tool,levelId,selectedWallId,selectedOpeningId,selectedSlabId,selectedCadHit,snappingEnabled) {
            var gestureCad: CadHit? = null
            var gestureCadVertex: Int? = null
            var gestureWallId: String? = null
            var gestureOpeningId: String? = null
            var gestureSlabId: String? = null
            var gestureVertex: Int? = null
            var openingCenter: Point2? = null
            var gestureEnd: WallEnd? = null
            var gestureBody = false
            var origin: Point2? = null
            var base: BimProject? = null
            detectDragGestures(onDragStart={ off ->
                preview.value=null
                gestureWallId=null;gestureOpeningId=null;gestureSlabId=null
                gestureCad=null;gestureCadVertex=null
                gestureVertex=null;gestureEnd=null;gestureBody=false
                val initial=projectState.value
                val s=BASE_PX_PER_MM*zoom.floatValue
                val world=toWorld(off,size.width.toFloat(),size.height.toFloat(),
                    cx.doubleValue,cy.doubleValue,s)
                if(tool==EditorTool.SELECT) {
                    val cad=selectedCadHit
                    if(cad!=null && cad.kind==CadKind.POLYLINE) {
                        val poly=initial.polylines.firstOrNull{it.id==cad.id && it.levelId==levelId}
                        if(poly!=null) {
                            val idx=poly.vertices.indices.minByOrNull { i ->
                                (off-toScreen(poly.vertices[i],size.width.toFloat(),size.height.toFloat(),
                                    cx.doubleValue,cy.doubleValue,s)).getDistance()
                            }
                            if(idx!=null && (off-toScreen(poly.vertices[idx],size.width.toFloat(),
                                size.height.toFloat(),cx.doubleValue,cy.doubleValue,s)).getDistance()<30f) {
                                gestureCad=cad;gestureCadVertex=idx
                            }
                        }
                    }
                    if(gestureCad==null && cad!=null && CadEditing.nearest(initial,levelId,world,
                            (22.0/s).coerceAtMost(400.0))==cad) gestureCad=cad
                    if(gestureCad!=null){base=initial;origin=world}
                    val o=if(gestureCad==null)initial.openings.firstOrNull{it.id==selectedOpeningId}
                    if(o!=null) {
                        val middle=PlanEditing.openingCenter(initial,o)
                        if((off-toScreen(middle,size.width.toFloat(),size.height.toFloat(),
                            cx.doubleValue,cy.doubleValue,s)).getDistance()<32f) {
                            gestureOpeningId=o.id;openingCenter=middle
                        }
                    }
                    if(gestureOpeningId==null && gestureCad==null) {
                        val slab=initial.slabs.firstOrNull{it.id==selectedSlabId && it.levelId==levelId}
                        if(slab!=null) {
                            val index=slab.vertices.indices.minByOrNull{ i ->
                                (off-toScreen(slab.vertices[i],size.width.toFloat(),size.height.toFloat(),
                                    cx.doubleValue,cy.doubleValue,s)).getDistance()
                            }
                            if(index!=null && (off-toScreen(slab.vertices[index],size.width.toFloat(),
                                size.height.toFloat(),cx.doubleValue,cy.doubleValue,s)).getDistance()<32f) {
                                gestureSlabId=slab.id;gestureVertex=index
                            } else if(Geometry.containsPolygonPoint(slab.vertices,world)) {
                                gestureSlabId=slab.id
                            }
                        }
                    }
                    if(gestureOpeningId!=null || gestureSlabId!=null) {
                        base=initial;origin=world
                    }
                }
                val selected=initial.walls.firstOrNull {
                    tool==EditorTool.SELECT && it.id==selectedWallId && it.levelId==levelId
                }
                if(selected!=null && gestureOpeningId==null && gestureSlabId==null && gestureCad==null) {
                    val s=BASE_PX_PER_MM*zoom.floatValue
                    val a=toScreen(selected.start,size.width.toFloat(),size.height.toFloat(),
                        cx.doubleValue,cy.doubleValue,s)
                    val b=toScreen(selected.end,size.width.toFloat(),size.height.toFloat(),
                        cx.doubleValue,cy.doubleValue,s)
                    if((off-a).getDistance()<28f) gestureEnd=WallEnd.START
                    else if((off-b).getDistance()<28f) gestureEnd=WallEnd.END
                    else {
                        val world=toWorld(off,size.width.toFloat(),size.height.toFloat(),
                            cx.doubleValue,cy.doubleValue,s)
                        gestureBody=EditorEngine.pointToSegmentDistance(world,
                            selected.start,selected.end)*s<22f
                    }
                    if(gestureEnd!=null || gestureBody) {
                        gestureWallId=selected.id
                        base=projectState.value
                        origin=toWorld(off,size.width.toFloat(),size.height.toFloat(),
                            cx.doubleValue,cy.doubleValue,s)
                    }
                }
            },onDragEnd={
                preview.value?.let { dragCommitState.value(it) }
                preview.value=null
                gestureWallId=null;gestureOpeningId=null;gestureSlabId=null;gestureCad=null
                origin=null;base=null
            },onDragCancel={
                preview.value=null;gestureWallId=null;gestureOpeningId=null;gestureSlabId=null;gestureCad=null
                origin=null;base=null
            }) { change,_ ->
                val original=base
                if(original!=null && (gestureWallId!=null || gestureOpeningId!=null || gestureSlabId!=null || gestureCad!=null)) {
                    change.consume()
                    val s=BASE_PX_PER_MM*zoom.floatValue
                    val target=toWorld(change.position,size.width.toFloat(),size.height.toFloat(),
                        cx.doubleValue,cy.doubleValue,s)
                    val anchor=requireNotNull(origin)
                    val rawDelta=Point2(target.xMm-anchor.xMm,target.yMm-anchor.yMm)
                    val delta=if(snappingEnabled)EditorEngine.snap(rawDelta) else rawDelta
                    val edit=runCatching {
                        when {
                            gestureCad!=null && gestureCadVertex!=null -> {
                                val hit=requireNotNull(gestureCad)
                                val poly=original.polylines.first{it.id==hit.id}
                                val idx=requireNotNull(gestureCadVertex)
                                val old=poly.vertices[idx]
                                val moved=Point2(old.xMm+delta.xMm,old.yMm+delta.yMm)
                                require(original.draftLayers.any{it.name==poly.layer && !it.locked})
                                original.copy(polylines=original.polylines.map {
                                    if(it.id==poly.id)it.copy(vertices=it.vertices.mapIndexed {i,p ->
                                        if(i==idx)moved else p
                                    }) else it
                                })
                            }
                            gestureCad!=null -> CadEditing.move(original,requireNotNull(gestureCad),
                                delta.xMm,delta.yMm)
                            gestureOpeningId!=null -> {
                                val center=requireNotNull(openingCenter)
                                PlanEditing.moveOpeningCenter(original,requireNotNull(gestureOpeningId),
                                    Point2(center.xMm+rawDelta.xMm,center.yMm+rawDelta.yMm))
                            }
                            gestureSlabId!=null && gestureVertex!=null -> {
                                val slab=original.slabs.first{it.id==gestureSlabId}
                                val old=slab.vertices[requireNotNull(gestureVertex)]
                                val point=Point2(old.xMm+delta.xMm,old.yMm+delta.yMm)
                                PlanEditing.moveSlabVertex(original,requireNotNull(gestureSlabId),
                                    requireNotNull(gestureVertex),point)
                            }
                            gestureSlabId!=null -> PlanEditing.translateSlab(original,
                                requireNotNull(gestureSlabId),delta.xMm,delta.yMm)
                            gestureBody -> WallEditing.translateWall(original,
                                requireNotNull(gestureWallId),delta.xMm,delta.yMm)
                            else -> WallEditing.moveEndpoint(original,requireNotNull(gestureWallId),
                                requireNotNull(gestureEnd),target,
                                (14.0/s).coerceIn(50.0,350.0),snappingEnabled)
                        }
                    }.getOrNull()
                    if(edit!=null)preview.value=edit
                }
            }
        }
        .pointerInput(Unit) {
            detectTransformGestures { centroid,pan,zoomChange,_ ->
                val before=toWorld(centroid,size.width.toFloat(),size.height.toFloat(),
                    cx.doubleValue,cy.doubleValue,BASE_PX_PER_MM*zoom.floatValue)
                zoom.floatValue=(zoom.floatValue*zoomChange).coerceIn(0.15f,8f)
                val s=BASE_PX_PER_MM*zoom.floatValue
                cx.doubleValue=before.xMm-(centroid.x+pan.x-size.width/2f)/s
                cy.doubleValue=before.yMm+(centroid.y+pan.y-size.height/2f)/s
            }
        }
    ) {
        val s=BASE_PX_PER_MM*zoom.floatValue
        val projectNow=preview.value ?: projectState.value
        fun screen(p:Point2)=toScreen(p,size.width,size.height,cx.doubleValue,cy.doubleValue,s)
        drawRect(Color(0xFFFAFCFF))
        val upper=toWorld(Offset.Zero,size.width,size.height,cx.doubleValue,cy.doubleValue,s)
        val lower=toWorld(Offset(size.width,size.height),size.width,size.height,cx.doubleValue,cy.doubleValue,s)
        val step=if(s>=0.045f)500.0 else 1000.0
        val ix0=floor(min(upper.xMm,lower.xMm)/step).toInt()
        val ix1=ceil(max(upper.xMm,lower.xMm)/step).toInt()
        val iy0=floor(min(upper.yMm,lower.yMm)/step).toInt()
        val iy1=ceil(max(upper.yMm,lower.yMm)/step).toInt()
        if(ix1-ix0<200 && iy1-iy0<200) {
            for(i in ix0..ix1) {
                val x=screen(Point2(i*step,0.0)).x
                drawLine(Color(0xFFE6ECF2),Offset(x,0f),Offset(x,size.height),1f)
            }
            for(i in iy0..iy1) {
                val y=screen(Point2(0.0,i*step)).y
                drawLine(Color(0xFFE6ECF2),Offset(0f,y),Offset(size.width,y),1f)
            }
        }
        val paint=NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply {
            color=android.graphics.Color.rgb(44,65,86)
            textSize=12.sp.toPx()
            textAlign=NativePaint.Align.CENTER
        }
        projectNow.slabs.filter{it.levelId==levelId}.forEach { slab ->
            val path=Path()
            slab.vertices.map(::screen).forEachIndexed { index,p ->
                if(index==0) path.moveTo(p.x,p.y) else path.lineTo(p.x,p.y)
            }
            path.close()
            drawPath(path,if(slab.id==selectedSlabId)Color(0xFF94D9CC) else slabColor)
            drawPath(path,Color(0xFF6A879F),style=Stroke(width=2f))
            val p=screen(Point2(slab.vertices.map{it.xMm}.average(),slab.vertices.map{it.yMm}.average()))
            drawContext.canvas.nativeCanvas.drawText(
                String.format(java.util.Locale.US,"%.2f м²",slab.areaMm2/1e6),p.x,p.y,paint)
        }
        val visibleLayers=projectNow.draftLayers.filter { it.visible }.map{it.name}.toSet()
        projectNow.draftLines.filter{it.levelId==levelId && it.layer in visibleLayers}.forEach { line ->
            drawLine(if(line.id==selectedCadHit?.id || line.id==selectedDraftLineId)selectColor
                else Color(0xFF8D549B),screen(line.start),screen(line.end),
                if(line.id==selectedCadHit?.id || line.id==selectedDraftLineId)4f else 2f)
        }
        projectNow.polylines.filter{it.levelId==levelId && it.layer in visibleLayers}.forEach { poly ->
            val pts=poly.vertices.map(::screen)
            val ink=if(selectedCadHit?.id==poly.id)selectColor else Color(0xFF7651A7)
            for(i in 1 until pts.size)drawLine(ink,pts[i-1],pts[i],if(selectedCadHit?.id==poly.id)4f else 2f)
            if(poly.closed)drawLine(ink,pts.last(),pts.first(),2f)
            if(selectedCadHit?.id==poly.id)pts.forEach { pt ->
                drawCircle(Color.White,8f,pt);drawCircle(selectColor,5f,pt)
            }
        }
        projectNow.circles.filter{it.levelId==levelId && it.layer in visibleLayers}.forEach{ c ->
            drawCircle(if(selectedCadHit?.id==c.id)selectColor else Color(0xFF7651A7),
                radius=(c.radiusMm*s).toFloat(),center=screen(c.center),
                style=Stroke(width=if(selectedCadHit?.id==c.id)4f else 2f))
            if(selectedCadHit?.id==c.id)drawCircle(selectColor,4f,screen(c.center))
        }
        projectNow.arcs.filter{it.levelId==levelId && it.layer in visibleLayers}.forEach { arc ->
            val ink=if(selectedCadHit?.id==arc.id)selectColor else Color(0xFF7651A7)
            val sections=max(4,(arc.sweepDeg/4.0).toInt())
            fun arcPoint(i:Int):Point2 {
                val r=Math.toRadians(arc.startDeg+arc.sweepDeg*i/sections)
                return Point2(arc.center.xMm+arc.radiusMm*cos(r),arc.center.yMm+arc.radiusMm*sin(r))
            }
            var prev=screen(arcPoint(0))
            for(i in 1..sections) {
                val now=screen(arcPoint(i))
                drawLine(ink,prev,now,if(selectedCadHit?.id==arc.id)4f else 2f)
                prev=now
            }
        }
        selectedSlabId?.let { id ->
            projectNow.slabs.firstOrNull { it.id==id && it.levelId==levelId }?.vertices?.forEach { point ->
                drawCircle(Color.White,10f,screen(point))
                drawCircle(selectColor,6f,screen(point))
            }
        }
        val wallMap=projectNow.walls.filter{it.levelId==levelId}.associateBy{it.id}
        val wallLayerColors=listOf(Color(0xFFD9D7CB),Color(0xFF93A9B8),
            Color(0xFFD0A98F),Color(0xFFB3B9A7),Color(0xFFD2C7B6),Color(0xFF9CB8B0))
        val solved=WallJoinSolver.resolve(projectNow,levelId)
        wallMap.values.forEach { wall ->
            // Deterministic priority-clipped layer pieces, instead of overlapping stripes.
            val footprints=solved.pieces.filter{it.wallId==wall.id}
            footprints.forEach { layer ->
                val corners=layer.polygon.map(::screen)
                val poly=Path().apply {
                    moveTo(corners[0].x,corners[0].y)
                    corners.drop(1).forEach {lineTo(it.x,it.y)}
                    close()
                }
                val tint=if(wall.id==selectedWallId)Color(0xFFB9E1D8)
                    else wallLayerColors[layer.layerIndex%wallLayerColors.size]
                drawPath(poly,tint)
                drawPath(poly,Color(0xFF526577),style=Stroke(width=0.7f))
            }
            if(wall.id==selectedWallId) footprints.forEach{layer->
                val border=Path().apply {
                    layer.polygon.map(::screen).forEachIndexed{i,p->
                        if(i==0)moveTo(p.x,p.y)else lineTo(p.x,p.y)
                    }
                    close()
                }
                drawPath(border,selectColor,style=Stroke(width=2.8f))
            }
            val a=screen(wall.start);val b=screen(wall.end)
            val m=Offset((a.x+b.x)/2f,(a.y+b.y)/2f-12f)
            drawContext.canvas.nativeCanvas.drawText(
                String.format(java.util.Locale.US,"%.2f м",wall.lengthMm/1000.0),m.x,m.y,paint)
        }
        projectNow.wallJoints.filter { it.guestWallId in wallMap }.forEach { joint ->
            val guest=wallMap[joint.guestWallId] ?: return@forEach
            val p=screen(if(joint.guestEnd==WallEnd.START)guest.start else guest.end)
            drawCircle(Color.White,6f,p)
            drawCircle(selectColor,4f,p)
        }
        // Mark unsupported complex junctions explicitly rather than hiding the limitation.
        solved.warnings.forEach { warning ->
            val node=warning.point
            val point=screen(node)
            drawCircle(Color(0xFFC95842),10f,point)
            drawContext.canvas.nativeCanvas.drawText("!",point.x,point.y+4f,
                NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply {
                    color=android.graphics.Color.WHITE
                    textSize=13.sp.toPx()
                    textAlign=NativePaint.Align.CENTER
                    isFakeBoldText=true
                })
        }
        // Existing vertical cutting planes and first-tap preview.
        projectNow.sections.filter{it.levelId==levelId}.forEach{section->
            drawLine(Color(0xFFC35A4E),screen(section.start),screen(section.end),2.8f)
            drawCircle(Color(0xFFC35A4E),6f,screen(section.start))
            drawCircle(Color(0xFFC35A4E),6f,screen(section.end))
        }
        sectionStart?.let{drawCircle(Color(0xFFC35A4E),9f,screen(it))}
        selectedWallId?.let { selected ->
            wallMap[selected]?.let { w ->
                listOf(w.start,w.end).forEach { pt ->
                    val p=screen(pt)
                    drawCircle(Color.White,10f,p)
                    drawCircle(selectColor,7f,p)
                    drawCircle(Color.White,3f,p)
                }
            }
        }
        projectNow.openings.forEach {o ->
            val wall=wallMap[o.wallId] ?: return@forEach
            val dx=(wall.end.xMm-wall.start.xMm)/wall.lengthMm
            val dy=(wall.end.yMm-wall.start.yMm)/wall.lengthMm
            fun place(along:Double)=screen(Point2(wall.start.xMm+dx*along,wall.start.yMm+dy*along))
            val a=place(o.offsetMm);val b=place(o.endMm)
            val mid=place(o.offsetMm+o.widthMm/2.0)
            val width=(wall.thicknessMm*s).coerceAtLeast(3f)
            drawLine(Color(0xFFFAFCFF),a,b,width+2f,cap=StrokeCap.Butt)
            val ink=if(o.id==selectedOpeningId)selectColor else
                if(o.kind==OpeningKind.WINDOW)windowColor else Color(0xFFA36D42)
            if(o.kind==OpeningKind.WINDOW) {
                drawLine(ink,a,b,4f)
                val ox=(-dy*wall.thicknessMm*0.3*s).toFloat()
                val oy=(-dx*wall.thicknessMm*0.3*s).toFloat()
                drawLine(ink,Offset(a.x+ox,a.y+oy),Offset(b.x+ox,b.y+oy),1.5f)
                drawLine(ink,Offset(a.x-ox,a.y-oy),Offset(b.x-ox,b.y-oy),1.5f)
            } else {
                val pivot=a
                val tip=Offset(pivot.x+(-dy*o.widthMm*s).toFloat(),pivot.y+(-dx*o.widthMm*s).toFloat())
                drawLine(ink,pivot,tip,2.5f)
                drawCircle(ink,3.5f,pivot)
            }
            if(o.id==selectedOpeningId)drawCircle(selectColor,5f,mid)
            drawLine(wallColor,Offset(a.x+(-dy*width/2f),a.y+(-dx*width/2f)),
                Offset(a.x-(-dy*width/2f),a.y-(-dx*width/2f)),1.5f)
            drawLine(wallColor,Offset(b.x+(-dy*width/2f),b.y+(-dx*width/2f)),
                Offset(b.x-(-dy*width/2f),b.y-(-dx*width/2f)),1.5f)
        }
        projectNow.dimensions.filter{it.levelId==levelId}.forEach { dim ->
            val points=PlanEditing.dimensionPoints(projectNow,dim) ?: return@forEach
            val (a,b,length)=points
            val pa=screen(a);val pb=screen(b)
            val start=screen(PlanEditing.resolvedAnchor(projectNow,dim.first))
            val finish=screen(PlanEditing.resolvedAnchor(projectNow,dim.second))
            val ink=if(dim.id==selectedDimensionId)selectColor else Color(0xFF7B4A7A)
            drawLine(ink,start,pa,1.5f);drawLine(ink,finish,pb,1.5f)
            drawLine(ink,pa,pb,2.2f)
            drawCircle(ink,3.8f,pa);drawCircle(ink,3.8f,pb)
            val mid=Offset((pa.x+pb.x)/2f,(pa.y+pb.y)/2f-7f)
            drawContext.canvas.nativeCanvas.drawText(
                String.format(java.util.Locale.US,"%.0f мм",length),mid.x,mid.y,paint)
        }
        snapMarker?.let { marker ->
            val p=screen(marker.point)
            drawCircle(if(marker.kind==SnapKind.GRID)Color(0xFF7F8EA0) else selectColor,
                8f,p,style=Stroke(width=2f))
        }
        startPoint?.let {p->drawCircle(selectColor,7f,screen(p));drawCircle(Color.White,3f,screen(p))}
        if(cadPoints.isNotEmpty()) {
            val pts=cadPoints.map(::screen)
            for(i in 1 until pts.size)drawLine(selectColor,pts[i-1],pts[i],2.5f)
            pts.forEach { drawCircle(selectColor,5f,it) }
        }
        if(slabPoints.isNotEmpty()) {
            val screenPts=slabPoints.map(::screen)
            for(i in 1 until screenPts.size)
                drawLine(selectColor,screenPts[i-1],screenPts[i],3f)
            screenPts.forEach {drawCircle(selectColor,5f,it)}
        }
        val start=Offset(18f,size.height-25f)
        drawLine(Color.DarkGray,start,Offset(start.x+1000f*s,start.y),3f)
        drawContext.canvas.nativeCanvas.drawText("1 м",start.x+500f*s,start.y-8f,paint)
    }
}
