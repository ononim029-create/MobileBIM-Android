package com.domokrat.mobilebim.ui

enum class EditorTool { SELECT, WALL, DOOR, WINDOW, SLAB, LINE, POLYLINE, CIRCLE, ARC, DIMENSION, SECTION }
