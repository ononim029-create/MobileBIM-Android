package com.domokrat.mobilebim.data

import android.content.Context
import com.domokrat.mobilebim.core.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Schema v6; reads v1 through v6 and retains historical IDs. */
object ProjectCodec {
    private fun pointJson(p:Point2) = JSONObject().apply {put("xMm",p.xMm);put("yMm",p.yMm)}
    private fun pointFromJson(data:JSONObject)=Point2(data.getDouble("xMm"),data.getDouble("yMm"))

    fun encode(project:BimProject):String = JSONObject().apply {
        put("schemaVersion",6);put("id",project.id);put("name",project.name);put("units","mm")
        put("levels",JSONArray().apply {
            project.levels.forEach { l -> put(JSONObject().apply {
                put("id",l.id);put("name",l.name);put("elevationMm",l.elevationMm)
            }) }
        })
        put("walls",JSONArray().apply {
            project.walls.forEach { w -> put(JSONObject().apply {
                put("id",w.id);put("levelId",w.levelId)
                put("start",pointJson(w.start));put("end",pointJson(w.end))
                put("thicknessMm",w.thicknessMm);put("heightMm",w.heightMm)
                put("material",w.material)
                if(w.typeId!=null) put("typeId",w.typeId)
            }) }
        })
        put("openings",JSONArray().apply {
            project.openings.forEach { o -> put(JSONObject().apply {
                put("id",o.id);put("wallId",o.wallId);put("kind",o.kind.name)
                put("offsetMm",o.offsetMm);put("widthMm",o.widthMm)
                put("sillMm",o.sillMm);put("heightMm",o.heightMm)
            }) }
        })
        put("wallJoints",JSONArray().apply {
            project.wallJoints.forEach { joint -> put(JSONObject().apply {
                put("guestWallId",joint.guestWallId);put("guestEnd",joint.guestEnd.name)
                put("hostWallId",joint.hostWallId);put("hostT",joint.hostT)
            }) }
        })
        put("draftLines",JSONArray().apply {
            project.draftLines.forEach { line -> put(JSONObject().apply {
                put("id",line.id);put("levelId",line.levelId)
                put("start",pointJson(line.start));put("end",pointJson(line.end))
                put("layer",line.layer)
            }) }
        })
        put("draftLayers",JSONArray().apply {
            project.draftLayers.forEach {l -> put(JSONObject().apply {
                put("name",l.name);put("visible",l.visible);put("locked",l.locked)
            })}
        })
        put("wallTypes",JSONArray().apply {
            project.wallTypes.forEach {t -> put(JSONObject().apply {
                put("id",t.id);put("name",t.name)
                put("layers",JSONArray().apply {t.layers.forEach { l -> put(JSONObject().apply {
                    put("material",l.material);put("thicknessMm",l.thicknessMm)
                    put("joinPriority",l.joinPriority)
                }) }})
            })}
        })
        put("sections",JSONArray().apply {
            project.sections.forEach{cut->put(JSONObject().apply {
                put("id",cut.id);put("levelId",cut.levelId);put("name",cut.name)
                put("start",pointJson(cut.start));put("end",pointJson(cut.end))
            })}
        })
        put("polylines",JSONArray().apply {
            project.polylines.forEach {poly -> put(JSONObject().apply {
                put("id",poly.id);put("levelId",poly.levelId);put("closed",poly.closed)
                put("layer",poly.layer)
                put("vertices",JSONArray().apply {poly.vertices.forEach {put(pointJson(it))}})
            })}
        })
        put("circles",JSONArray().apply {
            project.circles.forEach {c -> put(JSONObject().apply {
                put("id",c.id);put("levelId",c.levelId);put("center",pointJson(c.center))
                put("radiusMm",c.radiusMm);put("layer",c.layer)
            })}
        })
        put("arcs",JSONArray().apply {
            project.arcs.forEach {a -> put(JSONObject().apply {
                put("id",a.id);put("levelId",a.levelId);put("center",pointJson(a.center))
                put("radiusMm",a.radiusMm);put("startDeg",a.startDeg);put("sweepDeg",a.sweepDeg)
                put("layer",a.layer)
            })}
        })
        put("dimensions",JSONArray().apply {
            fun anchorJson(a:DimensionAnchor)=JSONObject().apply {
                put("point",pointJson(a.point))
                if(a.wallId!=null) {put("wallId",a.wallId);put("wallEnd",a.wallEnd!!.name)}
            }
            project.dimensions.forEach { dim -> put(JSONObject().apply {
                put("id",dim.id);put("levelId",dim.levelId)
                put("first",anchorJson(dim.first));put("second",anchorJson(dim.second))
                put("offsetMm",dim.offsetMm)
            }) }
        })
        put("slabs",JSONArray().apply {
            project.slabs.forEach { slab -> put(JSONObject().apply {
                put("id",slab.id);put("levelId",slab.levelId)
                put("vertices",JSONArray().apply {slab.vertices.forEach{put(pointJson(it))}})
                put("thicknessMm",slab.thicknessMm);put("material",slab.material)
            }) }
        })
    }.toString(2)

    fun decode(json:String):BimProject {
        val data=JSONObject(json)
        val version=data.getInt("schemaVersion")
        require(version in 1..6) {"Неподдерживаемая версия файла: $version"}
        require(data.getString("units")=="mm") {"Неизвестные единицы измерения"}
        val levelsJson=data.getJSONArray("levels")
        val wallsJson=data.getJSONArray("walls")
        require(levelsJson.length() in 1..1000)
        require(wallsJson.length()<=100000)
        val levels=(0 until levelsJson.length()).map { i ->
            val l=levelsJson.getJSONObject(i)
            Level(id=l.getString("id"),name=l.getString("name"),elevationMm=l.getDouble("elevationMm"))
        }
        val walls=(0 until wallsJson.length()).map { i ->
            val w=wallsJson.getJSONObject(i)
            Wall(id=w.getString("id"),levelId=w.getString("levelId"),
                start=pointFromJson(w.getJSONObject("start")),
                end=pointFromJson(w.getJSONObject("end")),
                thicknessMm=w.getDouble("thicknessMm"),heightMm=w.getDouble("heightMm"),
                material=w.optString("material",""),
                typeId=if(w.has("typeId"))w.getString("typeId") else null)
        }
        val openingsJson=data.optJSONArray("openings") ?: JSONArray()
        val slabsJson=data.optJSONArray("slabs") ?: JSONArray()
        require(openingsJson.length()<=100000 && slabsJson.length()<=10000)
        val openings=(0 until openingsJson.length()).map { i ->
            val o=openingsJson.getJSONObject(i)
            Opening(id=o.getString("id"),wallId=o.getString("wallId"),
                kind=OpeningKind.valueOf(o.getString("kind")),
                offsetMm=o.getDouble("offsetMm"),widthMm=o.getDouble("widthMm"),
                sillMm=o.getDouble("sillMm"),heightMm=o.getDouble("heightMm"))
        }
        val slabs=(0 until slabsJson.length()).map { i ->
            val s=slabsJson.getJSONObject(i)
            val verts=s.getJSONArray("vertices")
            require(verts.length() in 3..500)
            Slab(id=s.getString("id"),levelId=s.getString("levelId"),
                vertices=(0 until verts.length()).map{pointFromJson(verts.getJSONObject(it))},
                thicknessMm=s.getDouble("thicknessMm"),material=s.optString("material",""))
        }
        val jointsJson=data.optJSONArray("wallJoints") ?: JSONArray()
        require(jointsJson.length()<=200000)
        val joints=(0 until jointsJson.length()).map { i ->
            val j=jointsJson.getJSONObject(i)
            WallJoint(guestWallId=j.getString("guestWallId"),
                guestEnd=WallEnd.valueOf(j.getString("guestEnd")),
                hostWallId=j.getString("hostWallId"),hostT=j.getDouble("hostT"))
        }
        val draftJson=data.optJSONArray("draftLines") ?: JSONArray()
        val dimJson=data.optJSONArray("dimensions") ?: JSONArray()
        require(draftJson.length()<=200000 && dimJson.length()<=100000)
        val draftLines=(0 until draftJson.length()).map { i ->
            val line=draftJson.getJSONObject(i)
            DraftLine(id=line.getString("id"),levelId=line.getString("levelId"),
                start=pointFromJson(line.getJSONObject("start")),
                end=pointFromJson(line.getJSONObject("end")),layer=line.optString("layer","Чертёж"))
        }
        fun readAnchor(obj:JSONObject):DimensionAnchor = DimensionAnchor(
            point=pointFromJson(obj.getJSONObject("point")),
            wallId=if(obj.has("wallId"))obj.getString("wallId") else null,
            wallEnd=if(obj.has("wallEnd"))WallEnd.valueOf(obj.getString("wallEnd")) else null)
        val dimensions=(0 until dimJson.length()).map { i ->
            val dim=dimJson.getJSONObject(i)
            LinearDimension(id=dim.getString("id"),levelId=dim.getString("levelId"),
                first=readAnchor(dim.getJSONObject("first")),second=readAnchor(dim.getJSONObject("second")),
                offsetMm=dim.getDouble("offsetMm"))
        }
        val layerJson=data.optJSONArray("draftLayers") ?: JSONArray()
        val typeJson=data.optJSONArray("wallTypes") ?: JSONArray()
        val sectionJson=data.optJSONArray("sections") ?: JSONArray()
        require(sectionJson.length()<=20000)
        val sections=(0 until sectionJson.length()).map {i->
            val c=sectionJson.getJSONObject(i)
            SectionCut(id=c.getString("id"),levelId=c.getString("levelId"),name=c.getString("name"),
                start=pointFromJson(c.getJSONObject("start")),
                end=pointFromJson(c.getJSONObject("end")))
        }
        val polyJson=data.optJSONArray("polylines") ?: JSONArray()
        val circleJson=data.optJSONArray("circles") ?: JSONArray()
        val arcJson=data.optJSONArray("arcs") ?: JSONArray()
        require(layerJson.length()<=1000 && typeJson.length()<=5000)
        require(polyJson.length()<=100000 && circleJson.length()<=100000 && arcJson.length()<=100000)
        val wallTypes=(0 until typeJson.length()).map { i ->
            val t=typeJson.getJSONObject(i);val materials=t.getJSONArray("layers")
            require(materials.length() in 1..50)
            WallType(id=t.getString("id"),name=t.getString("name"),
                layers=(0 until materials.length()).map { k ->
                    val l=materials.getJSONObject(k)
                    WallLayer(l.getString("material"),l.getDouble("thicknessMm"),
                        l.optInt("joinPriority",0))
                })
        }
        val polylines=(0 until polyJson.length()).map { i ->
            val poly=polyJson.getJSONObject(i);val points=poly.getJSONArray("vertices")
            require(points.length() in 2..1000)
            DraftPolyline(id=poly.getString("id"),levelId=poly.getString("levelId"),
                vertices=(0 until points.length()).map {pointFromJson(points.getJSONObject(it))},
                layer=poly.optString("layer","Чертёж"),closed=poly.optBoolean("closed",false))
        }
        val circles=(0 until circleJson.length()).map { i ->
            val c=circleJson.getJSONObject(i)
            DraftCircle(id=c.getString("id"),levelId=c.getString("levelId"),
                center=pointFromJson(c.getJSONObject("center")),radiusMm=c.getDouble("radiusMm"),
                layer=c.optString("layer","Чертёж"))
        }
        val arcs=(0 until arcJson.length()).map { i ->
            val a=arcJson.getJSONObject(i)
            DraftArc(id=a.getString("id"),levelId=a.getString("levelId"),
                center=pointFromJson(a.getJSONObject("center")),radiusMm=a.getDouble("radiusMm"),
                startDeg=a.getDouble("startDeg"),sweepDeg=a.getDouble("sweepDeg"),
                layer=a.optString("layer","Чертёж"))
        }
        val draftLayers=if(layerJson.length()>0)(0 until layerJson.length()).map { i ->
            val l=layerJson.getJSONObject(i)
            DraftLayer(name=l.getString("name"),visible=l.optBoolean("visible",true),
                locked=l.optBoolean("locked",false))
        } else {
            // Old formats store layer strings on lines only; synthesize missing layer records.
            (listOf("Чертёж")+draftLines.map{it.layer}+polylines.map{it.layer}+
                circles.map{it.layer}+arcs.map{it.layer}).distinct().map(::DraftLayer)
        }
        return BimProject(schemaVersion=6,id=data.getString("id"),name=data.getString("name"),
            levels=levels,walls=walls,openings=openings,slabs=slabs,wallJoints=joints,
            draftLines=draftLines,dimensions=dimensions,draftLayers=draftLayers,
            polylines=polylines,circles=circles,arcs=arcs,wallTypes=wallTypes,sections=sections)
    }
}

/** Atomic draft write; exports remain explicit, using Android's document picker. */
class ProjectStorage(private val context:Context) {
    private val autosave get()=File(context.filesDir,"autosave.mbim.json")
    fun loadDraft():BimProject?=runCatching {
        if(!autosave.exists()) null else ProjectCodec.decode(autosave.readText(Charsets.UTF_8))
    }.getOrNull()
    fun saveDraft(project:BimProject) {
        val target=autosave
        val temp=File(context.filesDir,"autosave.mbim.json.tmp")
        temp.writeText(ProjectCodec.encode(project),Charsets.UTF_8)
        if(!temp.renameTo(target)) {
            temp.copyTo(target,overwrite=true);temp.delete()
        }
    }
}
