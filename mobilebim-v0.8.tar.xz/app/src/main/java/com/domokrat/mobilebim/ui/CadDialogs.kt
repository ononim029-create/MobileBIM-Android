package com.domokrat.mobilebim.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.domokrat.mobilebim.core.*

@Composable
fun LayersDialog(project:BimProject,onDismiss:()->Unit,onUpdate:(BimProject)->Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Слои чертежа")},
        text={Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState()),
            verticalArrangement=Arrangement.spacedBy(7.dp)) {
            project.draftLayers.forEach { layer ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text(layer.name,Modifier.weight(1f))
                    Checkbox(checked=layer.visible,onCheckedChange={v ->
                        onUpdate(CadEditing.updateLayer(project,layer.name,v,layer.locked))
                    })
                    Checkbox(checked=layer.locked,onCheckedChange={v ->
                        onUpdate(CadEditing.updateLayer(project,layer.name,layer.visible,v))
                    })
                }
            }
            Text("Галочки: видимость / блокировка",style=MaterialTheme.typography.labelSmall)
            OutlinedTextField(value=name,onValueChange={name=it},label={Text("Новый слой")},singleLine=true)
            Button(onClick={
                val result=runCatching { CadEditing.addLayer(project,name) }
                result.getOrNull()?.let{onUpdate(it);name=""}
            },enabled=name.isNotBlank()) {Text("Добавить слой")}
        }},confirmButton={TextButton(onClick=onDismiss){Text("Готово")}})
}

private fun parseWallLayers(text:String):List<WallLayer> = text.lines().filter {it.isNotBlank()}.map { line ->
    val parts=line.split('|',limit=3)
    require(parts.size in 2..3) { "Каждый слой: материал | толщина | приоритет (необязательно)" }
    WallLayer(parts[0].trim(),parts[1].trim().replace(',','.').toDouble(),
        parts.getOrNull(2)?.trim()?.toInt()?:0)
}

@Composable
fun WallTypesDialog(project:BimProject,onDismiss:()->Unit,onUpdate:(BimProject)->Unit) {
    var editingId by remember {mutableStateOf<String?>(null)}
    var name by remember {mutableStateOf("")}
    var layers by remember {mutableStateOf("Штукатурка | 20\nКирпич | 160\nШтукатурка | 20")}
    var message by remember {mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Типы многослойных стен")},
        text={Column(Modifier.heightIn(max=490.dp).verticalScroll(rememberScrollState()),
            verticalArrangement=Arrangement.spacedBy(6.dp)) {
            project.wallTypes.forEach { type ->
                OutlinedButton(onClick={
                    editingId=type.id;name=type.name
                    layers=type.layers.joinToString("\n") {"${it.material} | ${it.thicknessMm.toInt()} | ${it.joinPriority}"}
                    message=""
                },modifier=Modifier.fillMaxWidth()) {
                    Text("${type.name} · ${type.thicknessMm.toInt()} мм")
                }
            }
            HorizontalDivider()
            Text(if(editingId==null)"Новый тип" else "Изменить тип",style=MaterialTheme.typography.titleSmall)
            OutlinedTextField(value=name,onValueChange={name=it},label={Text("Название типа")},singleLine=true)
            OutlinedTextField(value=layers,onValueChange={layers=it},minLines=3,maxLines=6,
                label={Text("Материал | толщина, мм | приоритет 0–1000")})
            if(message.isNotEmpty())Text(message,color=MaterialTheme.colorScheme.error)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={
                    runCatching {
                        val parsed=parseWallLayers(layers)
                        if(editingId==null)WallTypes.create(project,name,parsed)
                        else WallTypes.editType(project,requireNotNull(editingId),name,parsed)
                    }.onSuccess { onUpdate(it);editingId=null;name="";message="" }
                        .onFailure {message=it.message?:"Не удалось изменить тип"}
                },enabled=name.isNotBlank()){Text("Сохранить тип")}
                TextButton(onClick={editingId=null;name="";message=""}){Text("Новый")}
            }
            Text("Изменение типа обновляет толщину всех стен этого типа.",
                style=MaterialTheme.typography.labelSmall)
        }},confirmButton={TextButton(onClick=onDismiss){Text("Закрыть")}})
}

@Composable
fun AssignWallTypeDialog(project:BimProject,wall:Wall,onDismiss:()->Unit,onAssign:(String?)->Unit) {
    AlertDialog(onDismissRequest=onDismiss,title={Text("Тип стены")},
        text={Column(Modifier.heightIn(max=400.dp).verticalScroll(rememberScrollState())) {
            Text("Текущий: "+(project.wallTypes.firstOrNull{it.id==wall.typeId}?.name?:"Без типа"))
            TextButton(onClick={onAssign(null)}){Text("Отвязать от типа")}
            project.wallTypes.forEach{type ->
                OutlinedButton(onClick={onAssign(type.id)},modifier=Modifier.fillMaxWidth()) {
                    Text("${type.name} · ${type.thicknessMm.toInt()} мм")
                }
            }
            if(project.wallTypes.isEmpty())Text("Сначала создайте тип в меню «Типы стен».")
        }},confirmButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

@Composable
fun CadEditDialog(project:BimProject,hit:CadHit,onDismiss:()->Unit,onSave:(BimProject)->Unit) {
    val currentLayer=when(hit.kind) {
        CadKind.LINE -> project.draftLines.first{it.id==hit.id}.layer
        CadKind.POLYLINE -> project.polylines.first{it.id==hit.id}.layer
        CadKind.CIRCLE -> project.circles.first{it.id==hit.id}.layer
        CadKind.ARC -> project.arcs.first{it.id==hit.id}.layer
    }
    var layer by remember(hit.id){mutableStateOf(currentLayer)}
    var dx by remember(hit.id){mutableStateOf("0")}
    var dy by remember(hit.id){mutableStateOf("0")}
    var radius by remember(hit.id){mutableStateOf(when(hit.kind) {
        CadKind.CIRCLE -> project.circles.first{it.id==hit.id}.radiusMm.toString()
        CadKind.ARC -> project.arcs.first{it.id==hit.id}.radiusMm.toString()
        else -> "0"
    })}
    var startAngle by remember(hit.id){mutableStateOf(if(hit.kind==CadKind.ARC)
        project.arcs.first{it.id==hit.id}.startDeg.toString() else "0")}
    var sweep by remember(hit.id){mutableStateOf(if(hit.kind==CadKind.ARC)
        project.arcs.first{it.id==hit.id}.sweepDeg.toString() else "90")}
    var layerMenu by remember{mutableStateOf(false)}
    var error by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Редактировать CAD")},
        text={Column(Modifier.heightIn(max=450.dp).verticalScroll(rememberScrollState()),
            verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Box {
                OutlinedButton(onClick={layerMenu=true}){Text("Слой: $layer ▾")}
                DropdownMenu(expanded=layerMenu,onDismissRequest={layerMenu=false}) {
                    project.draftLayers.filter{!it.locked}.forEach {l ->
                        DropdownMenuItem(text={Text(l.name)},onClick={layer=l.name;layerMenu=false})
                    }
                }
            }
            OutlinedTextField(dx,{dx=it},label={Text("Сдвиг по X, мм")},singleLine=true,
                keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            OutlinedTextField(dy,{dy=it},label={Text("Сдвиг по Y, мм")},singleLine=true,
                keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            if(hit.kind==CadKind.CIRCLE || hit.kind==CadKind.ARC) {
                OutlinedTextField(radius,{radius=it},label={Text("Радиус, мм")},singleLine=true,
                    keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            }
            if(hit.kind==CadKind.ARC) {
                OutlinedTextField(startAngle,{startAngle=it},label={Text("Начало, °")},singleLine=true,
                    keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                OutlinedTextField(sweep,{sweep=it},label={Text("Размах против часовой, °")},singleLine=true,
                    keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            }
            if(error.isNotEmpty()) Text(error,color=MaterialTheme.colorScheme.error)
        }},confirmButton={TextButton(onClick={
            runCatching {
                fun number(s:String)=s.replace(',','.').toDouble()
                var next=CadEditing.move(project,hit,number(dx),number(dy))
                next=CadEditing.changeLayer(next,hit,layer)
                when(hit.kind) {
                    CadKind.CIRCLE -> next=next.copy(circles=next.circles.map {
                        if(it.id==hit.id)it.copy(radiusMm=number(radius))else it
                    })
                    CadKind.ARC -> next=next.copy(arcs=next.arcs.map {
                        if(it.id==hit.id)it.copy(radiusMm=number(radius),startDeg=number(startAngle),
                            sweepDeg=number(sweep)) else it
                    })
                    else -> Unit
                }
                next
            }.onSuccess(onSave).onFailure {error=it.message?:"Некорректные параметры"}
        }){Text("Применить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}
