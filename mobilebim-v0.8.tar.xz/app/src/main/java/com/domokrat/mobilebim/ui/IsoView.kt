package com.domokrat.mobilebim.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.domokrat.mobilebim.core.*
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private data class V(val x:Double,val y:Double,val z:Double)
private data class Face(val vertices:List<V>,val shade:Int,val selected:Boolean=false)

/** Triangulated 2.5D isometric preview; still no Z-buffer or production CSG. */
@Composable
fun IsoView(project:BimProject,selectedWallId:String?,selectedSlabId:String?,
            angleDegrees:Int,modifier:Modifier=Modifier) {
    Canvas(modifier.fillMaxSize()) {
        drawRect(Color(0xFFF5F8FC))
        val angle=Math.toRadians(angleDegrees.toDouble());val ca=cos(angle);val sa=sin(angle)
        fun point(p:V):Offset {
            val x=(p.x*ca-p.y*sa)/1000.0
            val y=(p.x*sa+p.y*ca)/1000.0
            val z=p.z/1000.0
            return Offset(((x-y)*0.866).toFloat(),((x+y)*0.5-z).toFloat())
        }
        val all=project.levels.flatMap{level ->
            (MeshGeometry.build(project,level.id)+SlabMesh.build(project,level.id)).map { triangle ->
                Face(listOf(triangle.a,triangle.b,triangle.c).map{V(it.xMm,it.yMm,it.zMm)},
                    if(triangle.layerIndex<0) 5 else (triangle.layerIndex+2)%6,
                    triangle.elementId==selectedWallId || triangle.elementId==selectedSlabId)
            }
        }
        if(all.isEmpty())return@Canvas
        val projected=all.flatMap{it.vertices}.map(::point)
        val minX=projected.minOf{it.x};val maxX=projected.maxOf{it.x}
        val minY=projected.minOf{it.y};val maxY=projected.maxOf{it.y}
        val fit=min(size.width*0.84f/max(1f,maxX-minX),
            size.height*0.80f/max(1f,maxY-minY)).coerceIn(0.08f,150f)
        val ox=size.width/2f-(minX+maxX)/2f*fit
        val oy=size.height/2f-(minY+maxY)/2f*fit
        val palette=listOf(Color(0xFF7C90A8),Color(0xFF667D98),
            Color(0xFF536E8B),Color(0xFF90A1B6),Color(0xFFAFC0D0),Color(0xFFBED4DE))
        for(face in all.sortedByDescending{ f ->
            f.vertices.map{ v -> val x=v.x*ca-v.y*sa;val y=v.x*sa+v.y*ca
                x+y+v.z*0.00001 }.average()
        }) {
            if(face.vertices.size<3)continue
            val path=Path()
            face.vertices.map(::point).forEachIndexed{ i,p ->
                val s=Offset(ox+p.x*fit,oy+p.y*fit)
                if(i==0)path.moveTo(s.x,s.y) else path.lineTo(s.x,s.y)
            }
            path.close()
            drawPath(path,if(face.selected)Color(0xFF3DBBA6) else palette[face.shade])
            drawPath(path,Color(0xFF35445A),style=Stroke(width=0.7f))
        }
    }
}
