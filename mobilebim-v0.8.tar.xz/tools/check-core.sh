#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
kotlinc "$ROOT"/core/src/main/kotlin/com/domokrat/mobilebim/core/*.kt \
  "$ROOT/tools/CoreSmoke.kt" -include-runtime -d "$TMP/smoke.jar"
java -jar "$TMP/smoke.jar"
