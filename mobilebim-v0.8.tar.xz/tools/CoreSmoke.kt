import com.domokrat.mobilebim.core.*
import kotlin.math.abs
fun near(got:Double, expected:Double){ check(abs(got-expected)<.001) { "$got != $expected" } }
fun main(){
  var passed=0
  fun test(name:String, block:()->Unit){ try { block();passed++;println("PASS $name") }catch(t:Throwable){ println("FAIL $name ${t.message}");throw t } }
  test("T connection propagates") {
     val p=BimProject(); val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(5000.0,0.0))
     val b=WallEditing.addSnappedWall(a,level, WallEditing.snap(a,level,Point2(2500.0,10.0),100.0),SnapResult(Point2(2500.0,3000.0),SnapKind.GRID))
     check(b.wallJoints.size==1)
     val c=WallEditing.moveEndpoint(b,b.walls.first().id,WallEnd.END,Point2(6000.0,0.0),100.0)
     near(c.walls.last().start.xMm,3000.0)
  }
  test("door length guard") {
     val p=BimProject(); val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(5000.0,0.0))
     val b=EditorEngine.addOpening(a,a.walls.single().id,OpeningKind.DOOR,Point2(4500.0,0.0))
     check(runCatching { WallEditing.setGeometry(b,b.walls.single().id,Point2(0.0,0.0),3000.0,0.0) }.isFailure)
  }
  test("numeric exact length") {
     val p=BimProject(); val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(5000.0,0.0))
     val b=WallEditing.setGeometry(a,a.walls.single().id,Point2(500.0,200.0),4200.0,90.0)
     near(b.walls.single().end.xMm,500.0);near(b.walls.single().end.yMm,4400.0)
  }
  test("move guest detaches") {
     val p=BimProject(); val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(5000.0,0.0))
     val b=WallEditing.addSnappedWall(a,level,WallEditing.snap(a,level,Point2(2500.0,0.0),100.0),SnapResult(Point2(2500.0,3000.0),SnapKind.GRID))
     val c=WallEditing.moveEndpoint(b,b.walls[1].id,WallEnd.START,Point2(1000.0,1000.0),50.0)
     check(c.wallJoints.isEmpty())
  }
  test("translate host propagates") {
     val p=BimProject(); val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(5000.0,0.0))
     val b=WallEditing.addSnappedWall(a,level,WallEditing.snap(a,level,Point2(5000.0,0.0),100.0),SnapResult(Point2(5000.0,3000.0),SnapKind.GRID))
     val c=WallEditing.translateWall(b,b.walls.first().id,400.0,600.0)
     check(c.walls[1].start==Point2(5400.0,600.0))
  }
  test("prevents cyclic joints") {
     val p=BimProject();val id=p.levels.single().id
     val w1=Wall(levelId=id,start=Point2(0.0,0.0),end=Point2(4000.0,0.0))
     val w2=Wall(levelId=id,start=Point2(0.0,0.0),end=Point2(0.0,4000.0))
     check(runCatching{p.copy(walls=listOf(w1,w2),wallJoints=listOf(
       WallJoint(w1.id,WallEnd.START,w2.id,0.0),WallJoint(w2.id,WallEnd.START,w1.id,0.0))) }.isFailure)
  }
  test("opening reposition and bounds") {
     val p=BimProject();val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(5000.0,0.0))
     val b=EditorEngine.addOpening(a,a.walls.single().id,OpeningKind.DOOR,Point2(1000.0,0.0))
     val c=PlanEditing.moveOpeningCenter(b,b.openings.single().id,Point2(4400.0,0.0))
     near(c.openings.single().offsetMm,3950.0)
     val d=PlanEditing.moveOpeningCenter(c,c.openings.single().id,Point2(99999.0,0.0))
     near(d.openings.single().offsetMm,4100.0)
  }
  test("overlap rejection is atomic") {
     val p=BimProject();val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(6000.0,0.0))
     val b=EditorEngine.addOpening(a,a.walls.single().id,OpeningKind.WINDOW,Point2(1500.0,0.0))
     val c=EditorEngine.addOpening(b,a.walls.single().id,OpeningKind.WINDOW,Point2(4300.0,0.0))
     check(runCatching{ PlanEditing.moveOpeningCenter(c,c.openings[1].id,Point2(1550.0,0.0)) }.isFailure)
     check(c.openings.size==2)
  }
  test("vertex edit retains valid shape") {
     val p=BimProject();val level=p.levels.single().id
     val a=EditorEngine.addSlab(p,level,listOf(Point2(0.0,0.0),Point2(5000.0,0.0),
        Point2(5000.0,4000.0),Point2(0.0,4000.0)))
     val id=a.slabs.single().id
     val b=PlanEditing.moveSlabVertex(a,id,2,Point2(4000.0,4000.0))
     near(b.slabs.single().areaMm2,18000000.0)
     val c=PlanEditing.translateSlab(b,id,1000.0,-500.0)
     near(c.slabs.single().vertices[0].xMm,1000.0)
     near(c.slabs.single().areaMm2,18000000.0)
     check(runCatching{PlanEditing.moveSlabVertex(a,id,2,Point2(2500.0,-1000.0))}.isFailure)
  }
  test("2D drafting line independent of wall") {
     val p=BimProject();val level=p.levels.single().id
     val a=PlanEditing.addDraftLine(p,level,Point2(100.0,100.0),Point2(2100.0,100.0))
     check(PlanEditing.nearestDraftLine(a,level,Point2(1000.0,120.0),50.0)?.id == a.draftLines.single().id)
     val b=PlanEditing.deleteDraftLine(a,a.draftLines.single().id)
     check(b.draftLines.isEmpty())
  }
  test("dimension follows wall endpoint") {
     val p=BimProject();val level=p.levels.single().id
     val w=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(4000.0,0.0))
     val wall=w.walls.single()
     val d=PlanEditing.addDimension(w,level,
         SnapResult(wall.start,SnapKind.WALL_ENDPOINT,wall.id,0.0),
         SnapResult(wall.end,SnapKind.WALL_ENDPOINT,wall.id,1.0),500.0)
     near(PlanEditing.dimensionPoints(d,d.dimensions.single())!!.third,4000.0)
     val moved=WallEditing.moveEndpoint(d,wall.id,WallEnd.END,Point2(6000.0,0.0),useSnaps=false)
     near(PlanEditing.dimensionPoints(moved,moved.dimensions.single())!!.third,6000.0)
     val removed=WallEditing.removeWall(moved,wall.id)
     check(removed.dimensions.single().first.wallId==null)
     check(removed.dimensions.single().second.wallId==null)
     near(PlanEditing.dimensionPoints(removed,removed.dimensions.single())!!.third,6000.0)
  }
  test("independent dimension offset change") {
     val p=BimProject();val level=p.levels.single().id
     val d=PlanEditing.addDimension(p,level,
         SnapResult(Point2(0.0,0.0),SnapKind.GRID),
         SnapResult(Point2(0.0,1000.0),SnapKind.GRID))
     val updated=PlanEditing.changeDimensionOffset(d,d.dimensions.single().id,-300.0)
     near(updated.dimensions.single().offsetMm,-300.0)
     check(runCatching { PlanEditing.changeDimensionOffset(updated,d.dimensions.single().id,Double.NaN) }.isFailure)
  }
  test("polyline and circle independent of BIM") {
     val p=BimProject();val level=p.levels.single().id
     val a=CadEditing.addPolyline(p,level,listOf(Point2(0.0,0.0),Point2(1000.0,0.0),Point2(1000.0,1000.0)))
     val b=CadEditing.addCircle(a,level,Point2(0.0,0.0),500.0)
     check(a.polylines.size==1 && b.circles.size==1 && b.walls.isEmpty())
     val hit=CadEditing.nearest(b,level,Point2(0.0,500.0),30.0)
     check(hit?.kind==CadKind.CIRCLE)
     val moved=CadEditing.move(b,hit!!,1000.0,0.0)
     near(moved.circles.single().center.xMm,1000.0)
  }
  test("arc counterclockwise and seam selection") {
     val p=BimProject();val level=p.levels.single().id
     val a=CadEditing.addArcByPoints(p,level,Point2(0.0,0.0),Point2(1000.0,0.0),Point2(0.0,1000.0))
     near(a.arcs.single().sweepDeg,90.0)
     check(CadEditing.nearest(a,level,Point2(707.1,707.1),20.0)?.kind==CadKind.ARC)
     check(CadEditing.nearest(a,level,Point2(-1000.0,0.0),20.0)==null)
     check(runCatching{CadEditing.addArcByPoints(p,level,Point2(0.0,0.0),Point2(1000.0,0.0),Point2(2000.0,0.0))}.isFailure)
  }
  test("locked and hidden drafting layers") {
     val p=BimProject();val level=p.levels.single().id
     val a=CadEditing.addLayer(p,"Размерные линии")
     val b=CadEditing.addPolyline(a,level,listOf(Point2(0.0,0.0),Point2(1000.0,0.0)),"Размерные линии")
     val id=b.polylines.single().id
     val hidden=CadEditing.updateLayer(b,"Размерные линии",false,false)
     check(CadEditing.nearest(hidden,level,Point2(500.0,0.0),15.0)==null)
     val locked=CadEditing.updateLayer(hidden,"Размерные линии",true,true)
     check(runCatching{CadEditing.move(locked,CadHit(id,CadKind.POLYLINE),100.0,0.0)}.isFailure)
     check(runCatching{CadEditing.delete(locked,CadHit(id,CadKind.POLYLINE))}.isFailure)
     check(runCatching{CadEditing.addPolyline(locked,level,listOf(Point2(0.0,0.0),Point2(2000.0,0.0)),"Размерные линии")}.isFailure)
  }
  test("polyline rejects degenerate geometry") {
     val p=BimProject();val level=p.levels.single().id
     check(runCatching {CadEditing.addPolyline(p,level,listOf(Point2(0.0,0.0),Point2(0.0,0.0)))}.isFailure)
     check(runCatching {CadEditing.addPolyline(p,level,listOf(Point2(0.0,0.0),Point2(1000.0,0.0)),closed=true)}.isFailure)
  }
  test("typed wall instances update with shared layer type") {
     val p=BimProject();val level=p.levels.single().id
     val a=WallTypes.create(p,"Базовая",listOf(WallLayer("Штукатурка",20.0),WallLayer("Кирпич",160.0),WallLayer("Штукатурка",20.0)))
     val t=a.wallTypes.single()
     val b=WallTypes.addWall(a,level,Point2(0.0,0.0),Point2(5000.0,0.0),t.id)
     val c=WallTypes.addWall(b,level,Point2(0.0,2000.0),Point2(5000.0,2000.0),t.id)
     val d=WallTypes.editType(c,t.id,"Усиленная",listOf(WallLayer("Штукатурка",30.0),WallLayer("Кирпич",190.0),WallLayer("Штукатурка",30.0)))
     check(d.walls.all{it.typeId==t.id && it.thicknessMm==250.0})
     val detached=WallTypes.detach(d,d.walls.first().id)
     val edited=WallTypes.editType(detached,t.id,"Другая",listOf(WallLayer("Кирпич",300.0)))
     near(edited.walls.first().thicknessMm,250.0)
     near(edited.walls.last().thicknessMm,300.0)
  }
  test("single wall instance thickness change detaches from shared type") {
     val p=BimProject();val level=p.levels.single().id
     val a=WallTypes.create(p,"Стена 200",listOf(WallLayer("Кирпич",200.0)))
     val b=WallTypes.addWall(a,level,Point2(0.0,0.0),Point2(4000.0,0.0),a.wallTypes.single().id)
     val c=EditorEngine.changeWall(b,b.walls.single().id,300.0,3000.0,"Усиленная")
     check(c.walls.single().typeId==null && c.walls.single().thicknessMm==300.0)
  }
  test("layer widths form the full wall thickness") {
     val p=BimProject();val level=p.levels.single().id
     val a=WallTypes.create(p,"Multi",listOf(WallLayer("Render",20.0),WallLayer("Core",160.0),WallLayer("Render2",20.0)))
     val b=WallTypes.addWall(a,level,Point2(0.0,0.0),Point2(4000.0,0.0),a.wallTypes.single().id)
     val parts=WallGeometry.footprints(b,b.walls.single())
     check(parts.map{it.material}==listOf("Render","Core","Render2"))
     near(parts[0].polygon[0].yMm,-100.0)
     near(parts[0].polygon[3].yMm,-80.0)
     near(parts[1].polygon[0].yMm,-80.0)
     near(parts[1].polygon[3].yMm,80.0)
     near(parts[2].polygon[3].yMm,100.0)
     near(Geometry.signedArea(WallGeometry.outline(b,b.walls.single())),800000.0)
  }
  test("two orthogonal walls have matching miter endpoints") {
     val p=BimProject(); val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(5000.0,0.0))
     val b=EditorEngine.addWall(a,level,Point2(0.0,0.0),Point2(0.0,4000.0))
     val horizontal=b.walls[0];val vertical=b.walls[1]
     check(WallGeometry.endGeometry(b,horizontal,true).kind==WallCornerKind.MITER)
     val h=WallGeometry.outline(b,horizontal)
     val v=WallGeometry.outline(b,vertical)
     near(h[0].xMm,v[3].xMm);near(h[0].yMm,v[3].yMm)
     near(h[3].xMm,v[0].xMm);near(h[3].yMm,v[0].yMm)
  }
  test("T join returns guest near host surface") {
     val p=BimProject(); val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(-3000.0,0.0),Point2(3000.0,0.0))
     val b=EditorEngine.addWall(a,level,Point2(0.0,0.0),Point2(0.0,3000.0))
     val guest=b.walls.last()
     check(WallGeometry.endGeometry(b,guest,true).kind==WallCornerKind.T_JOIN)
     val outline=WallGeometry.outline(b,guest)
     near(outline[0].yMm,100.0);near(outline[3].yMm,100.0)
     // Existing centreline remains unchanged; trimming is only computed geometry.
     near(guest.start.yMm,0.0)
  }
  test("end-on-host T join and rotated wall") {
     val p=BimProject();val level=p.levels.single().id
     val a=EditorEngine.addWall(p,level,Point2(0.0,0.0),Point2(0.0,5000.0))
     val b=EditorEngine.addWall(a,level,Point2(2000.0,3000.0),Point2(0.0,3000.0))
     val guest=b.walls.last()
     val boundary=WallGeometry.outline(b,guest)
     near(boundary[1].xMm,100.0);near(boundary[2].xMm,100.0)
  }
  test("wall type edit regenerates layer geometry") {
     val p=BimProject();val level=p.levels.single().id
     val a=WallTypes.create(p,"Type",listOf(WallLayer("A",50.0),WallLayer("B",150.0)))
     val b=WallTypes.addWall(a,level,Point2(0.0,0.0),Point2(4000.0,0.0),a.wallTypes.single().id)
     val c=WallTypes.editType(b,a.wallTypes.single().id,"Type",listOf(WallLayer("C",100.0)))
     check(WallGeometry.footprints(c,c.walls.single()).single().material=="C")
     near(WallGeometry.outline(c,c.walls.single())[0].yMm,-50.0)
  }
  test("legacy wall and different levels are safe") {
     val p=BimProject();val l=p.levels.single().id
     val a=EditorEngine.addWall(p,l,Point2(0.0,0.0),Point2(3000.0,0.0))
     check(WallGeometry.footprints(a,a.walls.single()).size==1)
     val high=Level(name="Roof",elevationMm=3000.0)
     val b=a.copy(levels=a.levels+high,walls=a.walls+Wall(levelId=high.id,
         start=Point2(0.0,0.0),end=Point2(0.0,4000.0)))
     check(WallGeometry.endGeometry(b,a.walls.single(),true).kind==WallCornerKind.BUTT)
  }
  test("complex multiway joint falls back safely") {
     val p=BimProject();val l=p.levels.single().id
     val a=EditorEngine.addWall(p,l,Point2(0.0,0.0),Point2(3000.0,0.0))
     val b=EditorEngine.addWall(a,l,Point2(0.0,0.0),Point2(0.0,3000.0))
     val c=EditorEngine.addWall(b,l,Point2(0.0,0.0),Point2(-3000.0,0.0))
     check(WallGeometry.endGeometry(c,c.walls[0],true).kind==WallCornerKind.BUTT)
  }
  test("layer priorities clip crossing footprints without double volume in plan") {
     val initial=BimProject();val l=initial.levels.single().id
     val typed=WallTypes.create(initial,"Strong",listOf(WallLayer("Core",200.0,100)))
     val other=WallTypes.create(typed,"Weak",listOf(WallLayer("Render",200.0,2)))
     val high=WallTypes.addWall(other,l,Point2(-2000.0,0.0),Point2(2000.0,0.0),typed.wallTypes.single().id)
     val both=WallTypes.addWall(high,l,Point2(0.0,-2000.0),Point2(0.0,2000.0),other.wallTypes.last().id)
     val solved=WallJoinSolver.resolve(both,l).pieces
     val byWall=solved.groupBy{it.wallId}
     val winner=byWall.getValue(both.walls.first().id)
     val loser=byWall.getValue(both.walls.last().id)
     near(winner.sumOf{kotlin.math.abs(Geometry.signedArea(it.polygon))},800000.0)
     near(loser.sumOf{kotlin.math.abs(Geometry.signedArea(it.polygon))},760000.0)
     near(solved.sumOf{kotlin.math.abs(Geometry.signedArea(it.polygon))},1560000.0)
  }
  test("multiway is deterministic with shared point warning") {
     val p=BimProject();val l=p.levels.single().id
     val a=EditorEngine.addWall(p,l,Point2(0.0,0.0),Point2(2000.0,0.0))
     val b=EditorEngine.addWall(a,l,Point2(0.0,0.0),Point2(0.0,3000.0))
     val c=EditorEngine.addWall(b,l,Point2(0.0,0.0),Point2(-2000.0,0.0))
     val first=WallJoinSolver.resolve(c,l)
     val again=WallJoinSolver.resolve(c,l)
     check(first==again)
     check(first.warnings.isNotEmpty())
     check(first.pieces.isNotEmpty())
     check(first.pieces.all{ kotlin.math.abs(Geometry.signedArea(it.polygon))>0.1 })
  }
  test("triangles respect window void") {
     val p=BimProject();val l=p.levels.single().id
     val a=EditorEngine.addWall(p,l,Point2(0.0,0.0),Point2(4000.0,0.0))
     val b=EditorEngine.addOpening(a,a.walls.single().id,OpeningKind.WINDOW,
         Point2(2000.0,0.0),widthMm=1000.0,heightMm=1200.0,sillMm=800.0)
     val mesh=MeshGeometry.build(b,l)
     check(mesh.isNotEmpty())
     check(mesh.all{listOf(it.a,it.b,it.c).all{v ->v.zMm in -0.001..3000.001}})
     // No triangle may have its three vertices strictly inside the cut box.
     check(mesh.none { t ->
         listOf(t.a,t.b,t.c).all{it.xMm>1500.01&&it.xMm<2499.99 &&
             it.zMm>800.01&&it.zMm<1999.99}
     })
  }
  test("section has opening bands and level elevation") {
     val p=BimProject();val l=p.levels.single().id
     val w=EditorEngine.addWall(p,l,Point2(0.0,0.0),Point2(4000.0,0.0))
     val window=EditorEngine.addOpening(w,w.walls.single().id,OpeningKind.WINDOW,
         Point2(2000.0,0.0),widthMm=1000.0,heightMm=1200.0,sillMm=800.0)
     val cut=SectionCut(levelId=l,name="A-A",start=Point2(-500.0,0.0),end=Point2(4500.0,0.0))
     val fragments=SectionGeometry.build(window,cut)
     check(fragments.any{it.leftMm<2500.0&&it.rightMm>2500.0 && it.topMm<=800.01})
     check(fragments.any{it.leftMm<2500.0&&it.rightMm>2500.0 && it.bottomMm>=1999.99})
     check(fragments.none{it.leftMm<2500.0&&it.rightMm>2500.0&&
         it.bottomMm<1400.0 && it.topMm>1400.0})
     val withSlab=EditorEngine.addSlab(window,l,listOf(Point2(0.0,-3000.0),
         Point2(4000.0,-3000.0),Point2(4000.0,3000.0),Point2(0.0,3000.0)))
     check(SectionGeometry.build(withSlab,cut).any{it.layerIndex==-1 && it.bottomMm==-200.0})
  }
  test("new section cut validates and survives copy with IDs") {
     val p=BimProject();val l=p.levels.single().id
     val cut=SectionCut(levelId=l,name="Section 1",start=Point2(0.0,0.0),end=Point2(3000.0,0.0))
     check(p.copy(sections=listOf(cut)).sections.single().id==cut.id)
     check(runCatching{SectionCut(levelId=l,name="tiny",start=Point2(0.0,0.0),
         end=Point2(30.0,0.0))}.isFailure)
  }
  test("concave slab triangulates without filling the inner corner") {
     val p=BimProject();val l=p.levels.single().id
     val pts=listOf(Point2(0.0,0.0),Point2(5000.0,0.0),Point2(5000.0,2000.0),
         Point2(2000.0,2000.0),Point2(2000.0,4000.0),Point2(0.0,4000.0))
     val withSlab=EditorEngine.addSlab(p,l,pts)
     val tris=SlabMesh.triangles(pts)
     check(tris.size==pts.size-2)
     near(tris.sumOf{(a,b,c)->kotlin.math.abs(Geometry.signedArea(listOf(pts[a],pts[b],pts[c])))},
         14000000.0)
     check(SlabMesh.build(withSlab,l).size==2*(pts.size-2)+2*pts.size)
  }
  test("reverse contour still triangulates") {
     val pts=listOf(Point2(0.0,0.0),Point2(3000.0,0.0),
         Point2(3000.0,1500.0),Point2(0.0,1500.0)).reversed()
     check(SlabMesh.triangles(pts).size==2)
  }
  test("section annotates opening only on longitudinal cut") {
     val p=BimProject();val l=p.levels.single().id
     val a=EditorEngine.addWall(p,l,Point2(0.0,0.0),Point2(5000.0,0.0))
     val b=EditorEngine.addOpening(a,a.walls.single().id,OpeningKind.WINDOW,
         Point2(2000.0,0.0),widthMm=1000.0,heightMm=1200.0,sillMm=900.0)
     val long=SectionCut(levelId=l,name="A-A",start=Point2(-300.0,0.0),end=Point2(5300.0,0.0))
     val cross=SectionCut(levelId=l,name="Б-Б",start=Point2(2500.0,-500.0),end=Point2(2500.0,500.0))
     val aDoc=SectionDocumentation.build(b,long)
     check(aDoc.openings.size==1)
     near(aDoc.openings.single().headMm,2100.0)
     check(SectionDocumentation.build(b,cross).openings.isEmpty())
  }
  test("hatch classifications are stable") {
     check(SectionDocumentation.hatch("Железобетон")==MaterialHatch.CONCRETE)
     check(SectionDocumentation.hatch("Кирпич")==MaterialHatch.MASONRY)
     check(SectionDocumentation.hatch("Утеплитель")==MaterialHatch.INSULATION)
     check(SectionDocumentation.hatch("Древесина")==MaterialHatch.WOOD)
  }
  println("Core integration checks passed: $passed")
}
