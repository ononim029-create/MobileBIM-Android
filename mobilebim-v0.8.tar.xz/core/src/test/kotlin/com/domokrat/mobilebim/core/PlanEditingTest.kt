package com.domokrat.mobilebim.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull
import kotlin.test.assertNull

class PlanEditingTest {
    private fun wallProject(): BimProject {
        val p = BimProject()
        return EditorEngine.addWall(p,p.levels.first().id,Point2(0.0,0.0),Point2(5000.0,0.0))
    }

    @Test fun `door can slide on its host without changing identity`() {
        val w = wallProject()
        val withDoor = EditorEngine.addOpening(w,w.walls.first().id,OpeningKind.DOOR,Point2(2000.0,0.0))
        val old = withDoor.openings.single()
        val moved = PlanEditing.moveOpeningCenter(withDoor,old.id,Point2(3400.0,1000.0))
        assertEquals(old.id,moved.openings.single().id)
        assertEquals(2950.0,moved.openings.single().offsetMm)
        assertEquals(old.widthMm,moved.openings.single().widthMm)
    }

    @Test fun `door cannot overlap another hosted opening`() {
        val w = wallProject()
        val a = EditorEngine.addOpening(w,w.walls.first().id,OpeningKind.DOOR,Point2(1000.0,0.0))
        val b = EditorEngine.addOpening(a,w.walls.first().id,OpeningKind.DOOR,Point2(3500.0,0.0))
        assertFailsWith<IllegalArgumentException> {
            PlanEditing.moveOpeningCenter(b,b.openings[1].id,Point2(1000.0,0.0))
        }
    }

    @Test fun `slab vertex editing rejects crossing boundaries`() {
        val p = BimProject()
        val slab = EditorEngine.addSlab(p,p.levels.first().id,listOf(
            Point2(0.0,0.0),Point2(5000.0,0.0),Point2(5000.0,4000.0),Point2(0.0,4000.0)))
        val id=slab.slabs.single().id
        val next=PlanEditing.moveSlabVertex(slab,id,2,Point2(4000.0,4000.0))
        assertEquals(18000000.0,next.slabs.single().areaMm2)
        assertFailsWith<IllegalArgumentException> {
            PlanEditing.moveSlabVertex(slab,id,2,Point2(2500.0,-1000.0))
        }
    }

    @Test fun `2D line is not a BIM wall`() {
        val p = BimProject()
        val q = PlanEditing.addDraftLine(p,p.levels.first().id,Point2(0.0,0.0),Point2(2100.0,0.0))
        assertEquals(0,q.walls.size)
        assertEquals(1,q.draftLines.size)
        assertNotNull(PlanEditing.nearestDraftLine(q,p.levels.first().id,Point2(500.0,10.0),50.0))
    }

    @Test fun `dimension updates from wall endpoint and remains after wall deletion`() {
        val w = wallProject()
        val wall = w.walls.single()
        val first=SnapResult(wall.start,SnapKind.WALL_ENDPOINT,wall.id,0.0)
        val last=SnapResult(wall.end,SnapKind.WALL_ENDPOINT,wall.id,1.0)
        val withDim=PlanEditing.addDimension(w,wall.levelId,first,last)
        assertEquals(5000.0,PlanEditing.dimensionPoints(withDim,withDim.dimensions.single())!!.third)
        val stretched=WallEditing.moveEndpoint(withDim,wall.id,WallEnd.END,Point2(6200.0,0.0),useSnaps=false)
        assertEquals(6200.0,PlanEditing.dimensionPoints(stretched,stretched.dimensions.single())!!.third)
        val deleted=EditorEngine.deleteWall(stretched,wall.id)
        assertNull(deleted.dimensions.single().first.wallId)
        assertNull(deleted.dimensions.single().second.wallId)
        assertEquals(6200.0,PlanEditing.dimensionPoints(deleted,deleted.dimensions.single())!!.third)
    }
}
