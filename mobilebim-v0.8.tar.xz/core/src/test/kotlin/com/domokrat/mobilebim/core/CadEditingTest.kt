package com.domokrat.mobilebim.core

import kotlin.test.*

class CadEditingTest {
    @Test fun `arc has correct sweep and is selectable only on arc`() {
        val p=BimProject();val level=p.levels.first().id
        val next=CadEditing.addArcByPoints(p,level,Point2(0.0,0.0),Point2(1000.0,0.0),Point2(0.0,1000.0))
        assertTrue(kotlin.math.abs(90.0-next.arcs.single().sweepDeg)<0.001)
        assertEquals(CadKind.ARC,CadEditing.nearest(next,level,Point2(707.1,707.1),10.0)?.kind)
        assertNull(CadEditing.nearest(next,level,Point2(-1000.0,0.0),20.0))
    }
    @Test fun `hidden layer is excluded and locked layer refuses edits`() {
        val p=BimProject();val level=p.levels.first().id
        val withLayer=CadEditing.addLayer(p,"CAD")
        val withCircle=CadEditing.addCircle(withLayer,level,Point2(0.0,0.0),500.0,"CAD")
        val hit=CadHit(withCircle.circles.single().id,CadKind.CIRCLE)
        val hidden=CadEditing.updateLayer(withCircle,"CAD",false,false)
        assertNull(CadEditing.nearest(hidden,level,Point2(500.0,0.0),10.0))
        val locked=CadEditing.updateLayer(hidden,"CAD",true,true)
        assertFailsWith<IllegalArgumentException> {CadEditing.move(locked,hit,100.0,0.0)}
        assertFailsWith<IllegalArgumentException> {CadEditing.delete(locked,hit)}
    }
}
