package com.domokrat.mobilebim.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SectionDocumentationTest {
    @Test fun parallelCutGetsOpeningTagButTransverseCutDoesNot() {
        val base=BimProject();val id=base.levels.single().id
        val wall=EditorEngine.addWall(base,id,Point2(0.0,0.0),Point2(5000.0,0.0))
        val project=EditorEngine.addOpening(wall,wall.walls.single().id,
            OpeningKind.WINDOW,Point2(2000.0,0.0),widthMm=1000.0,
            sillMm=900.0,heightMm=1200.0)
        val parallel=SectionCut(levelId=id,name="А-А",start=Point2(-300.0,0.0),end=Point2(5300.0,0.0))
        val doc=SectionDocumentation.build(project,parallel)
        assertEquals(1,doc.openings.size)
        assertEquals(2100.0,doc.openings.single().headMm,0.01)
        val transverse=SectionCut(levelId=id,name="Б-Б",start=Point2(2500.0,-500.0),end=Point2(2500.0,500.0))
        assertTrue(SectionDocumentation.build(project,transverse).openings.isEmpty())
    }
    @Test fun namesMapToConventionalHatches() {
        assertEquals(MaterialHatch.CONCRETE, SectionDocumentation.hatch("Железобетон"))
        assertEquals(MaterialHatch.MASONRY, SectionDocumentation.hatch("Кирпич"))
        assertEquals(MaterialHatch.INSULATION, SectionDocumentation.hatch("Утеплитель"))
    }
}
