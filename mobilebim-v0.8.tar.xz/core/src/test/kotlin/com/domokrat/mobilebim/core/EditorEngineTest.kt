package com.domokrat.mobilebim.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class EditorEngineTest {
    @Test fun `wall is created with physical units and level link`() {
        val p = BimProject()
        val next = EditorEngine.addWall(p,p.levels.first().id,Point2(0.0,0.0),Point2(4000.0,0.0))
        assertEquals(1,next.walls.size)
        assertEquals(4000.0,next.walls.first().lengthMm)
        assertEquals(0,p.walls.size)
    }
    @Test fun `short walls are rejected`() {
        val p=BimProject()
        assertFailsWith<IllegalArgumentException> {
            EditorEngine.addWall(p,p.levels.first().id,Point2(0.0,0.0),Point2(30.0,0.0))
        }
    }
    @Test fun `snap rounds to nearest hundred millimetres`() {
        assertEquals(Point2(1200.0,-400.0),EditorEngine.snap(Point2(1248.0,-357.0)))
    }
    @Test fun `nearest wall selection`() {
        val p=BimProject()
        val q=EditorEngine.addWall(p,p.levels.first().id,Point2(0.0,0.0),Point2(4000.0,0.0))
        assertNotNull(EditorEngine.nearestWall(q,p.levels.first().id,Point2(2100.0, 130.0),100.0))
        assertEquals(null,EditorEngine.nearestWall(q,p.levels.first().id,Point2(2100.0,1000.0),100.0))
    }
    @Test fun `edit preserves identity`() {
        val p=BimProject(); val a=EditorEngine.addWall(p,p.levels.first().id,Point2(0.0,0.0),Point2(4000.0,0.0))
        val id=a.walls.first().id
        val b=EditorEngine.changeWall(a,id,300.0,3200.0,"Кирпич")
        assertEquals(id,b.walls.first().id)
        assertEquals(300.0,b.walls.first().thicknessMm)
        assertEquals("Кирпич",b.walls.first().material)
    }
    @Test fun `project rejects walls with invalid levels`() {
        assertFailsWith<IllegalArgumentException> {
            BimProject(walls=listOf(Wall(levelId="missing",start=Point2(0.0,0.0),end=Point2(1000.0,0.0))))
        }
    }
}
