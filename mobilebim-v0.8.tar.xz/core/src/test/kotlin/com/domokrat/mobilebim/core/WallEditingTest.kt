package com.domokrat.mobilebim.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class WallEditingTest {
    private val eps=0.001
    private fun near(value:Double, expected:Double)=assertTrue(kotlin.math.abs(value-expected)<eps,"Expected $expected, got $value")
    private fun base():BimProject {
        val p=BimProject()
        return EditorEngine.addWall(p,p.levels.first().id,Point2(0.0,0.0),Point2(5000.0,0.0))
    }

    @Test fun `snap selects wall endpoint before grid`() {
        val p=base()
        val s=WallEditing.snap(p,p.levels.first().id,Point2(5050.0,25.0),150.0)
        assertEquals(SnapKind.WALL_ENDPOINT,s.kind)
        assertEquals(Point2(5000.0,0.0),s.point)
        assertEquals(1.0,s.hostT)
    }

    @Test fun `snap to wall midpoint and perpendicular axis`() {
        val p=base()
        val s=WallEditing.snap(p,p.levels.first().id,Point2(2480.0,20.0),90.0)
        assertEquals(SnapKind.WALL_MIDPOINT,s.kind)
        assertEquals(Point2(2500.0,0.0),s.point)
        val t=WallEditing.snap(p,p.levels.first().id,Point2(3333.0,45.0),100.0)
        assertEquals(SnapKind.WALL_AXIS,t.kind)
        near(t.point.xMm,3333.0);near(t.point.yMm,0.0)
    }

    @Test fun `T joint tracks host endpoint drag`() {
        val a=base()
        val level=a.levels.single().id
        val b=WallEditing.addSnappedWall(a,level,
            WallEditing.snap(a,level,Point2(2500.0,15.0),80.0),
            SnapResult(Point2(2500.0,3000.0),SnapKind.GRID))
        assertEquals(1,b.wallJoints.size)
        val guest=b.walls.last()
        near(guest.start.xMm,2500.0)
        val c=WallEditing.moveEndpoint(b,b.walls.first().id,WallEnd.END,Point2(6000.0,0.0),90.0)
        near(c.walls.last().start.xMm,3000.0)
        near(c.walls.last().start.yMm,0.0)
        assertEquals(guest.id,c.walls.last().id)
    }

    @Test fun `resizing host cannot truncate hosted door`() {
        val a=base()
        val b=EditorEngine.addOpening(a,a.walls.single().id,OpeningKind.DOOR,Point2(4500.0,0.0))
        assertFailsWith<IllegalArgumentException> {
            WallEditing.setGeometry(b,b.walls.single().id,Point2(0.0,0.0),3000.0,0.0)
        }
        near(b.walls.single().lengthMm,5000.0)
    }

    @Test fun `numeric length and angle edit in millimetres`() {
        val a=base()
        val id=a.walls.single().id
        val b=WallEditing.setGeometry(a,id,Point2(500.0,200.0),4200.0,90.0)
        near(b.walls.single().lengthMm,4200.0)
        near(b.walls.single().end.xMm,500.0)
        near(b.walls.single().end.yMm,4400.0)
        assertEquals(id,b.walls.single().id)
    }

    @Test fun `moving host translates connected guest endpoint`() {
        val a=base();val level=a.levels.single().id
        val b=WallEditing.addSnappedWall(a,level,
            WallEditing.snap(a,level,Point2(5000.0,0.0),120.0),
            SnapResult(Point2(5000.0,3000.0),SnapKind.GRID))
        val c=WallEditing.translateWall(b,b.walls.first().id,400.0,600.0)
        assertEquals(Point2(5400.0,600.0),c.walls[0].end)
        assertEquals(Point2(5400.0,600.0),c.walls[1].start)
        assertEquals(1,c.wallJoints.size)
    }

    @Test fun `moving a guest end detaches without duplicating walls`() {
        val a=base();val level=a.levels.single().id
        val b=WallEditing.addSnappedWall(a,level,
            WallEditing.snap(a,level,Point2(2500.0,0.0),100.0),
            SnapResult(Point2(2500.0,3000.0),SnapKind.GRID))
        val c=WallEditing.moveEndpoint(b,b.walls[1].id,WallEnd.START,Point2(1000.0,1000.0),50.0)
        assertEquals(0,c.wallJoints.size)
        assertEquals(2,c.walls.size)
    }

    @Test fun `deleting host detaches guests but preserves their geometry`() {
        val a=base();val level=a.levels.single().id
        val b=WallEditing.addSnappedWall(a,level,
            WallEditing.snap(a,level,Point2(2500.0,0.0),100.0),
            SnapResult(Point2(2500.0,3000.0),SnapKind.GRID))
        val guest=b.walls.last()
        val c=WallEditing.removeWall(b,b.walls.first().id)
        assertEquals(listOf(guest),c.walls)
        assertTrue(c.wallJoints.isEmpty())
    }

    @Test fun `cycle of host references must be rejected`() {
        val p=BimProject()
        val level=p.levels.single().id
        val w1=Wall(levelId=level,start=Point2(0.0,0.0),end=Point2(4000.0,0.0))
        val w2=Wall(levelId=level,start=Point2(0.0,0.0),end=Point2(0.0,4000.0))
        assertFailsWith<IllegalArgumentException> {
            p.copy(walls=listOf(w1,w2),wallJoints=listOf(
                WallJoint(w1.id,WallEnd.START,w2.id,0.0),
                WallJoint(w2.id,WallEnd.START,w1.id,0.0)))
        }
    }
}
