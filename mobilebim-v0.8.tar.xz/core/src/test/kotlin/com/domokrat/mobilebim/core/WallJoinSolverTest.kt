package com.domokrat.mobilebim.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class WallJoinSolverTest {
    @Test fun priorityWinsCrossingWithNoAreaDuplication() {
        var p=BimProject();val level=p.levels.single().id
        p=WallTypes.create(p,"P100",listOf(WallLayer("Structure",200.0,100)))
        p=WallTypes.create(p,"P10",listOf(WallLayer("Finish",200.0,10)))
        p=WallTypes.addWall(p,level,Point2(-2000.0,0.0),Point2(2000.0,0.0),p.wallTypes[0].id)
        p=WallTypes.addWall(p,level,Point2(0.0,-2000.0),Point2(0.0,2000.0),p.wallTypes[1].id)
        val pieces=WallJoinSolver.resolve(p,level).pieces
        val total=pieces.sumOf {abs(Geometry.signedArea(it.polygon))}
        assertEquals(1_560_000.0,total,0.01)
        assertTrue(pieces.none{it.polygon.size<3})
    }
    @Test fun priorityValidation() {
        assertTrue(runCatching {WallLayer("Bad",200.0,-1)}.isFailure)
        assertTrue(runCatching {WallLayer("Bad",200.0,1001)}.isFailure)
    }
}
