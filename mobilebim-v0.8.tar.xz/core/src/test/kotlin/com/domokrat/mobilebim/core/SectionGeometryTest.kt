package com.domokrat.mobilebim.core

import org.junit.Assert.assertTrue
import org.junit.Test

class SectionGeometryTest {
    @Test fun windowVoidExcludesMiddleBand() {
        var project=BimProject();val level=project.levels.single().id
        project=EditorEngine.addWall(project,level,Point2(0.0,0.0),Point2(4000.0,0.0))
        project=EditorEngine.addOpening(project,project.walls.single().id,OpeningKind.WINDOW,
            Point2(2000.0,0.0),widthMm=1000.0,heightMm=1200.0,sillMm=800.0)
        val cut=SectionCut(levelId=level,name="А-А",start=Point2(-500.0,0.0),end=Point2(4500.0,0.0))
        val section=SectionGeometry.build(project,cut)
        assertTrue(section.isNotEmpty())
        assertTrue(section.none {it.leftMm < 2500.0 && it.rightMm>2500.0 &&
            it.bottomMm < 1400.0 && it.topMm > 1400.0})
    }
    @Test fun meshContainsTrianglesButNoStoredGeometry() {
        var project=BimProject();val level=project.levels.single().id
        project=EditorEngine.addWall(project,level,Point2(0.0,0.0),Point2(4000.0,0.0))
        assertTrue(MeshGeometry.build(project,level).isNotEmpty())
        assertTrue(project.walls.single().start==Point2(0.0,0.0))
    }
}
