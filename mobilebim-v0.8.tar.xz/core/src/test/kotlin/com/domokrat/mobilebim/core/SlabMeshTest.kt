package com.domokrat.mobilebim.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class SlabMeshTest {
    @Test fun concaveSlabHasCorrectAreaAndClosedFaces() {
        val outline=listOf(Point2(0.0,0.0),Point2(5000.0,0.0),
            Point2(5000.0,2000.0),Point2(2000.0,2000.0),
            Point2(2000.0,4000.0),Point2(0.0,4000.0))
        val mesh=SlabMesh.triangles(outline)
        assertEquals(outline.size-2,mesh.size)
        val area=mesh.sumOf { (a,b,c)-> abs(Geometry.signedArea(listOf(outline[a],outline[b],outline[c]))) }
        assertEquals(abs(Geometry.signedArea(outline)),area,0.001)
        val project=BimProject().let { p -> EditorEngine.addSlab(p,p.levels.single().id,outline) }
        val faces=SlabMesh.build(project,project.levels.single().id)
        assertEquals(2*(outline.size-2)+2*outline.size,faces.size)
        assertTrue(faces.none{it.a.zMm.isNaN() || it.b.zMm.isNaN()})
    }
    @Test fun reversedContourAlsoTriangulates() {
        val pts=listOf(Point2(0.0,0.0),Point2(2500.0,0.0),
            Point2(2500.0,1500.0),Point2(0.0,1500.0)).reversed()
        assertEquals(2,SlabMesh.triangles(pts).size)
    }
}
