package com.domokrat.mobilebim.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class OpeningAndSlabTest {
    private fun wall():BimProject {
        val p=BimProject()
        return EditorEngine.addWall(p,p.levels.first().id,
            Point2(0.0,0.0),Point2(5000.0,0.0))
    }

    @Test fun `door has a real host and persistent identity`() {
        val p=wall();val wall=p.walls.first()
        val next=EditorEngine.addOpening(p,wall.id,OpeningKind.DOOR,Point2(2500.0,0.0))
        val opening=next.openings.single()
        assertEquals(wall.id,opening.wallId)
        assertEquals(2050.0,opening.offsetMm)
        assertEquals(900.0,opening.widthMm)
        assertEquals(0.0,opening.sillMm)
        assertEquals(1,p.walls.size)
        assertEquals(0,p.openings.size)
    }

    @Test fun `door near wall end is fitted within its host`() {
        val p=wall()
        val q=EditorEngine.addOpening(p,p.walls.first().id,OpeningKind.DOOR,Point2(4900.0,0.0))
        assertEquals(5000.0,q.openings.single().endMm)
    }

    @Test fun `openings cannot overlap in solid volume`() {
        val p=wall();val wall=p.walls.first()
        val q=EditorEngine.addOpening(p,wall.id,OpeningKind.DOOR,Point2(2000.0,0.0))
        assertFailsWith<IllegalArgumentException> {
            EditorEngine.addOpening(q,wall.id,OpeningKind.WINDOW,Point2(1900.0,0.0))
        }
    }

    @Test fun `invalid hosted opening cannot exceed height of its wall`() {
        val p=wall();val w=p.walls.first()
        assertFailsWith<IllegalArgumentException> {
            EditorEngine.addOpening(p,w.id,OpeningKind.WINDOW,Point2(2200.0,0.0),
                heightMm=2500.0,sillMm=800.0)
        }
    }

    @Test fun `door openings removed automatically with wall`() {
        val p=wall();val w=p.walls.first()
        val q=EditorEngine.addOpening(p,w.id,OpeningKind.DOOR,Point2(2000.0,0.0))
        val deleted=EditorEngine.deleteWall(q,w.id)
        assertTrue(deleted.walls.isEmpty())
        assertTrue(deleted.openings.isEmpty())
    }

    @Test fun `slab area is computed using physical millimetres`() {
        val p=BimProject();val level=p.levels.first().id
        val q=EditorEngine.addSlab(p,level,listOf(
            Point2(0.0,0.0),Point2(4000.0,0.0),
            Point2(4000.0,3000.0),Point2(0.0,3000.0)))
        assertEquals(12.0,q.slabs.single().areaMm2 / 1e6)
        assertEquals(level,q.slabs.single().levelId)
    }

    @Test fun `self crossing slabs rejected`() {
        val p=BimProject()
        assertFailsWith<IllegalArgumentException> {
            EditorEngine.addSlab(p,p.levels.first().id,listOf(
                Point2(0.0,0.0),Point2(4000.0,4000.0),
                Point2(0.0,4000.0),Point2(4000.0,0.0)))
        }
    }

    @Test fun `concave polygon contains points correctly`() {
        val pts=listOf(Point2(0.0,0.0),Point2(4000.0,0.0),Point2(4000.0,1000.0),
            Point2(1000.0,1000.0),Point2(1000.0,4000.0),Point2(0.0,4000.0))
        assertTrue(Geometry.isSimplePolygon(pts))
        assertTrue(Geometry.containsPolygonPoint(pts,Point2(500.0,3000.0)))
        assertTrue(!Geometry.containsPolygonPoint(pts,Point2(3000.0,3000.0)))
    }

    @Test fun `shortening a wall invalidates hosted opening transactionally`() {
        val p=wall();val w=p.walls.first()
        val q=EditorEngine.addOpening(p,w.id,OpeningKind.DOOR,Point2(4300.0,0.0))
        assertFailsWith<IllegalArgumentException> {
            q.copy(walls=q.walls.map {it.copy(end=Point2(4000.0,0.0))})
        }
        assertEquals(5000.0,q.walls.first().lengthMm)
    }
}
