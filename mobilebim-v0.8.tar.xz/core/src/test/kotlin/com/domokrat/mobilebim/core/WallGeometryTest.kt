package com.domokrat.mobilebim.core

import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class WallGeometryTest {
    private fun near(value:Double, expected:Double) =
        assertTrue(abs(value-expected)<0.001,"expected $expected, got $value")

    @Test fun stripesAreContiguousAndMatchType() {
        val p=BimProject();val level=p.levels.single().id
        val typed=WallTypes.create(p,"P200",listOf(WallLayer("Render",20.0),
            WallLayer("Brick",160.0),WallLayer("Render",20.0)))
        val edited=WallTypes.addWall(typed,level,Point2(0.0,0.0),Point2(5000.0,0.0),typed.wallTypes.single().id)
        val parts=WallGeometry.footprints(edited,edited.walls.single())
        assertEquals(3,parts.size)
        near(parts[0].polygon[3].yMm,parts[1].polygon[0].yMm)
        near(parts[1].polygon[3].yMm,parts[2].polygon[0].yMm)
        near(parts[0].polygon[0].yMm,-100.0)
        near(parts[2].polygon[3].yMm,100.0)
    }

    @Test fun miterHasSameEdgeAtCornerForReversedWall() {
        val p=BimProject();val level=p.levels.single().id
        val h=Wall(levelId=level,start=Point2(-4000.0,0.0),end=Point2(0.0,0.0),thicknessMm=300.0)
        val v=Wall(levelId=level,start=Point2(0.0,0.0),end=Point2(0.0,4000.0),thicknessMm=100.0)
        val project=p.copy(walls=listOf(h,v))
        val a=WallGeometry.outline(project,h)
        val b=WallGeometry.outline(project,v)
        assertEquals(WallCornerKind.MITER,WallGeometry.endGeometry(project,h,false).kind)
        // At the joint the positive/negative canonical layers swap because the first wall ends there.
        near(a[1].xMm,b[0].xMm);near(a[1].yMm,b[0].yMm)
        near(a[2].xMm,b[3].xMm);near(a[2].yMm,b[3].yMm)
    }

    @Test fun inferredTJoinStopsAtNearHostFace() {
        val p=BimProject();val level=p.levels.single().id
        val host=Wall(levelId=level,start=Point2(-5000.0,0.0),end=Point2(5000.0,0.0),thicknessMm=250.0)
        val guest=Wall(levelId=level,start=Point2(0.0,0.0),end=Point2(0.0,3000.0),thicknessMm=100.0)
        val project=p.copy(walls=listOf(host,guest))
        val vertices=WallGeometry.outline(project,guest)
        assertEquals(WallCornerKind.T_JOIN,WallGeometry.endGeometry(project,guest,true).kind)
        near(vertices[0].yMm,125.0)
        near(vertices[3].yMm,125.0)
    }

    @Test fun unsupportedMultiwayDoesNotInventMiter() {
        val p=BimProject();val level=p.levels.single().id
        val walls=listOf(Point2(5000.0,0.0),Point2(0.0,5000.0),Point2(-5000.0,0.0))
            .map {Wall(levelId=level,start=Point2(0.0,0.0),end=it)}
        val project=p.copy(walls=walls)
        walls.forEach { assertEquals(WallCornerKind.BUTT,WallGeometry.endGeometry(project,it,true).kind) }
    }
}
