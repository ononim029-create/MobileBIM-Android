package com.domokrat.mobilebim.core

import kotlin.test.*

class WallTypesTest {
    @Test fun `type edits update linked instances only`() {
        val p=BimProject();val level=p.levels.first().id
        val typed=WallTypes.create(p,"Кирпичная",listOf(WallLayer("Штукатурка",20.0),WallLayer("Кирпич",160.0),WallLayer("Штукатурка",20.0)))
        val id=typed.wallTypes.single().id
        val a=WallTypes.addWall(typed,level,Point2(0.0,0.0),Point2(5000.0,0.0),id)
        val b=WallTypes.addWall(a,level,Point2(0.0,2000.0),Point2(5000.0,2000.0),id)
        val c=WallTypes.detach(b,b.walls.first().id)
        val d=WallTypes.editType(c,id,"Кирпичная усиленная",listOf(WallLayer("Кирпич",250.0)))
        assertEquals(200.0,d.walls.first().thicknessMm)
        assertEquals(250.0,d.walls.last().thicknessMm)
        assertNull(d.walls.first().typeId)
    }
    @Test fun `wall type thickness mismatch rejected`() {
        val p=BimProject();val level=p.levels.first().id
        val typed=WallTypes.create(p,"Тип",listOf(WallLayer("Бетон",200.0)))
        val id=typed.wallTypes.single().id
        assertFailsWith<IllegalArgumentException> {
            typed.copy(walls=listOf(Wall(levelId=level,start=Point2(0.0,0.0),
                end=Point2(5000.0,0.0),typeId=id,thicknessMm=300.0)))
        }
    }
}
