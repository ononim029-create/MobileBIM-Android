package com.domokrat.mobilebim.core

import kotlin.math.abs

/**
 * Derived slab triangulation, independent of Android.  Supports simple concave
 * polygons without holes. The original polygon and editable vertices remain
 * the source of truth; this mesh is regenerated on demand.
 */
object SlabMesh {
    private const val EPS = 1e-8

    /** Each triple contains indices into the supplied polygon. */
    fun triangles(vertices: List<Point2>): List<Triple<Int, Int, Int>> {
        require(vertices.size >= 3 && Geometry.isSimplePolygon(vertices))
        val ccw = Geometry.signedArea(vertices) > 0
        val remaining = vertices.indices.toMutableList()
        val output = mutableListOf<Triple<Int, Int, Int>>()
        fun area(a: Point2, b: Point2, c: Point2): Double =
            (b.xMm-a.xMm)*(c.yMm-a.yMm)-(b.yMm-a.yMm)*(c.xMm-a.xMm)
        fun inside(a:Point2,b:Point2,c:Point2,p:Point2):Boolean {
            val d1=area(a,b,p);val d2=area(b,c,p);val d3=area(c,a,p)
            return if(ccw) d1>=-EPS && d2>=-EPS && d3>=-EPS
                else d1<=EPS && d2<=EPS && d3<=EPS
        }
        var safety=0
        while(remaining.size>3) {
            require(++safety <= vertices.size*vertices.size) { "Не удалось триангулировать перекрытие" }
            var clipped=false
            for(i in remaining.indices) {
                val prev=remaining[(i-1+remaining.size)%remaining.size]
                val cur=remaining[i]
                val next=remaining[(i+1)%remaining.size]
                val a=vertices[prev];val b=vertices[cur];val c=vertices[next]
                val winding=area(a,b,c)
                if(if(ccw) winding<=EPS else winding>=-EPS) continue
                val hasInnerPoint=remaining.any{other->
                    other!=prev && other!=cur && other!=next && inside(a,b,c,vertices[other])
                }
                if(hasInnerPoint)continue
                output+=if(ccw) Triple(prev,cur,next) else Triple(next,cur,prev)
                remaining.removeAt(i)
                clipped=true
                break
            }
            if(!clipped)error("Не удалось построить сетку: проверьте почти совпадающие вершины")
        }
        val a=remaining[0];val b=remaining[1];val c=remaining[2]
        output+=if(ccw) Triple(a,b,c) else Triple(c,b,a)
        return output
    }

    fun build(project:BimProject, levelId:String):List<MeshTriangle> {
        val level=project.levels.first{it.id==levelId}
        return project.slabs.filter{it.levelId==levelId}.flatMap{slab->
            val zTop=level.elevationMm
            val zBottom=zTop-slab.thicknessMm
            val points=slab.vertices
            val triangles=mutableListOf<MeshTriangle>()
            fun triangle(a:Point3,b:Point3,c:Point3) {
                triangles+=MeshTriangle(slab.id,-1,slab.material,a,b,c)
            }
            val upper=points.map{Point3(it.xMm,it.yMm,zTop)}
            val lower=points.map{Point3(it.xMm,it.yMm,zBottom)}
            for((a,b,c) in triangles(points)) {
                triangle(upper[a],upper[b],upper[c])
                triangle(lower[c],lower[b],lower[a])
            }
            val ccw=Geometry.signedArea(points)>0
            for(i in points.indices) {
                val j=(i+1)%points.size
                // Side faces are wound outward, matching the CCW upper face.
                if(ccw) {
                    triangle(lower[i],lower[j],upper[j])
                    triangle(lower[i],upper[j],upper[i])
                } else {
                    triangle(lower[j],lower[i],upper[i])
                    triangle(lower[j],upper[i],upper[j])
                }
            }
            triangles
        }
    }
}
