package com.domokrat.mobilebim.core

import kotlin.math.hypot
import kotlin.math.round

/** Immutable pure edit operations; no Android- or Revit-dependent state. */
object EditorEngine {
    fun snap(point: Point2, gridMm: Double = 100.0): Point2 {
        require(gridMm.isFinite() && gridMm > 0.0)
        return Point2(round(point.xMm/gridMm)*gridMm,round(point.yMm/gridMm)*gridMm)
    }

    fun addWall(project:BimProject,levelId:String,a:Point2,b:Point2,
                thicknessMm:Double=200.0,heightMm:Double=3000.0):BimProject {
        require(project.levels.any{it.id==levelId})
        return project.copy(walls=project.walls+Wall(levelId=levelId,start=a,end=b,
            thicknessMm=thicknessMm,heightMm=heightMm))
    }

    fun changeWall(project:BimProject,wallId:String,thicknessMm:Double,
                   heightMm:Double,material:String):BimProject {
        require(project.walls.any{it.id==wallId})
        return project.copy(walls=project.walls.map {
            if (it.id==wallId) it.copy(typeId=if(it.typeId!=null &&
                kotlin.math.abs(it.thicknessMm-thicknessMm)<0.001) it.typeId else null,
                thicknessMm=thicknessMm,heightMm=heightMm,material=material.trim()) else it
        })
    }

    /** Removing a wall atomically removes its hosted door/window voids. */
    fun deleteWall(project:BimProject,wallId:String):BimProject = WallEditing.removeWall(project,wallId)

    fun addLevel(project:BimProject,name:String,elevationMm:Double):BimProject {
        require(project.levels.none {it.name.equals(name.trim(),ignoreCase=true)}) {
            "Этаж с таким названием уже существует"
        }
        return project.copy(levels=project.levels+Level(name=name.trim(),elevationMm=elevationMm))
    }

    fun addOpening(project:BimProject,wallId:String,kind:OpeningKind,at:Point2,
                   widthMm:Double=if(kind==OpeningKind.DOOR)900.0 else 1200.0,
                   heightMm:Double=if(kind==OpeningKind.DOOR)2100.0 else 1400.0,
                   sillMm:Double=if(kind==OpeningKind.DOOR)0.0 else 900.0):BimProject {
        val wall=project.walls.firstOrNull {it.id==wallId} ?: error("Стена не найдена")
        require(widthMm<=wall.lengthMm) {"Проём шире стены"}
        val center=Geometry.wallProjection(wall,at)*wall.lengthMm
        val offset=(center-widthMm/2.0).coerceIn(0.0,wall.lengthMm-widthMm)
        return project.copy(openings=project.openings+Opening(wallId=wallId,kind=kind,
            offsetMm=offset,widthMm=widthMm,heightMm=heightMm,sillMm=sillMm))
    }

    fun editOpening(project:BimProject,id:String,offsetMm:Double,widthMm:Double,
                    heightMm:Double,sillMm:Double):BimProject {
        require(project.openings.any{it.id==id})
        return project.copy(openings=project.openings.map {
            if(it.id==id) it.copy(offsetMm=offsetMm,widthMm=widthMm,
                heightMm=heightMm,sillMm=sillMm) else it
        })
    }

    fun deleteOpening(project:BimProject,id:String):BimProject =
        project.copy(openings=project.openings.filterNot {it.id==id})

    fun addSlab(project:BimProject,levelId:String,points:List<Point2>,
                thicknessMm:Double=200.0):BimProject {
        require(project.levels.any {it.id==levelId})
        return project.copy(slabs=project.slabs+Slab(levelId=levelId,
            vertices=points.toList(),thicknessMm=thicknessMm))
    }

    fun changeSlab(project:BimProject,id:String,thicknessMm:Double,material:String):BimProject {
        require(project.slabs.any{it.id==id})
        return project.copy(slabs=project.slabs.map {
            if(it.id==id) it.copy(thicknessMm=thicknessMm,material=material.trim()) else it
        })
    }

    fun deleteSlab(project:BimProject,id:String):BimProject =
        project.copy(slabs=project.slabs.filterNot{it.id==id})

    fun nearestWall(project:BimProject,levelId:String,point:Point2,toleranceMm:Double):Wall? =
        project.walls.asReversed().asSequence().filter{it.levelId==levelId}
        .map{it to pointToSegmentDistance(point,it.start,it.end)}
        .filter{it.second<=toleranceMm+it.first.thicknessMm/2.0}
        .minByOrNull{it.second}?.first

    fun nearestOpening(project:BimProject,levelId:String,point:Point2,
                       toleranceMm:Double):Opening? {
        val walls=project.walls.filter{it.levelId==levelId}.associateBy{it.id}
        return project.openings.asReversed().asSequence().mapNotNull { opening ->
            val wall=walls[opening.wallId] ?: return@mapNotNull null
            val t=Geometry.wallProjection(wall,point)
            val along=t*wall.lengthMm
            if(along<opening.offsetMm-toleranceMm || along>opening.endMm+toleranceMm)
                return@mapNotNull null
            opening to pointToSegmentDistance(point,wall.start,wall.end)
        }.filter {it.second<=toleranceMm}
         .minByOrNull {it.second}?.first
    }

    fun nearestSlab(project:BimProject,levelId:String,point:Point2):Slab? =
        project.slabs.asReversed().firstOrNull {it.levelId==levelId && Geometry.containsPolygonPoint(it.vertices,point)}

    fun pointToSegmentDistance(p:Point2,a:Point2,b:Point2):Double {
        val dx=b.xMm-a.xMm;val dy=b.yMm-a.yMm
        val t=(((p.xMm-a.xMm)*dx+(p.yMm-a.yMm)*dy)/(dx*dx+dy*dy)).coerceIn(0.0,1.0)
        return hypot(p.xMm-(a.xMm+dx*t),p.yMm-(a.yMm+dy*t))
    }
}
