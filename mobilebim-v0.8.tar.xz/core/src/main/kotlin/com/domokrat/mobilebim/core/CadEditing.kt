package com.domokrat.mobilebim.core

import java.util.UUID
import kotlin.math.*

/** 2D objects never modify BIM geometry. All coordinates and radii are in millimetres. */
data class DraftLayer(
    val name: String,
    val visible: Boolean = true,
    val locked: Boolean = false,
) { init { require(name.isNotBlank() && name.length <= 80) } }

data class DraftPolyline(
    val id: String = UUID.randomUUID().toString(),
    val levelId: String,
    val vertices: List<Point2>,
    val closed: Boolean = false,
    val layer: String = "Чертёж",
) { init {
    require(id.isNotBlank() && levelId.isNotBlank() && layer.isNotBlank())
    require(vertices.size in (if (closed) 3 else 2)..1000)
    require(vertices.zipWithNext().all { (a,b) -> hypot(a.xMm-b.xMm,a.yMm-b.yMm) >= 1.0 })
    if (closed) require(hypot(vertices.first().xMm-vertices.last().xMm,
        vertices.first().yMm-vertices.last().yMm) >= 1.0)
} }

data class DraftCircle(
    val id: String = UUID.randomUUID().toString(),
    val levelId: String,
    val center: Point2,
    val radiusMm: Double,
    val layer: String = "Чертёж",
) { init {
    require(id.isNotBlank() && levelId.isNotBlank() && layer.isNotBlank())
    require(radiusMm.isFinite() && radiusMm in 1.0..1000000.0)
} }

/** Angles in degrees, counterclockwise in world XY, sweep in (0,360). */
data class DraftArc(
    val id: String = UUID.randomUUID().toString(),
    val levelId: String,
    val center: Point2,
    val radiusMm: Double,
    val startDeg: Double,
    val sweepDeg: Double,
    val layer: String = "Чертёж",
) { init {
    require(id.isNotBlank() && levelId.isNotBlank() && layer.isNotBlank())
    require(radiusMm.isFinite() && radiusMm in 1.0..1000000.0)
    require(startDeg.isFinite() && sweepDeg.isFinite() && sweepDeg>0.0 && sweepDeg<360.0)
} }

enum class CadKind { LINE, POLYLINE, CIRCLE, ARC }
data class CadHit(val id: String, val kind: CadKind)

object CadEditing {
    private fun distance(a:Point2,b:Point2)=hypot(a.xMm-b.xMm,a.yMm-b.yMm)
    private fun editable(p:BimProject,layer:String) = p.draftLayers.any {it.name==layer && !it.locked}
    private fun validateTarget(p:BimProject,level:String,layer:String) {
        require(p.levels.any {it.id==level})
        require(editable(p,layer)) { "Слой отсутствует или заблокирован" }
    }
    fun addLayer(p:BimProject,name:String):BimProject {
        val value=name.trim()
        require(value.isNotBlank() && p.draftLayers.none {it.name.equals(value,ignoreCase=true)})
        return p.copy(draftLayers=p.draftLayers+DraftLayer(value))
    }
    fun updateLayer(p:BimProject,name:String,visible:Boolean,locked:Boolean):BimProject {
        require(p.draftLayers.any {it.name==name})
        return p.copy(draftLayers=p.draftLayers.map {if(it.name==name)it.copy(visible=visible,locked=locked) else it})
    }
    fun addPolyline(p:BimProject,level:String,vertices:List<Point2>,layer:String="Чертёж",closed:Boolean=false):BimProject {
        validateTarget(p,level,layer)
        return p.copy(polylines=p.polylines+DraftPolyline(levelId=level,vertices=vertices.toList(),closed=closed,layer=layer))
    }
    fun addCircle(p:BimProject,level:String,center:Point2,radiusMm:Double,layer:String="Чертёж"):BimProject {
        validateTarget(p,level,layer)
        return p.copy(circles=p.circles+DraftCircle(levelId=level,center=center,radiusMm=radiusMm,layer=layer))
    }
    fun addArcByPoints(p:BimProject,level:String,center:Point2,start:Point2,end:Point2,
                       layer:String="Чертёж"):BimProject {
        validateTarget(p,level,layer)
        val r=distance(center,start)
        require(r>=1.0)
        // The third tap determines the arc endpoint angle, while radius is set by tap two.
        require(distance(center,end)>=1.0)
        val a=normalize(Math.toDegrees(atan2(start.yMm-center.yMm,start.xMm-center.xMm)))
        val b=normalize(Math.toDegrees(atan2(end.yMm-center.yMm,end.xMm-center.xMm)))
        val sweep=normalize(b-a)
        require(sweep>0.01) { "Начальный и конечный углы совпадают" }
        return p.copy(arcs=p.arcs+DraftArc(levelId=level,center=center,radiusMm=r,startDeg=a,
            sweepDeg=sweep,layer=layer))
    }
    private fun normalize(a:Double)=((a%360.0)+360.0)%360.0
    fun nearest(p:BimProject,level:String,point:Point2,tolerance:Double):CadHit? {
        val visible=p.draftLayers.filter{it.visible}.map{it.name}.toSet()
        val hits=mutableListOf<Pair<CadHit,Double>>()
        p.draftLines.filter{it.levelId==level && it.layer in visible}.forEach { l ->
            hits+=CadHit(l.id,CadKind.LINE) to EditorEngine.pointToSegmentDistance(point,l.start,l.end)
        }
        p.polylines.filter{it.levelId==level && it.layer in visible}.forEach { poly ->
            val pairs=poly.vertices.zipWithNext()+if(poly.closed)listOf(poly.vertices.last() to poly.vertices.first()) else emptyList()
            hits+=CadHit(poly.id,CadKind.POLYLINE) to pairs.minOf { (a,b) -> EditorEngine.pointToSegmentDistance(point,a,b) }
        }
        p.circles.filter{it.levelId==level && it.layer in visible}.forEach { c ->
            hits+=CadHit(c.id,CadKind.CIRCLE) to abs(distance(point,c.center)-c.radiusMm)
        }
        p.arcs.filter{it.levelId==level && it.layer in visible}.forEach { a ->
            fun pos(degrees:Double):Point2 {
                val r=Math.toRadians(degrees)
                return Point2(a.center.xMm+a.radiusMm*cos(r),a.center.yMm+a.radiusMm*sin(r))
            }
            val angle=normalize(Math.toDegrees(atan2(point.yMm-a.center.yMm,point.xMm-a.center.xMm)))
            val offset=normalize(angle-a.startDeg)
            val dist=if(offset<=a.sweepDeg)abs(distance(point,a.center)-a.radiusMm)
                     else min(distance(point,pos(a.startDeg)),distance(point,pos(a.startDeg+a.sweepDeg)))
            hits+=CadHit(a.id,CadKind.ARC) to dist
        }
        return hits.filter{it.second<=tolerance}.minByOrNull{it.second}?.first
    }
    fun move(p:BimProject,hit:CadHit,dx:Double,dy:Double):BimProject {
        require(dx.isFinite() && dy.isFinite())
        fun shift(v:Point2)=Point2(v.xMm+dx,v.yMm+dy)
        return when(hit.kind) {
            CadKind.LINE -> {
                val old=p.draftLines.first{it.id==hit.id};require(editable(p,old.layer))
                p.copy(draftLines=p.draftLines.map{if(it.id==hit.id)it.copy(start=shift(it.start),end=shift(it.end)) else it})
            }
            CadKind.POLYLINE -> {
                val old=p.polylines.first{it.id==hit.id};require(editable(p,old.layer))
                p.copy(polylines=p.polylines.map{if(it.id==hit.id)it.copy(vertices=it.vertices.map(::shift)) else it})
            }
            CadKind.CIRCLE -> {
                val old=p.circles.first{it.id==hit.id};require(editable(p,old.layer))
                p.copy(circles=p.circles.map{if(it.id==hit.id)it.copy(center=shift(it.center)) else it})
            }
            CadKind.ARC -> {
                val old=p.arcs.first{it.id==hit.id};require(editable(p,old.layer))
                p.copy(arcs=p.arcs.map{if(it.id==hit.id)it.copy(center=shift(it.center)) else it})
            }
        }
    }
    fun changeLayer(p:BimProject,hit:CadHit,layer:String):BimProject {
        require(p.draftLayers.any{it.name==layer && !it.locked})
        return when(hit.kind) {
            CadKind.LINE -> p.copy(draftLines=p.draftLines.map {if(it.id==hit.id){require(editable(p,it.layer));it.copy(layer=layer)}else it})
            CadKind.POLYLINE -> p.copy(polylines=p.polylines.map {if(it.id==hit.id){require(editable(p,it.layer));it.copy(layer=layer)}else it})
            CadKind.CIRCLE -> p.copy(circles=p.circles.map {if(it.id==hit.id){require(editable(p,it.layer));it.copy(layer=layer)}else it})
            CadKind.ARC -> p.copy(arcs=p.arcs.map {if(it.id==hit.id){require(editable(p,it.layer));it.copy(layer=layer)}else it})
        }
    }
    fun delete(p:BimProject,hit:CadHit):BimProject {
        val layer=when(hit.kind) {
            CadKind.LINE -> p.draftLines.first{it.id==hit.id}.layer
            CadKind.POLYLINE -> p.polylines.first{it.id==hit.id}.layer
            CadKind.CIRCLE -> p.circles.first{it.id==hit.id}.layer
            CadKind.ARC -> p.arcs.first{it.id==hit.id}.layer
        }
        require(editable(p,layer))
        return when(hit.kind) {
            CadKind.LINE -> p.copy(draftLines=p.draftLines.filterNot{it.id==hit.id})
            CadKind.POLYLINE -> p.copy(polylines=p.polylines.filterNot{it.id==hit.id})
            CadKind.CIRCLE -> p.copy(circles=p.circles.filterNot{it.id==hit.id})
            CadKind.ARC -> p.copy(arcs=p.arcs.filterNot{it.id==hit.id})
        }
    }
}
