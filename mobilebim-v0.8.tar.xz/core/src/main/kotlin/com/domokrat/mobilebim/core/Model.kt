package com.domokrat.mobilebim.core

import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot

/** Shared units are millimetres. No Android or Autodesk APIs may appear in this module. */
data class Point2(val xMm: Double, val yMm: Double) {
    init { require(xMm.isFinite() && yMm.isFinite()) }
}

data class Level(val id: String = UUID.randomUUID().toString(), val name: String,
                 val elevationMm: Double) {
    init { require(id.isNotBlank() && name.isNotBlank() && elevationMm.isFinite()) }
}

data class Wall(
    val id: String = UUID.randomUUID().toString(), val levelId: String,
    val start: Point2, val end: Point2, val thicknessMm: Double = 200.0,
    val heightMm: Double = 3000.0, val material: String = "Условная конструкция",
    val typeId: String? = null,
) {
    init {
        require(id.isNotBlank() && levelId.isNotBlank())
        require(typeId == null || typeId.isNotBlank())
        require(thicknessMm in 50.0..2000.0) { "Толщина стены: 50–2000 мм" }
        require(heightMm in 300.0..30000.0) { "Высота стены: 300–30000 мм" }
        require(lengthMm >= 100.0) { "Длина стены должна быть не менее 100 мм" }
    }
    val lengthMm: Double get() = hypot(end.xMm-start.xMm, end.yMm-start.yMm)
}

enum class OpeningKind { DOOR, WINDOW }

/** An opening is a void hosted by a wall; its coordinate is measured from the wall start. */
data class Opening(
    val id: String = UUID.randomUUID().toString(),
    val wallId: String, val kind: OpeningKind,
    val offsetMm: Double, val widthMm: Double,
    val sillMm: Double, val heightMm: Double,
) {
    init {
        require(id.isNotBlank() && wallId.isNotBlank())
        require(offsetMm.isFinite() && offsetMm >= 0.0)
        require(widthMm in 300.0..6000.0)
        require(sillMm.isFinite() && sillMm >= 0.0)
        require(heightMm in 300.0..6000.0)
        if (kind == OpeningKind.DOOR) require(sillMm == 0.0) { "Дверь должна начинаться от пола" }
    }
    val endMm get() = offsetMm+widthMm
    val topMm get() = sillMm+heightMm
}

/** Horizontal slab outline. It can be concave, but must not self-intersect. */
data class Slab(
    val id: String = UUID.randomUUID().toString(),
    val levelId: String,
    val vertices: List<Point2>,
    val thicknessMm: Double = 200.0,
    val material: String = "Железобетон",
) {
    init {
        require(id.isNotBlank() && levelId.isNotBlank())
        require(thicknessMm in 50.0..2000.0)
        require(vertices.size in 3..500) { "Перекрытие: от 3 до 500 вершин" }
        require(Geometry.isSimplePolygon(vertices)) { "Некорректный или самопересекающийся контур" }
        require(areaMm2 >= 100000.0) { "Площадь перекрытия слишком мала" }
    }
    val areaMm2: Double get() = abs(Geometry.signedArea(vertices))
}

/** Schema v6: wall joining priorities, section cuts and CAD entities. */
data class BimProject(
    val schemaVersion: Int = 6,
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Новый проект",
    val levels: List<Level> = listOf(Level(name="Этаж 1", elevationMm=0.0)),
    val walls: List<Wall> = emptyList(),
    val openings: List<Opening> = emptyList(),
    val slabs: List<Slab> = emptyList(),
    val wallJoints: List<WallJoint> = emptyList(),
    val draftLines: List<DraftLine> = emptyList(),
    val dimensions: List<LinearDimension> = emptyList(),
    val draftLayers: List<DraftLayer> = listOf(DraftLayer(name="Чертёж")),
    val polylines: List<DraftPolyline> = emptyList(),
    val circles: List<DraftCircle> = emptyList(),
    val arcs: List<DraftArc> = emptyList(),
    val wallTypes: List<WallType> = emptyList(),
    val sections: List<SectionCut> = emptyList(),
) {
    init {
        require(schemaVersion == 6) { "Неподдерживаемая версия BIM-формата" }
        require(id.isNotBlank() && name.isNotBlank() && levels.isNotEmpty())
        require(levels.map { it.id }.distinct().size == levels.size)
        require(walls.map { it.id }.distinct().size == walls.size)
        require(openings.map { it.id }.distinct().size == openings.size)
        require(slabs.map { it.id }.distinct().size == slabs.size)
        require(draftLines.map { it.id }.distinct().size == draftLines.size)
        require(dimensions.map { it.id }.distinct().size == dimensions.size)
        require(polylines.map { it.id }.distinct().size == polylines.size)
        require(circles.map { it.id }.distinct().size == circles.size)
        require(arcs.map { it.id }.distinct().size == arcs.size)
        require(draftLayers.isNotEmpty() && draftLayers.map { it.name }.distinct().size == draftLayers.size)
        require(sections.map { it.id }.distinct().size == sections.size)
        require(wallTypes.map { it.id }.distinct().size == wallTypes.size)
        require(wallTypes.map { it.name }.distinct().size == wallTypes.size)
        val types=wallTypes.associateBy { it.id }
        walls.forEach { wall -> wall.typeId?.let { id ->
            val type=types[id] ?: error("Тип стены не найден")
            require(abs(type.thicknessMm-wall.thicknessMm)<0.001) { "Толщина экземпляра отличается от типа" }
        } }
        val layerNames=draftLayers.map { it.name }.toSet()
        require(draftLines.all { it.layer in layerNames })
        require(polylines.all { it.layer in layerNames })
        require(circles.all { it.layer in layerNames })
        require(arcs.all { it.layer in layerNames })
        val levelIds=levels.map { it.id }.toSet()
        require(sections.all { it.levelId in levelIds })
        require(walls.all { it.levelId in levelIds }) { "Стена ссылается на неизвестный этаж" }
        require(slabs.all { it.levelId in levelIds }) { "Перекрытие ссылается на неизвестный этаж" }
        require(draftLines.all { it.levelId in levelIds })
        require(dimensions.all { it.levelId in levelIds })
        require(polylines.all { it.levelId in levelIds })
        require(circles.all { it.levelId in levelIds })
        require(arcs.all { it.levelId in levelIds })
        val wallsById=walls.associateBy { it.id }
        dimensions.forEach { dim ->
            listOf(dim.first, dim.second).forEach { anchor ->
                anchor.wallId?.let { hostId ->
                    val host=wallsById[hostId] ?: error("Размер привязан к отсутствующей стене")
                    require(host.levelId == dim.levelId) { "Размер ссылается на другой этаж" }
                }
            }
        }
        require(wallJoints.map { it.guestWallId to it.guestEnd }.distinct().size == wallJoints.size) {
            "Один конец стены не может иметь несколько закреплений"
        }
        wallJoints.forEach { joint ->
            val guest=wallsById[joint.guestWallId] ?: error("Соединение ссылается на неизвестную стену")
            val host=wallsById[joint.hostWallId] ?: error("Соединение ссылается на неизвестную стену")
            require(guest.levelId == host.levelId) { "Соединение между разными этажами" }
            val p=if(joint.guestEnd==WallEnd.START) guest.start else guest.end
            val x=host.start.xMm+(host.end.xMm-host.start.xMm)*joint.hostT
            val y=host.start.yMm+(host.end.yMm-host.start.yMm)*joint.hostT
            require(kotlin.math.hypot(p.xMm-x,p.yMm-y)<0.0001) { "Соединение стены нарушено" }
        }
        val joinsByGuest = wallJoints.groupBy { it.guestWallId }
        fun visit(id:String, path:MutableSet<String>, visited:MutableSet<String>) {
            require(path.add(id)) { "Циклические соединения стен" }
            joinsByGuest[id].orEmpty().forEach { joint ->
                if (joint.hostWallId !in visited) visit(joint.hostWallId,path,visited)
            }
            path.remove(id);visited.add(id)
        }
        val visited=mutableSetOf<String>()
        walls.forEach { if(it.id !in visited) visit(it.id, mutableSetOf(),visited) }
        openings.forEach { opening ->
            val host=wallsById[opening.wallId]
                ?: throw IllegalArgumentException("Проём ссылается на несуществующую стену")
            require(opening.endMm <= host.lengthMm + 1e-6) { "Проём выходит за границу стены" }
            require(opening.topMm <= host.heightMm + 1e-6) { "Высота проёма больше высоты стены" }
        }
        openings.groupBy { it.wallId }.values.forEach { hosted ->
            for (i in hosted.indices) for (j in i+1 until hosted.size) {
                val a=hosted[i]; val b=hosted[j]
                val overlapX=a.offsetMm < b.endMm - 1e-6 && b.offsetMm < a.endMm - 1e-6
                val overlapZ=a.sillMm < b.topMm - 1e-6 && b.sillMm < a.topMm - 1e-6
                require(!(overlapX && overlapZ)) { "Проёмы пересекаются" }
            }
        }
    }
}
