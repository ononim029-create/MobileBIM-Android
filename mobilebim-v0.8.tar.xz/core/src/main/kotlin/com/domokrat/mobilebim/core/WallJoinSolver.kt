package com.domokrat.mobilebim.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Deterministic 2D layer collision resolver, independent of Android.
 * Layer bodies are convex quadrilaterals for the currently supported simple
 * corner/T joins. Higher [WallLayer.joinPriority] claims the overlapping area.
 * A stable (wall ID, layer index) tie-break prevents flicker when a model is reopened.
 *
 * Limitation: this is planar footprint resolution (2.5D), NOT a general BRep
 * Boolean engine. Only overlapping layers with identical vertical extents are
 * resolved. Different elevations/heights require height-sliced Booleans later.
 */
object WallJoinSolver {
    private const val EPS=1e-6
    data class Piece(val wallId:String,val layerIndex:Int,val material:String,
                     val polygon:List<Point2>,val priority:Int)
    data class Warning(val point:Point2,val detail:String)
    data class Result(val pieces:List<Piece>,val warnings:List<Warning>)

    private fun area(p:List<Point2>)=abs(Geometry.signedArea(p))
    private fun cross(a:Point2,b:Point2,p:Point2) =
        (b.xMm-a.xMm)*(p.yMm-a.yMm)-(b.yMm-a.yMm)*(p.xMm-a.xMm)
    private fun blend(a:Point2,b:Point2,t:Double) = Point2(a.xMm+(b.xMm-a.xMm)*t,
        a.yMm+(b.yMm-a.yMm)*t)
    private fun clean(points:List<Point2>):List<Point2> {
        val reduced=mutableListOf<Point2>()
        for(p in points) if(reduced.lastOrNull()?.let { kotlin.math.hypot(p.xMm-it.xMm,p.yMm-it.yMm)<EPS }!=true) reduced+=p
        if(reduced.size>=2 && kotlin.math.hypot(reduced.first().xMm-reduced.last().xMm,
                reduced.first().yMm-reduced.last().yMm)<EPS)reduced.removeAt(reduced.lastIndex)
        return if(reduced.size>=3 && area(reduced)>0.001) reduced else emptyList()
    }
    /** Split by directed infinite line; points on the line are on both boundaries. */
    fun halfPlane(poly:List<Point2>,a:Point2,b:Point2,keepLeft:Boolean):List<Point2> {
        if(poly.size<3)return emptyList()
        val out=mutableListOf<Point2>()
        fun signed(p:Point2)=cross(a,b,p)*(if(keepLeft)1.0 else -1.0)
        for(i in poly.indices) {
            val from=poly[i];val to=poly[(i+1)%poly.size]
            val s0=signed(from);val s1=signed(to)
            if(s0>=-EPS)out+=from
            if((s0>EPS && s1 < -EPS) || (s0 < -EPS && s1>EPS))
                out+=blend(from,to,s0/(s0-s1))
        }
        return clean(out)
    }
    /**
     * Convex subject minus convex cutter: disjoint convex pieces, no holes.
     * Walking cutter edges retains the 'outside' of each cut in order.
     */
    fun subtract(subject:List<Point2>,cutter:List<Point2>):List<List<Point2>> {
        if(subject.size<3 || cutter.size<3) return listOf(subject).filter{it.size>=3}
        var inside=subject
        val result=mutableListOf<List<Point2>>()
        val ccw=Geometry.signedArea(cutter)>0
        for(i in cutter.indices) {
            val a=cutter[i];val b=cutter[(i+1)%cutter.size]
            val outside=halfPlane(inside,a,b,!ccw)
            if(outside.isNotEmpty())result+=outside
            inside=halfPlane(inside,a,b,ccw)
            if(inside.isEmpty())break
        }
        return result
    }
    private fun overlaps(a:List<Point2>,b:List<Point2>):Boolean {
        fun bounds(p:List<Point2>)=listOf(p.minOf{it.xMm},p.maxOf{it.xMm},p.minOf{it.yMm},p.maxOf{it.yMm})
        val x=bounds(a);val y=bounds(b)
        return x[0]<y[1]-EPS && y[0]<x[1]-EPS && x[2]<y[3]-EPS && y[2]<x[3]-EPS
    }
    fun resolve(project:BimProject,levelId:String):Result {
        val walls=project.walls.filter{it.levelId==levelId}
        val byId=walls.associateBy{it.id}
        val priorities=project.wallTypes.associateBy{it.id}
        val source=walls.flatMap { w ->
            WallGeometry.footprints(project,w).map { f ->
                val priority=priorities[w.typeId]?.layers?.getOrNull(f.layerIndex)?.joinPriority?:0
                Piece(w.id,f.layerIndex,f.material,f.polygon,priority)
            }
        }
        // higher priority wins, then ID and layer index by a total deterministic ordering
        val ranked=source.sortedWith(compareByDescending<Piece>{it.priority}
            .thenBy{it.wallId}.thenBy{it.layerIndex})
        val resolved=mutableListOf<Piece>()
        val warnings=mutableListOf<Warning>()
        for(s in ranked) {
            var pending=listOf(s.polygon)
            val thisWall=byId.getValue(s.wallId)
            for(winner in resolved) {
                if(winner.wallId==s.wallId)continue // layer stripes in same wall never subtract each other
                val otherWall=byId.getValue(winner.wallId)
                if(!overlaps(s.polygon,winner.polygon))continue
                if(abs(thisWall.heightMm-otherWall.heightMm)>EPS) {
                    warnings+=Warning(thisWall.start,"Стены разной высоты: требуется 3D-сопряжение")
                    continue
                }
                pending=pending.flatMap { part ->
                    if(overlaps(part,winner.polygon))subtract(part,winner.polygon)else listOf(part)
                }
                if(pending.isEmpty())break
            }
            pending.forEach { if(area(it)>0.1)resolved+=s.copy(polygon=it) }
        }
        // Warnings for numerically complex or ambiguous shared multi-way nodes remain visible.
        val sharedEnds=WallGeometry.unresolvedMultiwayNodes(project,levelId)
        for(node in sharedEnds) warnings+=Warning(node,"Сложный узел: проверьте приоритет и материалы")
        return Result(resolved,warnings.distinctBy {it.point to it.detail})
    }
}
