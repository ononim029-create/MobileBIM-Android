package com.domokrat.mobilebim.core

import kotlin.math.abs
import kotlin.math.hypot

/** Non-persistent annotations derived from project BIM data for a section view. */
enum class MaterialHatch { CONCRETE, MASONRY, INSULATION, WOOD, GENERIC }

data class SectionLevelTag(val name:String,val elevationMm:Double)
data class SectionOpeningTag(
    val elementId:String,
    val name:String,
    val stationMm:Double,
    val widthMm:Double,
    val sillMm:Double,
    val headMm:Double,
)
data class SectionDocument(
    val name:String,
    val lengthMm:Double,
    val levels:List<SectionLevelTag>,
    val openings:List<SectionOpeningTag>,
    val parts:List<SectionRect>,
)

object SectionDocumentation {
    fun hatch(material:String):MaterialHatch {
        val m=material.lowercase()
        return when {
            listOf("бетон","железобетон","concrete").any{it in m}->MaterialHatch.CONCRETE
            listOf("кирпич","блок","газобетон","brick","masonry").any{it in m}->MaterialHatch.MASONRY
            listOf("утепл","минвата","изоляц","insulat","wool").any{it in m}->MaterialHatch.INSULATION
            listOf("дерев","древес","wood","timber").any{it in m}->MaterialHatch.WOOD
            else->MaterialHatch.GENERIC
        }
    }

    /**
     * Opening callouts only where a cut follows a wall axis through the opening.
     * At transverse wall cuts the opening may not be visible; guessing would give
     * misleading documentation, so no label is emitted there.
     */
    fun build(project:BimProject,cut:SectionCut):SectionDocument {
        val dx=(cut.end.xMm-cut.start.xMm)/cut.lengthMm
        val dy=(cut.end.yMm-cut.start.yMm)/cut.lengthMm
        val walls=project.walls.associateBy{it.id}
        val tags=project.openings.mapNotNull{opening->
            val wall=walls[opening.wallId]?:return@mapNotNull null
            val wx=(wall.end.xMm-wall.start.xMm)/wall.lengthMm
            val wy=(wall.end.yMm-wall.start.yMm)/wall.lengthMm
            if(abs(dx*wy-dy*wx)>0.02)return@mapNotNull null
            val fromX=wall.start.xMm-cut.start.xMm
            val fromY=wall.start.yMm-cut.start.yMm
            val offsetFromAxis=abs(dx*fromY-dy*fromX)
            if(offsetFromAxis>wall.thicknessMm*0.5+0.01)return@mapNotNull null
            val centerX=wall.start.xMm+wx*(opening.offsetMm+opening.widthMm/2)
            val centerY=wall.start.yMm+wy*(opening.offsetMm+opening.widthMm/2)
            val station=(centerX-cut.start.xMm)*dx+(centerY-cut.start.yMm)*dy
            if(station-opening.widthMm/2<0.0 || station+opening.widthMm/2>cut.lengthMm)
                return@mapNotNull null
            val z=project.levels.first{it.id==wall.levelId}.elevationMm
            SectionOpeningTag(wall.id,if(opening.kind==OpeningKind.DOOR)"Дверь" else "Окно",
                station,opening.widthMm,z+opening.sillMm,z+opening.topMm)
        }.sortedBy{it.stationMm}
        return SectionDocument(cut.name,cut.lengthMm,
            project.levels.sortedBy{it.elevationMm}.map{SectionLevelTag(it.name,it.elevationMm)},
            tags,SectionGeometry.build(project,cut))
    }
}
