package com.domokrat.mobilebim.core

import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot

/** Vertical cutting plane defined by a direction on the plan. Sections are model-derived. */
data class SectionCut(val id:String=UUID.randomUUID().toString(),val levelId:String,
                      val name:String,val start:Point2,val end:Point2) {
    init { require(id.isNotBlank() && levelId.isNotBlank() && name.isNotBlank())
        require(hypot(end.xMm-start.xMm,end.yMm-start.yMm)>=100.0) }
    val lengthMm get()=hypot(end.xMm-start.xMm,end.yMm-start.yMm)
}

data class SectionRect(val elementId:String,val material:String,val layerIndex:Int,
                       val leftMm:Double,val rightMm:Double,val bottomMm:Double,val topMm:Double) {
    init { require(rightMm>leftMm && topMm>bottomMm) }
}

/** 2.5D orthographic section through derived wall footprints and slabs. */
object SectionGeometry {
    private const val EPS=1e-7
    private fun cross(ax:Double,ay:Double,bx:Double,by:Double)=ax*by-ay*bx
    private fun mix(a:Point2,b:Point2,t:Double)=Point2(
        a.xMm+(b.xMm-a.xMm)*t,a.yMm+(b.yMm-a.yMm)*t)
    private fun clipParameters(cut:SectionCut,poly:List<Point2>):List<Double> {
        val a=cut.start;val b=cut.end
        val dx=b.xMm-a.xMm;val dy=b.yMm-a.yMm
        val ts=mutableListOf(0.0,1.0)
        for(i in poly.indices) {
            val u=poly[i];val v=poly[(i+1)%poly.size]
            val ex=v.xMm-u.xMm;val ey=v.yMm-u.yMm
            val det=cross(dx,dy,ex,ey)
            if(abs(det)<EPS)continue
            val qx=u.xMm-a.xMm;val qy=u.yMm-a.yMm
            val t=cross(qx,qy,ex,ey)/det
            val r=cross(qx,qy,dx,dy)/det
            if(t in -EPS..(1.0+EPS) && r in -EPS..(1.0+EPS))ts+=t.coerceIn(0.0,1.0)
        }
        return ts.sorted().fold(mutableListOf<Double>()){acc,t->
            if(acc.isEmpty() || t-acc.last()>1e-8)acc.add(t)
            acc
        }
    }
    private fun inside(poly:List<Point2>,at:Point2):Boolean = Geometry.containsPolygonPoint(poly,at)
    private fun intervals(cut:SectionCut,poly:List<Point2>):List<Pair<Double,Double>> {
        val ts=clipParameters(cut,poly)
        return ts.zipWithNext().filter { (a,b)->
            (b-a)*cut.lengthMm>0.01 && inside(poly,mix(cut.start,cut.end,(a+b)/2))
        }
    }
    fun build(project:BimProject,cut:SectionCut):List<SectionRect> {
        require(project.levels.any{it.id==cut.levelId})
        val levels=project.levels.associateBy{it.id}
        val walls=project.walls.associateBy{it.id}
        val cuts=mutableListOf<SectionRect>()
        for(level in project.levels) {
            val resolved=WallJoinSolver.resolve(project,level.id)
            for(piece in resolved.pieces) {
                val wall=walls.getValue(piece.wallId)
                val base=levels.getValue(wall.levelId).elevationMm
                for((begin,end) in intervals(cut,piece.polygon)) {
                    // Slice additionally at projected opening jambs. The midpoint of
                    // each interval unambiguously belongs (or not) to an opening.
                    val projectionStart=Geometry.wallProjection(wall,cut.start)
                    val projectionEnd=Geometry.wallProjection(wall,cut.end)
                    val positions=mutableListOf(begin,end)
                    val open=project.openings.filter{it.wallId==wall.id}
                    if(abs(projectionEnd-projectionStart)>EPS)for(o in open) {
                        for(atMm in listOf(o.offsetMm,o.endMm)) {
                            val t=(atMm/wall.lengthMm-projectionStart)/(projectionEnd-projectionStart)
                            if(t>begin+EPS && t<end-EPS)positions+=t
                        }
                    }
                    val x=positions.sorted().distinct()
                    for((s,e) in x.zipWithNext()) {
                        if((e-s)*cut.lengthMm<=0.01)continue
                        val midpoint=(s+e)*0.5
                        val location=projectionStart+(projectionEnd-projectionStart)*midpoint
                        val along=location*wall.lengthMm
                        val holes=open.filter{along>it.offsetMm+EPS && along<it.endMm-EPS}
                        var bands=listOf(0.0 to wall.heightMm)
                        for(hole in holes) bands=bands.flatMap { (bottom,top) ->
                            listOf(bottom to kotlin.math.min(top,hole.sillMm),
                                kotlin.math.max(bottom,hole.topMm) to top)
                                .filter{it.second-it.first>0.01}
                        }
                        for((bottom,top) in bands)cuts+=SectionRect(wall.id,piece.material,
                            piece.layerIndex,s*cut.lengthMm,e*cut.lengthMm,base+bottom,base+top)
                    }
                }
            }
        }
        project.slabs.forEach {slab->
            val level=levels.getValue(slab.levelId)
            for((a,b) in intervals(cut,slab.vertices)) {
                cuts+=SectionRect(slab.id,slab.material,-1,a*cut.lengthMm,b*cut.lengthMm,
                    level.elevationMm-slab.thicknessMm,level.elevationMm)
            }
        }
        return cuts.sortedWith(compareBy({it.bottomMm},{it.leftMm},{it.layerIndex}))
    }
}
