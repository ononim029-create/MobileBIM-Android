package com.domokrat.mobilebim.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object Geometry {
    fun signedArea(vertices: List<Point2>): Double = vertices.indices.sumOf { i ->
        val a=vertices[i];val b=vertices[(i+1)%vertices.size]
        a.xMm*b.yMm-b.xMm*a.yMm
    } / 2.0

    private fun cross(a:Point2,b:Point2,c:Point2):Double =
        (b.xMm-a.xMm)*(c.yMm-a.yMm)-(b.yMm-a.yMm)*(c.xMm-a.xMm)

    private fun onSegment(a:Point2,b:Point2,p:Point2):Boolean =
        abs(cross(a,b,p))<1e-6 && p.xMm>=min(a.xMm,b.xMm)-1e-6 &&
        p.xMm<=max(a.xMm,b.xMm)+1e-6 && p.yMm>=min(a.yMm,b.yMm)-1e-6 &&
        p.yMm<=max(a.yMm,b.yMm)+1e-6

    private fun intersects(a:Point2,b:Point2,c:Point2,d:Point2):Boolean {
        val ac=cross(a,b,c);val ad=cross(a,b,d)
        val ca=cross(c,d,a);val cb=cross(c,d,b)
        if ((ac>0 && ad<0 || ac<0 && ad>0) && (ca>0 && cb<0 || ca<0 && cb>0)) return true
        return onSegment(a,b,c) || onSegment(a,b,d) || onSegment(c,d,a) || onSegment(c,d,b)
    }

    fun isSimplePolygon(points:List<Point2>):Boolean {
        val n=points.size
        if (n<3 || abs(signedArea(points))<1e-6) return false
        for(i in 0 until n) {
            val a=points[i];val b=points[(i+1)%n]
            if (a==b) return false
            for(j in i+1 until n) {
                if (j==i+1 || i==0 && j==n-1) continue
                if(intersects(a,b,points[j],points[(j+1)%n])) return false
            }
        }
        return true
    }

    fun containsPolygonPoint(vertices:List<Point2>, p:Point2):Boolean {
        var inside=false
        for(i in vertices.indices) {
            val a=vertices[i]; val b=vertices[(i+1)%vertices.size]
            if(onSegment(a,b,p)) return true
            if((a.yMm>p.yMm)!=(b.yMm>p.yMm)) {
                val x=a.xMm+(p.yMm-a.yMm)*(b.xMm-a.xMm)/(b.yMm-a.yMm)
                if(p.xMm<x) inside=!inside
            }
        }
        return inside
    }

    /** Centerline coordinate 0..1 of a projected point, unclamped for edge checking. */
    fun wallProjection(wall:Wall,p:Point2):Double {
        val dx=wall.end.xMm-wall.start.xMm;val dy=wall.end.yMm-wall.start.yMm
        return ((p.xMm-wall.start.xMm)*dx+(p.yMm-wall.start.yMm)*dy)/(dx*dx+dy*dy)
    }
}
