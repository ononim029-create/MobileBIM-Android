package com.domokrat.mobilebim.core

import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot

/** A loose 2D drafting entity: intentionally not linked to a structural element. */
data class DraftLine(
    val id: String = UUID.randomUUID().toString(),
    val levelId: String,
    val start: Point2,
    val end: Point2,
    val layer: String = "Чертёж",
) {
    init {
        require(id.isNotBlank() && levelId.isNotBlank() && layer.isNotBlank())
        require(hypot(end.xMm - start.xMm, end.yMm - start.yMm) >= 1.0) { "Линия должна быть не короче 1 мм" }
    }
}

/** A reference to a wall endpoint OR an independent point. The point is a snapshot for fallback. */
data class DimensionAnchor(
    val point: Point2,
    val wallId: String? = null,
    val wallEnd: WallEnd? = null,
) {
    init { require((wallId == null) == (wallEnd == null)) }
}

/** Aligned measurement. Positive offset displaces the line to the left of first -> second. */
data class LinearDimension(
    val id: String = UUID.randomUUID().toString(),
    val levelId: String,
    val first: DimensionAnchor,
    val second: DimensionAnchor,
    val offsetMm: Double = 500.0,
) {
    init {
        require(id.isNotBlank() && levelId.isNotBlank())
        require(offsetMm.isFinite() && abs(offsetMm) <= 100000.0)
    }
}

object PlanEditing {
    fun openingCenter(project: BimProject, opening: Opening): Point2 {
        val host = project.walls.first { it.id == opening.wallId }
        val t = (opening.offsetMm + opening.widthMm / 2.0) / host.lengthMm
        return Point2(host.start.xMm + (host.end.xMm - host.start.xMm) * t,
            host.start.yMm + (host.end.yMm - host.start.yMm) * t)
    }

    fun moveOpeningCenter(project: BimProject, id: String, at: Point2): BimProject {
        val opening = project.openings.firstOrNull { it.id == id } ?: error("Проём не найден")
        val host = project.walls.first { it.id == opening.wallId }
        val offset = (Geometry.wallProjection(host, at) * host.lengthMm - opening.widthMm / 2.0)
            .coerceIn(0.0, host.lengthMm - opening.widthMm)
        // BimProject performs collision and wall-boundary validation; failed moves are atomic.
        return project.copy(openings = project.openings.map {
            if (it.id == id) it.copy(offsetMm = offset) else it
        })
    }

    fun moveSlabVertex(project: BimProject, id: String, vertex: Int, point: Point2): BimProject {
        val slab = project.slabs.firstOrNull { it.id == id } ?: error("Перекрытие не найдено")
        require(vertex in slab.vertices.indices) { "Вершина контура не найдена" }
        return project.copy(slabs = project.slabs.map {
            if (it.id == id) it.copy(vertices = it.vertices.mapIndexed { i, p -> if (i == vertex) point else p }) else it
        })
    }

    fun translateSlab(project: BimProject, id: String, dxMm: Double, dyMm: Double): BimProject {
        require(dxMm.isFinite() && dyMm.isFinite())
        require(project.slabs.any { it.id == id })
        return project.copy(slabs = project.slabs.map { slab ->
            if (slab.id == id) slab.copy(vertices = slab.vertices.map { Point2(it.xMm + dxMm, it.yMm + dyMm) })
            else slab
        })
    }

    fun addDraftLine(project: BimProject, levelId: String, a: Point2, b: Point2,
                     layer: String = "Чертёж"): BimProject {
        require(project.levels.any { it.id == levelId })
        require(project.draftLayers.any { it.name==layer && !it.locked })
        return project.copy(draftLines = project.draftLines + DraftLine(levelId = levelId,
            start = a, end = b, layer=layer))
    }

    fun deleteDraftLine(project: BimProject, id: String) =
        CadEditing.delete(project,CadHit(id,CadKind.LINE))

    fun nearestDraftLine(project: BimProject, levelId: String, p: Point2, tolerance: Double): DraftLine? =
        project.draftLines.asReversed().firstOrNull {
            it.levelId == levelId && project.draftLayers.any { layer -> layer.name==it.layer && layer.visible } &&
            EditorEngine.pointToSegmentDistance(p, it.start, it.end) <= tolerance
        }

    fun anchored(project: BimProject, snap: SnapResult): DimensionAnchor {
        val wall = snap.hostWallId?.let { id -> project.walls.firstOrNull { it.id == id } }
        val end = when {
            wall == null || snap.kind != SnapKind.WALL_ENDPOINT -> null
            snap.hostT == 0.0 -> WallEnd.START
            snap.hostT == 1.0 -> WallEnd.END
            else -> null
        }
        return if (wall != null && end != null) DimensionAnchor(snap.point, wall.id, end)
        else DimensionAnchor(snap.point)
    }

    fun resolvedAnchor(project: BimProject, anchor: DimensionAnchor): Point2 {
        val wall = project.walls.firstOrNull { it.id == anchor.wallId } ?: return anchor.point
        return when (anchor.wallEnd) {
            WallEnd.START -> wall.start
            WallEnd.END -> wall.end
            null -> anchor.point
        }
    }

    fun freezeAnchor(project: BimProject, anchor: DimensionAnchor): DimensionAnchor =
        DimensionAnchor(resolvedAnchor(project, anchor))

    fun addDimension(project: BimProject, levelId: String, first: SnapResult, second: SnapResult,
                     offsetMm: Double = 500.0): BimProject {
        require(project.levels.any { it.id == levelId })
        val a = anchored(project, first)
        val b = anchored(project, second)
        require(hypot(a.point.xMm - b.point.xMm, a.point.yMm - b.point.yMm) >= 1.0) {
            "Для размера нужны разные точки"
        }
        return project.copy(dimensions = project.dimensions +
            LinearDimension(levelId = levelId, first = a, second = b, offsetMm = offsetMm))
    }

    fun changeDimensionOffset(project: BimProject, id: String, offsetMm: Double): BimProject {
        require(project.dimensions.any { it.id == id })
        return project.copy(dimensions = project.dimensions.map {
            if (it.id == id) it.copy(offsetMm = offsetMm) else it
        })
    }

    fun deleteDimension(project: BimProject, id: String) =
        project.copy(dimensions = project.dimensions.filterNot { it.id == id })

    /** Returns two dimension-line endpoints and actual measurement in mm. */
    fun dimensionPoints(project: BimProject, dim: LinearDimension): Triple<Point2, Point2, Double>? {
        val a = resolvedAnchor(project, dim.first)
        val b = resolvedAnchor(project, dim.second)
        val length = hypot(b.xMm - a.xMm, b.yMm - a.yMm)
        if (length < 1.0) return null
        val nx = -(b.yMm - a.yMm) / length
        val ny = (b.xMm - a.xMm) / length
        return Triple(Point2(a.xMm + nx * dim.offsetMm, a.yMm + ny * dim.offsetMm),
            Point2(b.xMm + nx * dim.offsetMm, b.yMm + ny * dim.offsetMm), length)
    }

    fun nearestDimension(project: BimProject, levelId: String, p: Point2, tolerance: Double): LinearDimension? =
        project.dimensions.asReversed().firstOrNull { dim ->
            if (dim.levelId != levelId) false else dimensionPoints(project, dim)?.let { (a, b, _) ->
                EditorEngine.pointToSegmentDistance(p, a, b) <= tolerance
            } == true
        }
}
