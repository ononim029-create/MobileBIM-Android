package com.domokrat.mobilebim.core

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Persistent wall junction. The guest endpoint follows a position along the host wall axis. */
enum class WallEnd { START, END }
data class WallJoint(
    val guestWallId: String,
    val guestEnd: WallEnd,
    val hostWallId: String,
    val hostT: Double,
) {
    init {
        require(guestWallId.isNotBlank() && hostWallId.isNotBlank() && guestWallId != hostWallId)
        require(hostT.isFinite() && hostT in 0.0..1.0)
    }
}

enum class SnapKind { GRID, WALL_ENDPOINT, WALL_MIDPOINT, WALL_AXIS, INTERSECTION }
data class SnapResult(
    val point: Point2, val kind: SnapKind,
    val hostWallId: String? = null, val hostT: Double? = null,
)

/** Wall editing and snapping without UI dependencies. Geometry is always in millimetres. */
object WallEditing {
    private fun position(w: Wall, t: Double) = Point2(
        w.start.xMm + (w.end.xMm - w.start.xMm) * t,
        w.start.yMm + (w.end.yMm - w.start.yMm) * t,
    )
    private fun distance(a: Point2, b: Point2) = hypot(a.xMm - b.xMm, a.yMm - b.yMm)
    private fun projected(w: Wall, p: Point2) =
        Geometry.wallProjection(w, p).coerceIn(0.0, 1.0)
    private fun cross(ax: Double, ay: Double, bx: Double, by: Double) = ax * by - ay * bx

    private fun intersect(a: Wall, b: Wall): Point2? {
        val rx = a.end.xMm - a.start.xMm
        val ry = a.end.yMm - a.start.yMm
        val sx = b.end.xMm - b.start.xMm
        val sy = b.end.yMm - b.start.yMm
        val divisor = cross(rx, ry, sx, sy)
        if (abs(divisor) < 1e-8) return null
        val qx = b.start.xMm - a.start.xMm
        val qy = b.start.yMm - a.start.yMm
        val t = cross(qx, qy, sx, sy) / divisor
        val u = cross(qx, qy, rx, ry) / divisor
        if (t !in 0.0..1.0 || u !in 0.0..1.0) return null
        return position(a, t)
    }

    /** Priority: existing endpoints, wall intersections, midpoint, axis, then 100 mm grid. */
    fun snap(
        project: BimProject, levelId: String, raw: Point2,
        toleranceMm: Double = 200.0, excludeWallId: String? = null,
        gridMm: Double = 100.0,
    ): SnapResult {
        require(toleranceMm.isFinite() && toleranceMm >= 0.0)
        val walls = project.walls.filter { it.levelId == levelId && it.id != excludeWallId }
        val candidates = mutableListOf<Triple<Int, Double, SnapResult>>()
        fun add(priority: Int, snap: SnapResult) {
            val d = distance(raw, snap.point)
            if (d <= toleranceMm) candidates.add(Triple(priority, d, snap))
        }
        for (w in walls) {
            add(0, SnapResult(w.start, SnapKind.WALL_ENDPOINT, w.id, 0.0))
            add(0, SnapResult(w.end, SnapKind.WALL_ENDPOINT, w.id, 1.0))
            add(2, SnapResult(position(w, 0.5), SnapKind.WALL_MIDPOINT, w.id, 0.5))
            val t = projected(w, raw)
            if (t > 1e-6 && t < 1.0 - 1e-6)
                add(3, SnapResult(position(w, t), SnapKind.WALL_AXIS, w.id, t))
        }
        // No special persisted junction is added at a crossing; the snap is positional only.
        for (i in walls.indices) for (j in i + 1 until walls.size) {
            val hit = intersect(walls[i], walls[j]) ?: continue
            add(1, SnapResult(hit, SnapKind.INTERSECTION, walls[i].id, projected(walls[i], hit)))
        }
        return candidates.minWithOrNull(compareBy<Triple<Int, Double, SnapResult>> { it.first }
            .thenBy { it.second })?.third ?: SnapResult(EditorEngine.snap(raw, gridMm), SnapKind.GRID)
    }

    private fun withPropagatedJoints(project: BimProject, newWalls: List<Wall>, joints: List<WallJoint>): BimProject {
        val byId = newWalls.associateBy { it.id }.toMutableMap()
        val byGuest = joints.groupBy { it.guestWallId }
        val completed = mutableSetOf<String>()
        val visiting = mutableSetOf<String>()
        fun resolve(id: String) {
            if (id in completed) return
            check(visiting.add(id)) { "Циклические соединения стен" }
            var guest = byId[id] ?: error("Неизвестная стена в соединении")
            // Resolve all upstream hosts before updating this wall's endpoints.
            for (joint in byGuest[id].orEmpty()) {
                resolve(joint.hostWallId)
                val host = byId.getValue(joint.hostWallId)
                val contact = position(host, joint.hostT)
                guest = when (joint.guestEnd) {
                    WallEnd.START -> guest.copy(start = contact)
                    WallEnd.END -> guest.copy(end = contact)
                }
            }
            byId[id] = guest
            visiting.remove(id)
            completed.add(id)
        }
        for (wall in newWalls) resolve(wall.id)
        return project.copy(walls = newWalls.map { byId.getValue(it.id) }, wallJoints = joints)
    }

    /** Draw a new wall with persistent endpoint-to-host associations. */
    fun addSnappedWall(
        project: BimProject, levelId: String,
        start: SnapResult, end: SnapResult,
        thicknessMm: Double = 200.0, heightMm: Double = 3000.0,
        typeId: String? = null,
    ): BimProject {
        val type = typeId?.let { id -> project.wallTypes.firstOrNull {it.id==id}
            ?: error("Тип стены не найден") }
        require(type==null || kotlin.math.abs(type.thicknessMm-thicknessMm)<0.001)
        val wall = Wall(levelId = levelId, start = start.point, end = end.point,
            thicknessMm = thicknessMm, heightMm = heightMm,
            typeId = type?.id, material = type?.name ?: "Условная конструкция")
        val joints = project.wallJoints.toMutableList()
        listOf(WallEnd.START to start, WallEnd.END to end).forEach { (which, result) ->
            val host = result.hostWallId
            val t = result.hostT
            if (host != null && t != null) joints.add(WallJoint(wall.id, which, host, t))
        }
        return withPropagatedJoints(project, project.walls + wall, joints)
    }

    /** End-handle drag. A dragged endpoint detaches from its old host and reattaches if snapped. */
    fun moveEndpoint(
        project: BimProject, wallId: String, end: WallEnd,
        target: Point2, toleranceMm: Double = 200.0,
        useSnaps: Boolean = true,
    ): BimProject {
        val wall = project.walls.firstOrNull { it.id == wallId } ?: error("Стена не найдена")
        val result = if(useSnaps)
            snap(project, wall.levelId, target, toleranceMm, excludeWallId = wallId)
            else SnapResult(target, SnapKind.GRID)
        val modified = if (end == WallEnd.START) wall.copy(start = result.point) else wall.copy(end = result.point)
        val joints = project.wallJoints.filterNot { it.guestWallId == wallId && it.guestEnd == end }.toMutableList()
        if (result.hostWallId != null && result.hostT != null &&
            !dependsOn(project.wallJoints, result.hostWallId, wallId)) {
            joints.add(WallJoint(wallId, end, result.hostWallId, result.hostT))
        }
        return withPropagatedJoints(project, project.walls.map { if (it.id == wallId) modified else it }, joints)
    }

    private fun dependsOn(joints: List<WallJoint>, startId: String, wantedId: String): Boolean {
        val queue = ArrayDeque<String>()
        val checked = mutableSetOf<String>()
        queue.add(startId)
        while (queue.isNotEmpty()) {
            val current = queue.removeFirst()
            if (current == wantedId) return true
            if (checked.add(current)) joints.filter { it.guestWallId == current }
                .forEach { queue.add(it.hostWallId) }
        }
        return false
    }

    /** Translate a wall. Its inbound host attachments are released, dependants follow. */
    fun translateWall(project: BimProject, wallId: String, dxMm: Double, dyMm: Double): BimProject {
        require(dxMm.isFinite() && dyMm.isFinite())
        val w = project.walls.firstOrNull { it.id == wallId } ?: error("Стена не найдена")
        fun shifted(p: Point2) = Point2(p.xMm + dxMm, p.yMm + dyMm)
        val changed = w.copy(start = shifted(w.start), end = shifted(w.end))
        return withPropagatedJoints(project, project.walls.map { if (it.id == wallId) changed else it },
            project.wallJoints.filterNot { it.guestWallId == wallId })
    }

    /** Exact numeric wall geometry. An endpoint retains its host only when unchanged. */
    fun setGeometry(project: BimProject, wallId: String, start: Point2, lengthMm: Double, angleDeg: Double): BimProject {
        require(lengthMm.isFinite() && lengthMm >= 100.0)
        require(angleDeg.isFinite())
        val radians = Math.toRadians(angleDeg)
        val end = Point2(start.xMm + lengthMm * cos(radians), start.yMm + lengthMm * sin(radians))
        val old = project.walls.firstOrNull { it.id == wallId } ?: error("Стена не найдена")
        // Preserve exact coordinates for unchanged endpoints to avoid rounding-related joint drift.
        val stableStart = if (distance(old.start, start) < 0.01) old.start else start
        val stableEnd = if (distance(old.end, end) < 0.01) old.end else end
        val adjusted = old.copy(start = stableStart, end = stableEnd)
        val preserved = project.wallJoints.filterNot {
            it.guestWallId == wallId && when(it.guestEnd) {
                WallEnd.START -> stableStart != old.start
                WallEnd.END -> stableEnd != old.end
            }
        }
        return withPropagatedJoints(project, project.walls.map { if (it.id == wallId) adjusted else it }, preserved)
    }

    fun degrees(wall: Wall): Double = Math.toDegrees(atan2(
        wall.end.yMm - wall.start.yMm, wall.end.xMm - wall.start.xMm))

    fun removeWall(project: BimProject, wallId: String): BimProject {
        val wall = project.walls.firstOrNull { it.id == wallId } ?: return project
        // A disconnected guest keeps the current geometric position of its endpoint.
        val dimensions = project.dimensions.map { dim ->
            dim.copy(
                first = if (dim.first.wallId == wallId) PlanEditing.freezeAnchor(project, dim.first) else dim.first,
                second = if (dim.second.wallId == wallId) PlanEditing.freezeAnchor(project, dim.second) else dim.second,
            )
        }
        return project.copy(dimensions = dimensions, walls = project.walls.filterNot { it.id == wall.id },
            openings = project.openings.filterNot { it.wallId == wall.id },
            wallJoints = project.wallJoints.filterNot { it.guestWallId == wall.id || it.hostWallId == wall.id })
    }
}
