package com.domokrat.mobilebim.core

import java.util.UUID
import kotlin.math.abs

data class WallLayer(val material:String,val thicknessMm:Double,
                     val joinPriority:Int=0) {
    init {
        require(material.isNotBlank())
        require(joinPriority in 0..1000) { "Приоритет соединения: 0–1000" }
        require(thicknessMm.isFinite() && thicknessMm>=1.0 && thicknessMm<=2000.0)
    }
}

data class WallType(
    val id:String=UUID.randomUUID().toString(),
    val name:String,
    /** Layers follow the user-defined cross-section order. */
    val layers:List<WallLayer>,
) {
    val thicknessMm get()=layers.sumOf{it.thicknessMm}
    init {
        require(id.isNotBlank() && name.isNotBlank())
        require(layers.size in 1..50)
        require(thicknessMm in 50.0..2000.0)
    }
}

object WallTypes {
    /** Legacy untyped walls are intentionally retained until explicitly assigned a type. */
    fun create(p:BimProject,name:String,layers:List<WallLayer>):BimProject {
        require(p.wallTypes.none{it.name.equals(name.trim(),ignoreCase=true)})
        return p.copy(wallTypes=p.wallTypes+WallType(name=name.trim(),layers=layers.toList()))
    }
    fun assign(p:BimProject,wallId:String,typeId:String):BimProject {
        val type=p.wallTypes.firstOrNull{it.id==typeId}?:error("Тип стены не найден")
        require(p.walls.any{it.id==wallId})
        return p.copy(walls=p.walls.map{if(it.id==wallId)it.copy(typeId=typeId,
            thicknessMm=type.thicknessMm,material=type.name)else it})
    }
    /** Editing a shared type propagates total thickness to all its instances atomically. */
    fun editType(p:BimProject,id:String,name:String,layers:List<WallLayer>):BimProject {
        require(p.wallTypes.any{it.id==id})
        require(p.wallTypes.none{it.id!=id && it.name.equals(name.trim(),ignoreCase=true)})
        val next=WallType(id=id,name=name.trim(),layers=layers.toList())
        return p.copy(wallTypes=p.wallTypes.map{if(it.id==id)next else it},
            walls=p.walls.map{if(it.typeId==id)it.copy(thicknessMm=next.thicknessMm,material=next.name) else it})
    }
    /** A single wall can be detached; subsequent edits of its former type won't affect it. */
    fun detach(p:BimProject,wallId:String):BimProject = p.copy(walls=p.walls.map {
        if(it.id==wallId)it.copy(typeId=null)else it
    })
    fun addWall(p:BimProject,levelId:String,a:Point2,b:Point2,typeId:String,height:Double=3000.0):BimProject {
        val type=p.wallTypes.firstOrNull{it.id==typeId}?:error("Тип стены не найден")
        return p.copy(walls=p.walls+Wall(levelId=levelId,start=a,end=b,heightMm=height,
            thicknessMm=type.thicknessMm,material=type.name,typeId=type.id))
    }
}
