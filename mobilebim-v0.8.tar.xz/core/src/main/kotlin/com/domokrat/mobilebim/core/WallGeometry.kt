package com.domokrat.mobilebim.core

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * Derived plan geometry. Wall centre-lines and wall types remain the ONLY editable source of truth.
 * This data is not serialized, so changes to any wall/type automatically rebuild its footprints.
 * Coordinate system: millimetres, all layers run from the right to the left of the wall axis.
 */
data class WallLayerFootprint(
    val wallId: String,
    val layerIndex: Int,
    val material: String,
    val polygon: List<Point2>, // start-right, end-right, end-left, start-left
)

enum class WallCornerKind { BUTT, MITER, T_JOIN }

data class WallEndGeometry(val kind: WallCornerKind, val neighbourId: String? = null)

object WallGeometry {
    private const val EPS = 1e-7
    private const val CONNECTION_TOL_MM = 0.05
    private data class V(val x: Double, val y: Double) {
        operator fun plus(v: V) = V(x+v.x,y+v.y)
        operator fun minus(v: V) = V(x-v.x,y-v.y)
        operator fun times(f: Double) = V(x*f,y*f)
        fun dot(v: V) = x*v.x+y*v.y
        fun cross(v: V) = x*v.y-y*v.x
        val length get() = hypot(x,y)
        fun point() = Point2(x,y)
    }
    private fun vec(p: Point2) = V(p.xMm,p.yMm)
    private fun axis(w: Wall) = (vec(w.end)-vec(w.start))*(1.0/w.lengthMm)
    private fun normal(w: Wall): V { val v=axis(w);return V(-v.y,v.x) }
    private fun endpoint(w: Wall, isStart: Boolean) = vec(if(isStart)w.start else w.end)
    private fun outward(w: Wall,isStart: Boolean) = axis(w)*(if(isStart)1.0 else -1.0)
    private fun lineCross(p:V,dir:V,q:V,otherDir:V):V? {
        val divisor=dir.cross(otherDir)
        if(abs(divisor)<EPS)return null
        return p+dir*((q-p).cross(otherDir)/divisor)
    }
    private fun near(a:V,b:V):Boolean = (a-b).length<=CONNECTION_TOL_MM
    private data class Link(val neighbour:Wall,val nearHostFace:Boolean,val hostT:Double=0.0)

    /** L-miters are inferred only for exactly two coincident wall ends on a level.
     *  T-junctions use explicit WallJoint first; otherwise infer an endpoint on a host axis.
     *  Complex 3+-wall/multi-way junctions deliberately remain unmodified until solved robustly.
     */
    private fun link(p:BimProject,w:Wall,isStart:Boolean):Link? {
        val origin=endpoint(w,isStart)
        val peers=p.walls.filter{it.id!=w.id && it.levelId==w.levelId}
        val endpointPeers=peers.filter { near(origin,vec(it.start)) || near(origin,vec(it.end)) }
        if(endpointPeers.size==1) {
            val peer=endpointPeers.single()
            if(abs(axis(w).cross(axis(peer)))>0.1) return Link(peer,false)
        }
        if(endpointPeers.size>1)return null // no implicit miter on multi-way nodes
        val recorded=p.wallJoints.firstOrNull{it.guestWallId==w.id &&
            it.guestEnd==(if(isStart)WallEnd.START else WallEnd.END)}
        val candidates= if(recorded!=null) peers.filter{it.id==recorded.hostWallId} else peers
        val found=candidates.mapNotNull { host ->
            val t=Geometry.wallProjection(host,origin.point())
            val point=vec(host.start)+(vec(host.end)-vec(host.start))*t
            val distance=(origin-point).length
            // Don't trim walls that merely cross in the middle or attach at a host endpoint.
            // Those require a different solid-union treatment.
            if(t !in 0.02..0.98 || distance>CONNECTION_TOL_MM) null
            else if(abs(outward(w,isStart).dot(normal(host)))<0.25) null
            else Triple(host,t,distance)
        }.minByOrNull{it.third}
        return found?.let { Link(it.first,true,it.second) }
    }

    fun endGeometry(p:BimProject,w:Wall,isStart:Boolean):WallEndGeometry {
        val l=link(p,w,isStart) ?: return WallEndGeometry(WallCornerKind.BUTT)
        return WallEndGeometry(if(l.nearHostFace)WallCornerKind.T_JOIN else WallCornerKind.MITER,l.neighbour.id)
    }

    /** Compute a point on a wall's offset line with its end adjusted for a miter/T joint. */
    private fun edgeEnd(p:BimProject,w:Wall,isStart:Boolean,offsetMm:Double):Point2 {
        val center=endpoint(w,isStart)
        val d=outward(w,isStart)
        val first=center+normal(w)*offsetMm
        val l=link(p,w,isStart) ?: return first.point()
        val peer=l.neighbour
        val adjusted=if(l.nearHostFace) {
            val hostN=normal(peer)
            val facing=if(d.dot(hostN)>=0.0)1.0 else -1.0
            val face=center+hostN*(peer.thicknessMm*0.5*facing)
            lineCross(first,d,face,axis(peer))
        } else {
            val peerAtStart=near(center,vec(peer.start))
            val peerOut=outward(peer,peerAtStart)
            // Opposite 'outward sides' meet at the same corner.
            val outwardOffset=offsetMm*(if(isStart)1.0 else -1.0)
            val peerOutOffset=-outwardOffset*peer.thicknessMm/w.thicknessMm
            val peerCanonicalOffset=peerOutOffset*(if(peerAtStart)1.0 else -1.0)
            val other=endpoint(peer,peerAtStart)+normal(peer)*peerCanonicalOffset
            lineCross(first,d,other,peerOut)
        } ?: return first.point()
        // Avoid huge miters at acute angles or inverted walls shorter than their thickness.
        val move=(adjusted-first).length
        if(!move.isFinite() || move>max(4*w.thicknessMm,4*peer.thicknessMm) ||
            (adjusted-center).dot(d) > w.lengthMm-1.0) return first.point()
        return adjusted.point()
    }

    /** Ordered stripes for a wall. Untyped legacy walls are represented by one stripe. */
    fun footprints(p:BimProject,w:Wall):List<WallLayerFootprint> {
        val type=p.wallTypes.find{it.id==w.typeId}
        val layers=type?.layers ?: listOf(WallLayer(w.material.ifBlank{"Конструкция"},w.thicknessMm))
        var at=-w.thicknessMm/2.0
        return layers.mapIndexed { i,layer ->
            val low=at; val high=at+layer.thicknessMm; at=high
            WallLayerFootprint(w.id,i,layer.material,listOf(
                edgeEnd(p,w,true,low),edgeEnd(p,w,false,low),
                edgeEnd(p,w,false,high),edgeEnd(p,w,true,high)
            ))
        }
    }

    fun footprints(p:BimProject,levelId:String):List<WallLayerFootprint> =
        p.walls.filter{it.levelId==levelId}.flatMap{footprints(p,it)}

    /** Locations requiring manual review: three or more wall endpoints at one axis node.
     * They are intentionally NOT mitered into a guessed multi-way Boolean union. */
    fun unresolvedMultiwayNodes(p:BimProject,levelId:String):List<Point2> {
        val ends=p.walls.filter{it.levelId==levelId}.flatMap{listOf(it.start,it.end)}
        // Quantization at 0.01 mm is only for grouping a rendering warning; model stays exact.
        val groups=ends.groupBy {
            Pair(kotlin.math.round(it.xMm*100).toLong(),kotlin.math.round(it.yMm*100).toLong())
        }
        return groups.values.filter{it.size>=3}.map{it.first()}
    }

    /** Total wall body outline, even if multiple individual layers are present. */
    fun outline(p:BimProject,w:Wall):List<Point2> = listOf(
        edgeEnd(p,w,true,-w.thicknessMm/2),edgeEnd(p,w,false,-w.thicknessMm/2),
        edgeEnd(p,w,false,w.thicknessMm/2),edgeEnd(p,w,true,w.thicknessMm/2)
    )
}
