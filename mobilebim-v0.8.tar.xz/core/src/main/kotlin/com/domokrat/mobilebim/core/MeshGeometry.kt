package com.domokrat.mobilebim.core

import kotlin.math.abs
import kotlin.math.hypot

/** Derived 2.5D triangular geometry; no mesh is persisted in project files. */
data class Point3(val xMm:Double,val yMm:Double,val zMm:Double)
data class MeshTriangle(val elementId:String,val layerIndex:Int,val material:String,
                        val a:Point3,val b:Point3,val c:Point3)

/**
 * Generates triangulated wall-layer prisms clipped by hosted rectangular openings.
 * Supports nonconvex plan junctions through convex fragments produced by
 * WallJoinSolver. Mesh is for visualization / first sections; not general BRep.
 * Internal coplanar faces between adjacent fragments may remain in the output.
 */
object MeshGeometry {
    private const val EPS=1e-5
    fun build(project:BimProject,levelId:String):List<MeshTriangle> {
        val level=project.levels.first{it.id==levelId}
        val walls=project.walls.filter{it.levelId==levelId}.associateBy{it.id}
        val openings=project.openings.groupBy{it.wallId}
        val triangles=mutableListOf<MeshTriangle>()
        for(piece in WallJoinSolver.resolve(project,levelId).pieces) {
            val wall=walls.getValue(piece.wallId)
            val voids=openings[wall.id].orEmpty()
            val cutsX=(listOf(0.0,wall.lengthMm)+voids.flatMap{listOf(it.offsetMm,it.endMm)})
                .distinct().sorted()
            val cutsZ=(listOf(0.0,wall.heightMm)+voids.flatMap{listOf(it.sillMm,it.topMm)})
                .distinct().sorted()
            val dx=(wall.end.xMm-wall.start.xMm)/wall.lengthMm
            val dy=(wall.end.yMm-wall.start.yMm)/wall.lengthMm
            val nx=-dy;val ny=dx
            fun clipAt(poly:List<Point2>,distance:Double,keepBelow:Boolean):List<Point2> {
                val center=Point2(wall.start.xMm+dx*distance,wall.start.yMm+dy*distance)
                val tangent=Point2(center.xMm+nx,center.yMm+ny)
                return WallJoinSolver.halfPlane(poly,center,tangent,keepBelow)
            }
            fun face(poly:List<Point3>) {
                for(i in 1 until poly.size-1)triangles+=MeshTriangle(piece.wallId,
                    piece.layerIndex,piece.material,poly[0],poly[i],poly[i+1])
            }
            for((s,e) in cutsX.zipWithNext()) {
                if(e-s<EPS)continue
                val section=clipAt(clipAt(piece.polygon,s,false),e,true)
                if(section.size<3)continue
                val mid=(s+e)/2
                for((low,high) in cutsZ.zipWithNext()) {
                    if(high-low<EPS)continue
                    val hole=voids.any {mid>it.offsetMm+EPS && mid<it.endMm-EPS &&
                        (low+high)/2>it.sillMm+EPS && (low+high)/2<it.topMm-EPS }
                    if(hole)continue
                    val base=level.elevationMm
                    val bottom=section.map{Point3(it.xMm,it.yMm,base+low)}
                    val top=section.map{Point3(it.xMm,it.yMm,base+high)}
                    face(top)
                    face(bottom.reversed())
                    for(k in section.indices) {
                        val next=(k+1)%section.size
                        face(listOf(bottom[k],bottom[next],top[next],top[k]))
                    }
                }
            }
        }
        return triangles
    }
}
