plugins { id("org.jetbrains.kotlin.jvm") }
kotlin { jvmToolchain(17) }
dependencies {
    testImplementation(kotlin("test-junit5"))
    testImplementation("junit:junit:4.13.2")
}
tasks.test { useJUnitPlatform() }
dependencies {
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:5.11.4")
    testRuntimeOnly("org.junit.vintage:junit-vintage-engine:5.11.4")
}
